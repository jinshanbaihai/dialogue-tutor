# 从每小问回溯到首次建立

|原题目标|所需关系|首次建立|完整例题|
|---|---|---|---|
|Q1a总体/单位/框/样本|研究集合、单个观察单位、抽取入口、实际抽取子集|survey③五个定义与名册对应|E1a博物馆完整编号与24张底片|
|Q1b一利一弊|检查单位数影响资源/实物处理，部分观察有抽样波动|survey③比较表与⑥测量边界|E1b24×1=24分钟的普查条件|
|Q2a第一观测加已知3|计算规则只需样本与已知常数|statistic③only、固定n与未知参数输入清单|E2a18/21/19的极差3|
|Q2b样本mean减未知μ|三数之和除以3；所需μ仍未知|statistic③及⑥规则与分布的区别|E2b已算R仍不能给出R−μ|
|Q3aD/E同值身份不同|mean=(X1+X2)/2；条件概率定义→乘法；独立后因子1/3；互斥原像相加|distribution③全部主WR路径、映射、概率与归一化|E3a改变为maximum的完整正向构造|
|Q3b剩余均匀WO|第一因子1/3，第二因子1/2；排重复身份但保留DE/ED|distribution③完整WO重建，⑤只回看逆向原像|主WO整例与下半独立D/E/F完整构造|
|Q4最大值恰5|取较大值；两数均不含9且至少一个5；原像GH/HG/HH|distribution④E3明确maximum|E3a两开关0/2四条完整路径|

`math-ledger.json`逐行保存before、operation、after、reason与对象/条件/路径；定义首行的before为空表示未进行前式变换。全部数学与逻辑行存在于最终静态HTML。三类修正入口按本次差异落repair-equal、repair-reverse、repair-weight，含匹配/遗漏/多选与实际值、当前权重及原行链接。

主推导内互动：pause-weight位于AB权重之前，AB/BA选择与两阶段因子短回忆；pause-preimage位于同输出归并之前，从AC/BB选择进入同一分布；pause-mechanism位于WO完整重建之前，同AB切WR/WO并回忆第二因子。它们保留原推导并提供返回锚点。3张短卡只记已打开参考，不计自评掌握；recall-core的两张正式回忆卡另走运行库review item。
