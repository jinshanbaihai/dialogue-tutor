from pathlib import Path
from fractions import Fraction as F
import json,hashlib
ROOT=Path(__file__).resolve().parent
q=lambda v:{'n':F(v).numerator,'d':F(v).denominator}
data={'schemaVersion':1,'tokens':{'x1':'#2364AA','x2':'#7250A4','stat':'#0F7074','ink':'#202C39','muted':'#586674','line':'#D4D8DC','surface':'#FFFFFF'},'conditions':{}}
for base,units,stat,mechanisms in [('main',[('A',1),('B',5),('C',9)],'mean',['wr','wo']),('task',[('D',2),('E',2),('F',8)],'mean',['wr','wo']),('example',[('K',0),('L',2)],'maximum',['wr']),('challenge',[('G',1),('H',5),('J',9)],'maximum',['wr'])]:
 for mech in mechanisms:
  key=f'{base}-{mech}-{stat}-v1';n=len(units);paths=[];bars={}
  for a,x in units:
   for b,y in units:
    allowed=mech=='wr' or a!=b
    t=F(x+y,2) if stat=='mean' else F(max(x,y))
    w=F(1,n*(n if mech=='wr' else n-1)) if allowed else F(0)
    pid=a+b
    paths.append({'id':pid,'firstId':a,'secondId':b,'x1':q(x),'x2':q(y),'sum':q(x+y),'stat':q(t),'allowed':allowed,'weight':q(w),'firstProbability':q(F(1,n)),'secondProbability':q(F(1,n if mech=='wr' else n-1) if allowed else 0),'linePrefix':f'{base}-{mech}-{pid}'})
    bars.setdefault(str(t),{'id':'b'+str(t).replace('/','_'),'value':q(t),'pathIds':[],'probability':F(0)})
    if allowed:bars[str(t)]['pathIds'].append(pid);bars[str(t)]['probability']+=w
  ordered=sorted(bars.values(),key=lambda b:F(b['value']['n'],b['value']['d']))
  for b in ordered:b['probability']=q(b['probability']);b['lineId']=f'{base}-{mech}-bar-{b["value"]["n"]}'
  data['conditions'][key]={'id':key,'base':base,'mechanism':mech,'statistic':stat,'sampleSize':2,'units':[{'id':i,'value':q(v)} for i,v in units],'paths':paths,'bars':ordered,'conditionText':('每次均匀抽取，放回后独立进行下一抽' if mech=='wr' else '每次从尚未抽出的身份中均匀抽取，无放回')}
text=json.dumps(data,ensure_ascii=False,indent=2);(ROOT/'exact-data.json').write_text(text);(ROOT/'data-hash.txt').write_text(hashlib.sha256(text.encode()).hexdigest()+'\n')
