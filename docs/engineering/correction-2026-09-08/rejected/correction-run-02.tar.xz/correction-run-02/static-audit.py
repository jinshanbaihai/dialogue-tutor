from pathlib import Path
from html.parser import HTMLParser
from fractions import Fraction as F
import json,re,hashlib
R=Path(__file__).parent
lesson=json.loads((R/'lesson.json').read_text())
class Parse(HTMLParser):
 def __init__(self):super().__init__();self.text=[];self.ids=[];self.links=[];self.hide=0
 def handle_starttag(self,t,a):
  d=dict(a)
  if t in ['script','style']:self.hide+=1
  if 'id' in d:self.ids.append(d['id'])
  if t=='a' and d.get('href','').startswith('#'):self.links.append(d['href'][1:])
 def handle_endtag(self,t):
  if t in ['script','style']:self.hide-=1
 def handle_data(self,d):
  if not self.hide and d.strip():self.text.append(d.strip())
p=Parse();p.feed(''.join(s['bodyHtml'] for s in lesson['sections']));(R/'authored-reading-text.txt').write_text('\n'.join(p.text))
print('broken links',set(p.links)-set(p.ids))
# Independent fixed-stem arithmetic; does not import make_data or author's helpers.
facts={'main-wr-mean-v1':([('A',1),('B',5),('C',9)],True,'mean'),'main-wo-mean-v1':([('A',1),('B',5),('C',9)],False,'mean'),'task-wr-mean-v1':([('D',2),('E',2),('F',8)],True,'mean'),'task-wo-mean-v1':([('D',2),('E',2),('F',8)],False,'mean'),'example-wr-maximum-v1':([('K',0),('L',2)],True,'maximum'),'challenge-wr-maximum-v1':([('G',1),('H',5),('J',9)],True,'maximum')}
data=json.loads((R/'exact-data.json').read_text())['conditions'];checks=[]
for k,(units,wr,stat) in facts.items():
 masses={};origins={}
 for a,x in units:
  for b,y in units:
   out=F(x+y,2) if stat=='mean' else F(max(x,y));w=F(1,len(units)*(len(units) if wr else len(units)-1)) if wr or a!=b else F(0)
   masses[out]=masses.get(out,F(0))+w;origins.setdefault(out,[])
   if w:origins[out].append(a+b)
   got=next(p for p in data[k]['paths'] if p['id']==a+b)
   assert F(**{'numerator':got['stat']['n'],'denominator':got['stat']['d']})==out
   assert F(got['weight']['n'],got['weight']['d'])==w
 for bar in data[k]['bars']:
  v=F(bar['value']['n'],bar['value']['d']);assert F(bar['probability']['n'],bar['probability']['d'])==masses.get(v,F(0));assert sorted(bar['pathIds'])==sorted(origins.get(v,[]))
 assert sum(masses.values())==1
 checks.append({'conditionKey':k,'expected':{str(v):str(p) for v,p in masses.items()},'origins':{str(v):p for v,p in origins.items()},'status':'pass'})
ledger=json.loads((R/'math-ledger.json').read_text());same=[]
for a,b in zip(ledger,ledger[1:]):
 if re.sub(r'\s','',a['after'])==re.sub(r'\s','',b['after']):same.append({'first':a['lineId'],'second':b['lineId'],'operation':b['operation'],'reason':b['reason']})
report={'mathIndependentFixedStems':checks,'adjacentSameExpressions':same,'brokenStaticLinks':sorted(set(p.links)-set(p.ids)),'htmlSha256':hashlib.sha256((R/'lesson.html').read_bytes()).hexdigest()}
(R/'static-audit-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('6 fixed-stem conditions verified; same-expression rows',len(same))
