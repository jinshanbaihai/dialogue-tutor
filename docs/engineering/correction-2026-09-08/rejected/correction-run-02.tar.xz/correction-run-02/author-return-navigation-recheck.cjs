'use strict';
// Focused recheck authorized after root found the return link was cleared by scroll redraw.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const {JSDOM,VirtualConsole}=require('../../repo/node_modules/jsdom');
const dir=__dirname,html=fs.readFileSync(path.join(dir,'lesson.html'),'utf8');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const htmlSha256=sha(html),expectedHash='7941f152c7f7eeedad7ca002dbd5602047ec9ba11f96ee16b6d7d2e127fe76d7';
const images=[],errors=[],results=[];const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const expected=[['main-wr-mean-v1','AB','mapping','pause-weight'],['main-wr-mean-v1','BA','mapping','pause-weight'],['main-wr-mean-v1','AC','bars','pause-preimage'],['main-wr-mean-v1','BB','bars','pause-preimage'],['main-wr-mean-v1','AB','bars','pause-mechanism'],['main-wo-mean-v1','AB','bars','pause-mechanism']];
async function run(){
 assert.equal(htmlSha256,expectedHash,'targeted recheck must identify the repaired HTML');
 const dom=new JSDOM(html,{url:'https://return-fixture.invalid/lesson.html',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=function(){};w.Image=class ImageCallbackFixture{constructor(){images.push(this);}set src(v){this._src=v;}get src(){return this._src;}success(){if(this.onload)this.onload();}};}});
 const w=dom.window,d=w.document;await new Promise(r=>w.addEventListener('load',r,{once:true}));
 try{
  const buttons=[...d.querySelectorAll('[data-action="inspect-path"]')];assert.equal(buttons.length,6);
  for(let i=0;i<6;i++){
   const input=expected[i],b=buttons[i],name=input.join(' / ');
   try{
    assert.deepEqual([b.dataset.condition,b.dataset.path,b.dataset.stage,b.dataset.back],input);
    b.click();const image=images.at(-1);assert(image,'request Image callback fixture absent');
    const selector='[data-proof-return] a[href="#'+input[3]+'"]';
    const before=d.querySelector(selector);assert(before,'return anchor absent after native inspect click');const beforeHtml=before.outerHTML;
    w.dispatchEvent(new w.Event('scroll'));
    const afterScroll=d.querySelector(selector);assert(afterScroll,'scroll redraw removed return anchor');const afterScrollHtml=afterScroll.outerHTML;
    image.success();
    const afterImage=d.querySelector(selector);assert(afterImage,'current Image success redraw removed return anchor');const afterImageHtml=afterImage.outerHTML;
    const s=w.DialogueTutor.instance.getState().activities['main-map'].exploration,r=s.rounds[input[0]];
    assert.equal(s.conditionKey,input[0]);assert.equal(r.pathId,input[1]);assert.equal(r.stageId,input[2]);assert.equal(r.mediaStatus,'shown');assert.equal(r.requested,r.displayed);
    assert.equal(d.querySelector('[data-displayed-group]').hidden,false);
    afterImage.click();assert.equal(d.activeElement.id,input[3],'native return click did not focus original proof pause');assert.equal(errors.length,0,'unhandled final HTML error');
    results.push({name,status:'pass',input:{conditionKey:input[0],pathId:input[1],stageId:input[2],back:input[3]},evidence:{beforeHtml,afterScrollHtml,afterImageHtml,requested:r.requested,displayed:r.displayed,focusedId:d.activeElement.id,targetText:d.activeElement.textContent.replace(/\s+/g,' ').slice(0,240)}});
   }catch(error){results.push({name,status:'fail',error:error.stack});}
  }
  await new Promise(r=>w.setTimeout(r,0));await new Promise(r=>w.setTimeout(r,0));assert.equal(errors.length,0);
 }finally{w.close();}
}
run().then(()=>{const report={complete:true,kind:'author-targeted-return-navigation-recheck-not-independent-review',htmlSha256,testScriptSha256:sha(fs.readFileSync(__filename)),executedAt:new Date().toISOString(),scope:'Only six inspect-path buttons, native click, synthetic scroll event, current Image callback success, persistent return anchor, and native return click focus.',priorFullSuiteHtmlSha256:'d1cd9293b4a307016a56a876bcc8d6022f262bb6e1283d095502126f7ab4610c',newHtmlFull73Executed:false,evidenceBoundary:{dom:'Final repaired HTML executes in jsdom; native inspect and anchor click handlers execute.',scroll:'Dispatched scroll event tests redraw behavior only, not real viewport scrolling or browser layout.',image:'Manual Image success callback fixture; not actual PNG decoding.',notTested:['real browser layout','native MathML rendering','touch','Tab navigation','200% zoom','actual image decoding']},results,jsdomErrors:errors};fs.writeFileSync(path.join(dir,'author-return-navigation-recheck.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({htmlSha256,pass:results.filter(r=>r.status==='pass').length,fail:results.filter(r=>r.status==='fail')}));process.exitCode=results.some(r=>r.status==='fail')?1:0;}).catch(error=>{console.error(error);process.exitCode=1;});
