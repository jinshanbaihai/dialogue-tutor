# 本轮作者行为自检的证据边界

本文件及 author-risk-tests.cjs 属于作者候选自检，不是独立五席批准。仅读取本轮 correction-run-02 原创材料与批准的通用运行库、规则和 jsdom。

测试直接执行最终组装 lesson.html，使用原生 radio/checkbox/select 的 click/change、原生 summary.click() 默认展开行为，以及公开 instance.importState/exportState。没有调用作者内部 checkDraft 或其它评分函数作为裁判。路径与概率期望按合同固定题面单独写在测试里。

- jsdom 的 Image 替身保存 src 并手动调用 onload/onerror，仅证明实际媒体状态机的成功、失败、迟到与恢复分支；它不证明 PNG 解码。
- jsdom 的 getBoundingClientRect 仅在明确静态来源视口场景返回指定矩形，其他场景返回空矩形。该 fixture 只证明状态分支，不是浏览器滚动、布局或视线证据。
- 文件导入走真实 input[type=file] change 处理器；jsdom File 的 text 方法使用可控 Promise 模拟异步读取完成，以检验读取期间打开参考后的应用边界。下载走真实导出按钮与 Blob/createObjectURL，记录 Blob 内容；不称操作系统实际下载成功。
- 没有真实浏览器排版、原生 MathML 呈现、触控、Tab 焦点顺序、200% 缩放或真实图像解码通过结论。
- author-risk-results.json 必须绑定实际运行的 lesson.html SHA-256；仍未组装的草稿不称通过。

## 测试夹具的修正记录

1. jsdom窗口销毁前排空原生summary/toggle任务，避免测试结束后访问已关闭document的jsdom自身异常。
2. 可见正文提取只对HTML元素调用getComputedStyle；jsdom的MathML节点不支持该接口的全部行为。MathML沿HTML祖先显隐提取文字，不据此评价排版。角色属性统一用getAttribute读取，避免MathML没有dataset时的夹具异常。
3. 跨窗口状态先作JSON规范化后比较，避免不同realm的空数组原型造成假失败。
4. 构造提交后的真实反馈是新的接触：恢复后、提交前的contacts必须与原快照完全相同；新提交后必须保留原来源及首次时间，允许新增该次反馈来源。旧的“提交后仍须完全相等”断言错把正确新增反馈当成失败。最终同HTML hash定向复跑，原失败保留在JSON的runHistory。
5. 拒绝提示证据改为实际 `.dt-study-body [role=status]` 中的“导入未应用：”文本，并验证学习记录details处于open。旧报告曾错误截取 `#dt-runtime` 脚本文本；该字段不是学习者可见证据。最终同hash对16条拒绝场景重新读取真实DOM提示，状态断言保持不变。

定向复跑只允许与完整基线相同的lesson.html SHA-256，脚本会在不一致时拒绝合并。author-risk-results.json保留原完整73项（71通过、2项旧期望失败）；author-risk-recheck.json独立保存实际执行的18项定向结果与runHistory。仅在同一HTML hash下按同名场景核对有效覆盖，没有跨HTML hash沿用通过项。

## 本次记录收束

HTML SHA-256：`d1cd9293b4a307016a56a876bcc8d6022f262bb6e1283d095502126f7ab4610c`。完整73项后同hash定向18项全部通过；按同名替换本次夹具/证据修正后，有效覆盖73项通过。完整原结果及两条旧期望失败均保留。风险1由root另行独立数学核验；本套是风险2—10的作者行为自检，不是五席批准。

root在此轮收束时另指出inspect-path返回锚点可能被scroll重绘清除。本套原有六按钮测试只覆盖请求、图片回调和立即返回，没有覆盖scroll后的返回；此新发现不被本次通过结论包含。若作者修复并改变HTML hash，需要单独标明新hash上的受影响路径复查，不能改写本轮原hash证据。

## root发现的返回入口问题：单独受影响复查

作者将返回链接移入独立 `nav[data-proof-return]`，新HTML SHA-256为 `7941f152c7f7eeedad7ca002dbd5602047ec9ba11f96ee16b6d7d2e127fe76d7`。

独立脚本 `author-return-navigation-recheck.cjs` 在此新hash上实际执行六个inspect-path按钮，各自依次进行原生click、scroll事件、当前Image成功回调、核返回锚点保留、原生返回click和真实document.activeElement定位：6项全部通过，0条jsdom运行异常。结果在 `author-return-navigation-recheck.json`。scroll只检实际重绘分支，Image只检回调分支；没有真实浏览器滚屏、布局或图像解码通过结论。

按root明确限定，新hash没有重新运行完整73项。本轮保留旧hash完整73项及同hash18项定向记录，并把新hash仅6项受影响复查独立列出；不得称新hash完整73项实跑通过。
