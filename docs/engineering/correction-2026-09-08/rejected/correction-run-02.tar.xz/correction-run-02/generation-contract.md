# 本轮原创课程合同（编写前，2026-09-08）

模式 bgct，Edexcel IAL Statistics 2 Chapter 6。唯一生成目录 correction-run-02。没有读取失败课件，通用 skill/runtime 与原始依赖可复用。可知模型配置未暴露；独立作者角色不是学生测量。

## 教学对象、首次建立与公式清单

|对象|①缺口|②短来源|③首次完整建立|④完整原创例题（六项）|⑤短的另一方向|⑥边界|⑦下半|
|---|---|---|---|---|---|---|---|
|survey：抽样调查|图书管理员能读几本，能否回答全库纸张损坏情况|官方统计机构对普查/调查用途的说明，不编首创者|survey-population 至 survey-tradeoff：目标总体→单位→抽样框→实际样本，census覆盖所有单位；成本/破坏性/及时性与覆盖/抽样波动的权衡|E1博物馆底片数字化：总体、单位、框及何时普查|从一条名册记录倒查它代表哪个单位|框漏项、非回应、census仍可能测量错误；不声称抽样必然代表|Q1a/Q1b|
|statistic：从观测可计算的量|三次电池读数已有，扣掉未知总体均值仍算不出|Pearson定义条目与正式statistic历史只在查实范围写|stat-only 至 stat-fixed：只用观测及已知常数、n已知，逐字解释only/unknown parameter，统计量抽前随机抽后数值|E2温度探头三读数：极差与含未知μ的比较，实际极差逐行算|从算法所需输入反查是否藏着未知量|含未知参数不合定义；已知常数、固定n允许；统计量不必无偏也不必使用所有观测|Q2a/Q2b|
|sampling distribution：把路径概率送到输出|A=1 B=5 C=9三个身份，独立均匀有放回抽2次；mean为5与1是否一样可能|Pearson范围；概率分组的数学来源在本课有限可加性推导，具名历史缺证不编|dist-wr-*：平均、P读法、有序身份、互斥、独立和乘法先立；9路径各1/9→均值→原像相加→完整分布；dist-wo-*：无放回条件改变，3个对角消失，6路径各1/6→重建|E3两种开关延迟0/2ms、独立均匀放回抽2次，求maximum完整分布，和主例mean作不同映射；六项逐行全额|从输出5倒看其原像，而非从路径顺着算；只指向③已建关系|随机须给均匀/独立条件；无放回第二次样本空间改变；相同数值不同身份保留|Q3a/Q3b/Q4|

未知前提在相应③主链讲清：平均的加总和除样本量；事件是路径集合；互斥指不能同时发生；相加因集合不重叠；条件概率只在第一抽固定后的剩余单位中计数。主链连续可读，当前练习③—⑥解法局部details，六项全部存在，随时全解。

## 课程事实与任务身份

- main数据：A1、B5、C9，样本量2，统计量mean；两条件 `main-wr-mean-v1`（两次独立，每次均匀放回），`main-wo-mean-v1`（逐次在剩余身份中均匀，无放回）。WR分布1,3,5,7,9对应1,2,3,2,1除9；WO对应0,1,1,1,0除3。
- main-map交互回答开场 `opening-middle-v-edge`：当前条件下mean5和mean1概率是否一样。预测冻结后选择实际路径/阶段并观察；不提交也可看。结果来源exact-data.conditions对应bars，不写固定默认结语。
- build-sample新数据：D2、E2、F8（身份不同，值可相同）；同样n=2，mean；两条件 `task-wr-mean-v1` 和 `task-wo-mean-v1`。完整构造四组。新增判断是身份与数值不一一对应，不能删掉D→E；普通换数的部分称新数据同构练习。
- Q4最大值挑战：G1、H5、J9，n=2独立均匀放回，求maximum为5的原像概率；新增判断是按最大值分组，同一对称mean目标的原像不能照搬。选择核对不声称广泛迁移。

## 行与角色

`exact-data.json`保存约分有理数；生成器为每条路径产出：允许资格、X1/X2、求和、除以2、真实约分、权重条件式、分子/分母乘法、原像概率相加、必要约分、完整分布校验。`derivation-ledger.json`每行含lineId/objectId/conditionKey/pathId/before/operation/after/reason。相邻同式列入审核；不需要改变分母时没有“通分”；单项原像直接取该路径概率；最大值直接比较取较大观测，不套mean文案。

`occurrences.json`逐位置绑定conditionKey/pathId/lineId/occurrenceId/operandPosition/objectId/role/exact/token。X1变量及其代入蓝#2364AA圆；X2紫#7250A4方；T变量/最终结果青#0F7074菱。中间和、样本量2、概率分子/分母墨色。正反路径和同值D/E各自保留角色。HTML MathML及Manim共同消费记录；选择中的复杂式使用受控MathML，不向纯文本choice塞HTML。

## 完整构造组依赖与反馈

|组|候选及依赖|提交前可见|冻结后|
|---|---|---|---|
|paths|固定全部D/E/F×D/E/F九候选；WR/WO均保留全部可选|仅原始有序身份和值，不给合法条数|missing/extra/matched精确集合，误选对角先说明无资格|
|mapping|仅来自本人勾选草稿，误选亦保留；取消路径移除其当前映射，历史答卷不动|每条已选路径可选2、5、8；不从标准集合补行|每个错映射显示实际两数、求和/除法行与归组行|
|weight|固定均匀独立乘法、剩余对象条件乘法、旧权重等依据候选|不显示正确路径数或删掉某备选|逐项比较本机制的第一抽/给定第一抽后的概率|
|distribution|固定输出候选2、5、8，每个选择有理概率（含0），不由标准允许路径生成|所有机制同一候选；未填只提示尚未选择的组，不提示标准答案数|精确概率逐输出对照，链接原像相加行|

一次有效提交冻结全部草稿和assistanceAtSubmit，双击不新增。完整度检用户已选行所需映射、概率依据、分布格；零路径也可明确提交空集判断，由核对报missing，不能只核显示行。每个差异有自己的真实身份/数值/当前资格和权重/回原行。三错误补讲 `repair-equal`, `repair-reverse`, `repair-weight` 各有真实小步。错误→对应修复；正确→Q4最大值新增判断；辅助→换未显示机制构造（若已看则称回看）；跳过→E3完整示例。所有入口实际可点击，错答不锁。

## 接触覆盖与状态事务

`reference-coverage.json`列每一个sourceId→componentId/conditionKey/kind/lineIds。
- 主链WR与WO公开正文分别覆盖main-map对应条件（阅读型探索的预测如接触过主链会记录辅助，不冒充盲测）；主例result帧覆盖其本条件；task的全解各只覆盖build-sample本条件。
- shared-task-solutions总details覆盖build-sample两条件，main-reference全解覆盖main-map两条件；原生summary与按钮都同一个同步采集函数，检查所有祖先hidden/closed details及display/visibility；未解码请求不算看过。
- 只要进入当前可显示的正文答案区域就记录该来源（采用真实可见状态，不臆测视线）；sources的首次timestamp幂等并集。contacts与visibleSolutionIds分开；提示只记录提示、不擅开全解。
- main-map及build-sample各自提交之前同步采集；dt:ready注册beforeImport/beforeExport，共用于公开API/原生file完成读取时/原生download。回调先保存可信当前接触，再验证入站；无效入站保留当前可信草稿/提交/接触。
- 组件v1+dataHash+条件身份；validate对合法condition/path/stage/frame、groupIDs/optionIDs、草稿、submission身份及其条件选择核全。允许未答半草稿、合法错选、requested/displayed不同的加载态；未知hash/版本/字段拒绝。submissionId冲突内容不同拒绝；有效恢复合并冻结原件与接触并集，restoreExploration静默持久化，不发新探索。恢复visibleSolutionIds精确开对应details。

## 媒体与阶段

main-map有限状态：条件2×允许路径（WR9/WO6）×阶段3（paths/mapping/bars），另每条件概览。每帧Scene真实PNG、hash、dataHash、sceneSourceHash、conditionKey/stageId/lineIds/pathIds/barIds和角色记录。手机单图4:5分面，不能把三图挤一张；正文当前式紧邻图片。列全帧合同再渲染。
- paths：已显示有序身份和资格；尚待其mean；下一步映射。
- mapping：已显示两观测代入与mean；尚待寻找同mean原像；下一步归组。
- bars：已显示原像及概率柱；尚待总质量核查/换条件；下一步当前机制的完整书面分布。
requested先验证、立即更新caption/当前href/当前文字回退，并隐藏旧图+旧动态公式+旧目标。成功仅当前序号一次提交displayed图式；失败保持requested当前行并可重试；旧成功/旧失败不改新状态。恢复使旧回调失效。构造未提交前图表不自动显示其新题答案。

## 开场收束与回访

openingQuestionId=`opening-middle-v-edge`；target=P(mean5)与P(mean1)；resultSource=current main condition bars；lineIds=`main-wr-bar-5`/`main-wr-bar-1`或wo对应；displayPredicate=相关结果接触或主链已实际显示（含全部祖先状态）；evidenceFields=prediction、assistanceAtSubmit、displayed/contacts、skipped、主动pathSelection。
未作答未揭示→给“查看当前条件分布”；只观察→精确答两概率并称已查看；无辅助正确→保留当前判断及核对；辅助正确→说明提交前参考；不一致→指出原选择和结果差异；跳过→保留跳过且若已见就答开场。正确/辅助/已见独立字段，不互斥。当前条件切换后重新取精确概率，计数不代替答案。

`recall-core`两卡：statistic only与无放回第二抽条件。结尾浏览按钮单参navigate并称浏览；继续未自评第二卡按真实状态称继续；提前/到期入口从DialogueTutor.getReviews真实列表选择具体cardIndex，传完整item；无item提供首次任务。第一卡完成、第二卡背面开着时重访第一卡必须先正面，提前不推进间隔，历史保留。

## 作者风险测试与冻结

最终lesson.html的原生DOM事件执行generation-checks十项：独立Fraction题干复算与逐行理由；零/漏/多草稿全组泄露；正确/错/提示/跳过/参考/重试全程免键入；两个组件summary同队列提交/旧导入即时导出新窗口；API与原生file/download坏记录拒绝及可信恢复；逐位置角色；媒体A成功B失败、跨条件失败、C成功旧B回调、重试、加载恢复；missing/extra反馈和四种下一入口；六收束状态并切条件；多卡真实item复习。
保存输入、DOM与导出摘录、活动/行/帧ID、结果。实际PNG按最终祖先padding扣除后的手机宽度目视并测像素。浏览器基础设施不可用；jsdom不能认证原生MathML/触控/Tab/200%缩放，人工Image回调不能认证真实图片解码。这些保留未测，不称通过。
正式冻结后不修改完整候选；退回由root先修skill再独立重生成。

## 编写前评议落实（教育/叙事）

静态主链可读与已呈现分开：`main-map`挂在开场条件和平均的一个可承担例子后、所有概率答案正文之前；下面三对象正常连续公开。静态答案行须祖先可见且getBoundingClientRect与当前viewport相交，或学习者点击明确定位到该行，才记presented；不声称已读/理解。不设停留秒数。observer/scroll仅增补，提交/import/export同一同步函数重新读当前矩形。原生summary全解是主动打开，按本节点与所有祖先真实显隐采集，即时不用等待toggle。jsdom矩形fixture只检分支，实际滚屏/视口仍属浏览器未测。

`opening-middle-v-edge`结果已显示须精确覆盖两个目标：P(mean5)与P(mean1)。main的bars帧显示整幅分布，覆盖两目标；paths/mapping帧只覆盖路径事实或单次mean，不解锁两概率结语。静态只有bar-5和bar-1均呈现才回答开场；部分呈现时引导补看缺少的概率行。主链WR呈现只记WR；随后WO呈现才记WO。预测冻结conditionKey，切条件只比较本条件匹配的预测，旧条件预测单列历史。

六条真实路线（测试起始均清新课程窗口；通过实际控件/fixture赋予不同可见范围）：
1. 未作答未揭示：开场不选、不进下方答案→直接结尾→当前条件的“查看两目标概率”入口。
2. 只观察：开场不选→主动看bars帧→结尾：WR为三分之一大于九分之一，称已查看，无预测。
3. 无辅助正确：开场选择“不一样，中间较可能”→冻结预测→主动bars→结尾：原判断与这次枚举一致；仍不称完整证明/长期掌握。
4. 辅助正确：主动打开主例全解→立即选择同判断→提交→结尾：相同数学结果；提交前已打开参考。
5. 不一致：开场选择“一样可能”→冻结→bars→结尾：原判断与实际概率不一致，给原像差异修复。
6. 跳过：点跳过预测→结尾，尚未bars给查看入口；再点查看则给结果并保留跳过事实。跳过不算错误。
所有路线切WO后概率更新为三分之一与零；WR预测不冒充WO预测，允许另起本条件判断。

Q小问六项的实际入口规则：每问ID `q1a/q1b/q2a/q2b/q3a/q3b/q4`，其顺序锚点后缀 `-read/-method/-connect/-rule/-work/-answer`，全解 `-solution`。
- Q1a：图书馆现存全部实体书、单本、馆藏登记簿、被检查的60本；辨认总体/单位/框/样本。
- Q1b：每检查一本须拆装书脊，比较普查与样本调查；明确破坏性成本与抽样波动，不由成本推断代表性。
- Q2a：三个电池读数，选只用样本与已知常数的计算，逐个核输入。
- Q2b：另给未知μ，样本平均减μ；即使所有读数已知仍欠μ；已知常数可用。分清统计量公式不含未知参数与统计量分布可能依赖总体参数。
- Q3a：D2/E2/F8独立均匀放回完整构造，均值2原像DD/DE/ED/EE；身份不按数值去重。
- Q3b：同袋逐次均匀无放回完整构造，均值2原像DE/ED；DD/EE同身份排除但DE/ED保留。
- Q4：以E3最大值为参照的新数据练习；三值1/5/9的中间目标5须排除任一含9路径，原像GH/HG/HH。新增的是中间阈值需要协调“没有9”和“至少一个5”，不只因名称换为maximum。

条件乘法在dist-rule首次先写：P(first=a and second=b)=P(first=a)×P(second=b given first=a)，说明两个阶段的比例连乘；独立时第二因子才可换成边际概率。WO在给定第一抽后列剩余两个身份，解释各二分之一，身份相同条件概率为零；然后代入三分之一与二分之一，再算分子/分母各自乘法到六分之一。

后续选择按真实接触：辅助时优先尚未呈现的另一task机制，若两者均已见则未揭示Q4；均已见就明确“回看原像/按现有记录回忆”，不承诺不存在的新独立挑战。Q4已完成锁定时按钮称回看。

## 最后具体化：接续、条件乘法与界面预算

`dist-conditional-definition`：P(second=b given first=a)=P(first=a and second=b)/P(first=a)，先解释只在first=a的那部分机会中计算比例，且P(first=a)>0。`dist-conditional-multiply`两边同乘这个非零概率；`dist-product-rule`约去右侧非零分母，得到联合事件概率等于第一事件概率乘条件概率。`dist-independent`才使用独立条件把后者换成第二抽边际概率。WO直接用条件式，从剩余身份的集合推得第二因子。

Q4采用原生choice但选择的是整组原像/理由，选项包括GH/HG/HH（没有J且至少一个H）、GJ/HH/JG（mean5原像）、GG/GH/HG/HH（最大值至多5而非恰5）；提交后完整全解再合并概率。不能只选最后分数。

|核心组件/结果|真实下一动作ID及conditionKey|已完成或已见时|
|---|---|---|
|main-map / correct|build-sample，task-wr-mean-v1，“按D/E不同身份构造”|目标已冻结则“回看有放回构造”|
|main-map / assisted|build-sample未接触的task-wr-mean-v1，或task-wo-mean-v1；均已见则q4-answer，challenge-wr-maximum-v1|所有目标已见时“回看最大值原像”；不称首次独立|
|main-map / incorrect|repair-equal，main当前conditionKey，“检查两种均值的原像”|局部逐行补讲仍可用|
|main-map / skipped|定位e3a-work，example-wr-maximum-v1，“先读最大值完整例题”|明确示例参考|
|build-sample / correct|q4-answer，challenge-wr-maximum-v1，“检验没有J且至少一个H”|已提交则“回看最大值原像核对”|
|build-sample / assisted|本组件尚未呈现的另一task条件，否则未呈现q4-answer|均已见则“回看具体原像/复习条件”|
|build-sample / incorrect|repair-reverse或repair-weight或repair-equal，当前task条件；按missing/extra/错映射/错概率具名选择|每个差异附当前条件原行，补讲不换成默认数据|
|build-sample / skipped|定位e3a-work，example-wr-maximum-v1|示例参考，可直接全解|

main-map的预测及build-sample的draft/activeSubmissionId分别存于rounds[conditionKey]，切条件只切当前视图不改记录；切回原条件恢复该条件草稿/锁定，重试只清该条件当前draft并保留所有冻结提交和接触。入站有效半草稿或合法错选保留。submittedId与实际submission.conditionKey须一致，错配拒绝。预测提交前是否参考也仅冻结本条件。

summary的click监听只排入microtask补采集，读取默认动作后的真实open；toggle也补充，不把事件出现等同已显示。决定性同步采集位于submit/beforeImport/beforeExport，在这些边界读取当时已改变的open和完整祖先显隐，所以同队列summary→submit/import/export不会靠等待toggle。参考呈现contacts和visibleSolutionIds分开，静态presented历史不会在恢复时伪造当前视口。

回访具体表：浏览recall-core/index当前值用单参navigate；继续recall-core当前未自评卡保留原状态；提前练习recall-core/index0或index1取getReviews返回的非到期完整item；到期练习取相同活动真实due item并传其cardIndex。按钮标签显示具体卡“only定义”或“第二抽条件”。第一卡完成、当前第二卡背面时，提前/到期index0回到第一张正面；浏览保留第二张背面，继续保留未完成状态。

PNG源1000×1250。课程图在main中左右16px，媒体组件及dt-custom所有水平padding清零、边框清零，img自身左右各1px：360→328−2=326px图内容宽；390→358−2=356px。若实际runtime祖先还有padding，最终有效样式另行扣除后重算。源数学字形至少60px（326时19.56px），文本至少54px（326时17.60px）；图标主线至少9px（326时2.93px），轴至少5px（326时1.63px）。main WR/WO纵轴共用0至1/3、横轴1/3/5/7/9真实数距；WO端点1、9空心零标记。逐位置核静态与动态两代入项/结果token，常量保持墨色。

第二幕来源落实：survey引用ONS Coverage estimation for Census2021第3节“Census Coverage Survey”，只支持其实际漏计检查用途；statistic引用Pearson 2013 SAMS的S2评分定义“calculation based only on known data from a sample”（需原文打开定位后写入source S4）；S2考纲4.2仅作范围来源S1；distribution来源S1作范围，构造归本课有限互斥可加性证明，不写伪造的首创历史。任何历史未能核实处明确说明未作历史首创断言。

## 实现时补齐的精确入口与来源

主推导在`pause-weight/pause-preimage/pause-mechanism`三处加入六个原生`inspect-path`按钮，改变真实condition/path/stage并保留回到原推导的独立`[data-proof-return]`导航节点；scroll、加载回调与收束重绘只更新各自区域，不清除此节点。三处`-recall`短卡分别覆盖main WR/WR/WO，翻开后按已显祖先与共同提交/转移边界记来源。正式recall-core仍使用真实getReviews item，与短卡来源不同。

静态main各bar的前置原像/概率过程行记辅助接触，只有最终概率行或完整分布表贡献开场目标覆盖；表有`main-wr-table/main-wo-table`显式来源。构造冻结反馈显示后追加`construction-feedback-<conditionKey>`来源，首答assistance快照保持原值，后续同条件作答计已有反馈辅助。重试开放空草稿，旧冻结答卷及逐项反馈仍在本条件的可读历史details中。

首次存储恢复的非空未知组件也走完整验证；缺版本/坏hash不会静默换成空白，用户可用同课有效公开导入恢复。原生API与文件读取完成的边界继续共同采集刚发生的参考。具体反馈按真实错项进入`repair-equal/repair-reverse/repair-weight`实体位置，每个错概率附当前原像权重，错权重链接到同条件同路径的条件乘法起始行。
