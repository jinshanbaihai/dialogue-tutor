from pathlib import Path
from fractions import Fraction as F
import json, html, hashlib, re
R=Path(__file__).resolve().parent
D=json.loads((R/'exact-data.json').read_text()); HASH=hashlib.sha256((R/'exact-data.json').read_bytes()).hexdigest()
C=D['conditions']; ledger=[]; occurrences=[]
def esc(s):return html.escape(str(s))
def num(v):
 if isinstance(v,dict):v=F(v['n'],v['d'])
 else:v=F(v)
 return f'<mn>{v.numerator}</mn>' if v.denominator==1 else f'<mfrac><mn>{v.numerator}</mn><mn>{v.denominator}</mn></mfrac>'
def rawfrac(a,b):return '<mfrac><mrow>'+a+'</mrow><mrow>'+b+'</mrow></mfrac>'
def op(s):return '<mo>'+esc(s)+'</mo>'
def math(s):return '<math xmlns="http://www.w3.org/1998/Math/MathML"><mrow>'+s+'</mrow></math>'
def role(role_,content,line='',path='',condition='',value=None,position='variable'):
 oid={'x1':'X1','x2':'X2','stat':'T'}[role_];oc=f'{line}-{role_}-{position}'
 if line:occurrences.append({'conditionKey':condition,'pathId':path,'lineId':line,'occurrenceId':oc,'operandPosition':position,'objectId':oid,'role':role_,'exact':value,'token':D['tokens'][role_]})
 return f'<mstyle data-role="{role_}" data-object-id="{oid}" data-occurrence="{oc}" mathcolor="{D["tokens"][role_]}">{content}</mstyle>'
def var(r,line='',p='',c=''):
 return role(r,'<mi>T</mi>' if r=='stat' else '<msub><mi>X</mi><mn>'+('1' if r=='x1' else '2')+'</mn></msub>',line,p,c)
def val(r,v,line='',p='',c=''):
 return role(r,num(v),line,p,c,v,'value')
def line(id,expr,reason,before=None,operation='definition',objectId='T',conditionKey='',pathId=''):
 if before is None and operation in ['substitute time factors','compare observations','apply independence','translate rule','expand sample mean']:before={'substitute time factors':'24 negatives; one minute for each negative','compare observations':'observed temperatures 18, 21, 19','apply independence':'P(F|E), under the stated independent draw assumption','translate rule':'A is the first observed lifetime plus 3 known hours','expand sample mean':'B = sample mean minus unknown mu; fixed sample size 3'}[operation]
 if before is None and operation=='sum distribution':before='All output probabilities in '+conditionKey+' distribution table'
 if before is None and operation=='exclude same identity':before='First identity '+pathId[:1]+' has already been removed under '+conditionKey+'; second identity '+pathId[1:]+' is the same physical unit'
 if before is None and operation in ['common denominator','same-denominator addition rule','add numerators','divide equal positive integers'] and ledger:before=ledger[-1]['after']
 ledger.append({'lineId':id,'objectId':objectId,'conditionKey':conditionKey,'pathId':pathId,'before':before,'operation':operation,'after':re.sub('<[^>]+>',' ',expr),'reason':reason})
 return f'<div class="math-line" id="{id}" data-line="{id}"><div class="expression">{math(expr)}</div><p class="reason">{reason}</p></div>'
def textline(id,text,reason,objectId='concept'):
 ledger.append({'lineId':id,'objectId':objectId,'before':None,'operation':'premise','after':text,'reason':reason})
 return f'<div class="logic-line" id="{id}"><p>{text}</p><p class="reason">{reason}</p></div>'
def p(s):return '<p>'+s+'</p>'
def mt(v):return math(num(v))
def prob(t):return '<mi>P</mi>'+op('(')+var('stat')+op('=')+val('stat',t)+op(')')
def derivation(key):
 c=C[key];base=c['base'];mech=c['mechanism'];stat=c['statistic'];n=len(c['units']);prefix=f'{base}-{mech}'
 out=f'<div class="condition-proof" data-condition="{key}"><h4 id="{prefix}-paths">完整路径与{("mean" if stat=="mean" else "maximum")}：{("有放回" if mech=="wr" else "无放回")}</h4>'
 out+=p('身份名单为'+ '、'.join(u['id']+'的数值'+str(u['value']['n']) for u in c['units'])+'。有序路径把先后次序保留下来；先固定第一身份，再逐个配第二身份，能逐行排查遗漏。')
 for pa in c['paths']:
  pid=pa['id'];pr=pa['linePrefix'];x,y=pa['x1'],pa['x2'];sv=pa['stat'];allowed=pa['allowed']
  out+=f'<section class="path-proof" data-path="{pid}"><h5>{pid[0]} → {pid[1]}</h5>'
  if not allowed:
   out+=textline(pr+'-sub',f'{pid[0]}已经被取走；第二次没有同一个{pid[1]}可取。','无放回排除重复身份；即使另一枚筹码数值相同，它仍是另一个可抽身份。')
   out+=line(pr+'-weight','<mi>P</mi>'+op('(')+f'<mtext>{pid}</mtext>'+op(')')+op('=')+num(0),'该路径不在本机制的允许样本空间中，概率为零。',operation='exclude same identity',conditionKey=key,pathId=pid)
   out+='</section>';continue
  # Mean transformations really performed, no repeated pseudo-operations.
  sub=pr+'-sub';summ=pr+'-sum';res=pr+'-result'
  if stat=='mean':
   expr=var('stat',sub,pid,key)+op('=')+rawfrac(val('x1',x,sub,pid,key)+op('+')+val('x2',y,sub,pid,key),num(2))
   out+=line(sub,expr,'将这条路径的第一观测和第二观测分别放入平均公式；分母2是这次样本量。',before='T=(X1+X2)/2',operation='substitute observations',conditionKey=key,pathId=pid)
   expr2=var('stat',summ,pid,key)+op('=')+rawfrac(num(pa['sum']),num(2))
   out+=line(summ,expr2,'先计算分子中两个观测值的和；分母保持2。',before=re.sub('<[^>]+>',' ',expr),operation='add numerator',conditionKey=key,pathId=pid)
   out+=line(res,var('stat',res,pid,key)+op('=')+val('stat',sv,res,pid,key),'将分子除以2，得到这条路径的mean；观察单位与原数值相同。',before=re.sub('<[^>]+>',' ',expr2),operation='divide by sample size',conditionKey=key,pathId=pid)
  else:
   expr=var('stat',sub,pid,key)+op('=')+'<mi>max</mi>'+op('(')+val('x1',x,sub,pid,key)+op(',')+val('x2',y,sub,pid,key)+op(')')
   out+=line(sub,expr,'max读作取最大值：比较两个观测；相等时这个共同值就是最大值。',before='T=max(X1,X2)',operation='substitute observations',conditionKey=key,pathId=pid)
   out+=line(res,var('stat',res,pid,key)+op('=')+val('stat',sv,res,pid,key),'比较这两个观测后取较大者，得到maximum；这里没有加总再平均。',before=re.sub('<[^>]+>',' ',expr),operation='take maximum',conditionKey=key,pathId=pid)
  den=n if mech=='wr' else n-1
  out+=line(pr+'-weight-sub','<mi>P</mi>'+op('(')+f'<mtext>{pid}</mtext>'+op(')')+op('=')+num(F(1,n))+op('×')+num(F(1,den)),f'第一抽在{n}个身份中均匀选{pid[0]}；'+(f'放回且独立，第二抽仍在{n}个身份中均匀选{pid[1]}。' if mech=='wr' else f'给定已取走{pid[0]}，第二抽只在剩下{den}个身份中均匀选{pid[1]}。'),before='P(first and second)=P(first) P(second given first)',operation='substitute conditional probabilities',conditionKey=key,pathId=pid)
  out+=line(pr+'-weight-product','<mi>P</mi>'+op('(')+f'<mtext>{pid}</mtext>'+op(')')+op('=')+rawfrac(num(1)+op('×')+num(1),num(n)+op('×')+num(den)),'分数相乘时，分子相乘、分母相乘；两个分母都为正。',before=f'1/{n} × 1/{den}',operation='multiply fractions rule',conditionKey=key,pathId=pid)
  out+=line(pr+'-weight-numerator','<mi>P</mi>'+op('(')+f'<mtext>{pid}</mtext>'+op(')')+op('=')+rawfrac(num(1),num(n)+op('×')+num(den)),'分子的一乘一得到一，分母的乘积暂时保留。',before=f'(1×1)/({n}×{den})',operation='multiply numerator',conditionKey=key,pathId=pid)
  out+=line(pr+'-weight','<mi>P</mi>'+op('(')+f'<mtext>{pid}</mtext>'+op(')')+op('=')+num(pa['weight']),f'分母{n}乘{den}得到{n*den}；分子为1，因此已是最简分数。',before=f'1/({n}×{den})',operation='multiply denominator',conditionKey=key,pathId=pid)
  out+='</section>'
 out+=f'<h4 id="{prefix}-grouping">按相同输出归并</h4>'+p('同一个输出所对应的全部输入路径称它的原像（preimage）。每次抽样只走一条有序路径，因此不同路径互斥；把这些路径概率相加，不会重复计数。')
 for b in c['bars']:
  t=b['value'];bid=b['lineId'];ids=b['pathIds'];pr=b['probability'];den=n*(n if mech=='wr' else n-1)
  out+=f'<section class="bar-proof"><h5>输出 {t["n"]}</h5>'
  out+=textline(bid+'-preimage',('原像：'+ '、'.join(ids)) if ids else '原像为空：没有允许路径产生这个输出。','根据每条路径的实际统计量映射逐项归组，身份不同的路径保留。')
  lhs=prob(t)+op('=')
  if not ids:
   out+=line(bid,lhs+num(0),'空事件的概率是零。',before='empty preimage',operation='empty event',conditionKey=key)
  elif len(ids)==1:
   out+=line(bid,lhs+num(pr),'原像只有'+ids[0]+'这一项，直接取它的路径概率；没有额外相加。',before=ids[0]+' weight',operation='single path probability',conditionKey=key)
  else:
   out+=line(bid+'-add',lhs+op('+').join(num(F(1,den)) for _ in ids),'各原像路径互斥，使用概率加法法则；每一项对应一个列出的身份路径。',before=' + '.join('P('+x+')' for x in ids),operation='substitute path weights',conditionKey=key)
   out+=line(bid+'-numerators',lhs+rawfrac(op('+').join(num(1) for _ in ids),num(den)),'这些分数已具有相同分母，保留分母并把分子写成和；没有改变分母。',before='+'.join('1/'+str(den) for _ in ids),operation='same-denominator addition rule',conditionKey=key)
   count=len(ids)
   out+=line(bid if F(count,den).denominator==den else bid+'-count',lhs+rawfrac(num(count),num(den)),f'将{count}个分子1相加得到{count}。',before='+'.join('1' for _ in ids),operation='add numerators',conditionKey=key)
   if F(count,den).denominator!=den:
    g=__import__('math').gcd(count,den)
    out+=line(bid,lhs+num(pr),f'分子{count}与分母{den}同除公因数{g}，值不变。',before=f'{count}/{den}',operation=f'reduce by {g}',conditionKey=key)
  out+='</section>'
 out+='<div class="distribution-table" id="'+prefix+'-table"><table><caption>本条件的完整sampling distribution</caption><thead><tr><th>统计量输出</th><th>概率</th></tr></thead><tbody>'
 for b in c['bars']:out+='<tr><td>'+math(val('stat',b['value']))+'</td><td>'+mt(b['probability'])+'</td></tr>'
 out+='</tbody></table></div>'+p('其余取值的概率为零。每条允许路径恰好进入一个原像：统计量对一个样本只给一个结果，因此归组没有遗漏，也没有重复。')
 weights=[F(b['probability']['n'],b['probability']['d']) for b in c['bars']];nonzero=[x for x in weights if x]
 lcm=__import__('math').lcm(*(x.denominator for x in nonzero));scaled=[x.numerator*(lcm//x.denominator) for x in nonzero]
 out+=line(prefix+'-mass-start','<mtext>总概率</mtext>'+op('=')+op('+').join(num(x) for x in nonzero),'把表中全部非零输出的概率相加；零项不改变总和。',operation='sum distribution',conditionKey=key)
 if len(set(x.denominator for x in nonzero))>1:
  out+=line(prefix+'-mass-common','<mtext>总概率</mtext>'+op('=')+op('+').join(rawfrac(num(x),num(lcm)) for x in scaled),f'把各分数改写成分母{lcm}，每项分子、分母同乘相同的正整数。',operation='common denominator',conditionKey=key)
 out+=line(prefix+'-mass-numerators','<mtext>总概率</mtext>'+op('=')+rawfrac(op('+').join(num(x) for x in scaled),num(lcm)),'分母已经相同，保留分母、相加分子。',operation='same-denominator addition rule',conditionKey=key)
 out+=line(prefix+'-mass-sum','<mtext>总概率</mtext>'+op('=')+rawfrac(num(sum(scaled)),num(lcm)),'计算分子中的整数和。',operation='add numerators',conditionKey=key)
 out+=line(prefix+'-mass-one','<mtext>总概率</mtext>'+op('=')+num(1),'分子与非零分母相同，所以这个商等于一。',operation='divide equal positive integers',conditionKey=key)
 return out+'</div>'

def act(n,title,body):return f'<div class="act" data-act="{n}"><h3>{"①②③④⑤⑥⑦"[n-1]} {title}</h3>{body}</div>'
def mount(id):return f'<div data-dt-activity="{id}"></div>'
def details(id,title,body):return f'<details id="{id}" class="reference"><summary>{title}</summary>{body}</details>'
def six(id,en,zh,read,method,connect,rule,work,answer,activity=None):
 return f'<article class="question" id="{id}"><h4>{id.upper()}</h4><div class="stem"><strong>题干：</strong><p lang="en">{en}</p><p>中文题面（我译的那一份）：{zh}</p></div>'+f'<div id="{id}-read"><h5>① 读清给定与限制</h5>{read}</div><div id="{id}-method"><h5>② 条件引向哪条方法</h5>{method}</div>'+(mount(activity) if activity else '')+details(id+'-solution','直接看完整讲解 · '+id.upper(),f'<div id="{id}-connect"><h5>③ 接回已经造出的对象</h5>{connect}</div><div id="{id}-rule"><h5>④ 选择关系与条件</h5>{rule}</div><div id="{id}-work"><h5>⑤ 一步一步核算</h5>{work}</div><div id="{id}-answer"><h5>⑥ 答案与原创评价要点</h5>{answer}</div>')+'</article>'
def total(id,en,zh):return f'<div class="total-stem" id="{id}-stem"><p><strong>英文原题 · 原创</strong></p><p lang="en">{en}</p><p><strong>中文题面</strong></p><p>{zh}</p></div>'
# The entries below are original authored problems, not transcribed textbook tasks.
INTRO=p('桌上有三枚带身份的筹码：A写1，B写5，C写9。每次都均匀随机抽一枚，放回后重新混合；两次抽取独立。均匀是每枚机会相同，独立是第一抽的结果不改变第二抽的机会。每一组抽两次，记录先后。')
INTRO+=p('把第一次数值叫第一观测X₁，第二次数值叫第二观测X₂。平均数（mean）把这两个观测的总量平分给两次位置，记为T；这个字母在本页始终表示当前指定的统计量。小标1、2表示先后次序，不是乘法。')
INTRO+=line('intro-mean',var('stat')+op('=')+rawfrac(var('x1')+op('+')+var('x2'),num(2)),'两项的平均等于其和除以项数；这里项数是已知的2。',operation='define mean')
INTRO+=line('intro-sub',var('stat')+op('=')+rawfrac(val('x1',1)+op('+')+val('x2',5),num(2)),'例如沿A→B抽到第一观测1、第二观测5，将两值放入平均式。',before='mean formula',operation='substitute observations')
INTRO+=line('intro-sum',var('stat')+op('=')+rawfrac(num(6),num(2)),'分子中一加五得到六，分母保持二。',before='(1+5)/2',operation='add numerator')
INTRO+=line('intro-result',var('stat')+op('=')+val('stat',3),'六除以二得到三。这只是这一次样本的mean。',before='6/2',operation='divide')
INTRO+=p('概率（probability）描述按同一机制抽样时某件事发生的机会；P读作“概率”。P(T=5)问的是抽到一个mean为5的样本的机会，不是在问某一枚筹码的机会。现在可以心中先作一个判断，暂时不会公布核对结果。也可以先读下面的完整构造。')
INTRO+=mount('main-map')+p('<button type="button" data-lesson-action="go-ending">直接到本次收束</button> <button type="button" data-lesson-action="all-solutions">展开所有参考讲解</button>')
SURVEY=act(1,'先确定要回答的是谁',p('管理员检查了书桌上的十本书，发现两本书脊受损。这个结果准确描述这十本书。图书馆若要安排全库修缮预算，还需要知道这十本和全库的联系：哪些书有机会被选到，哪些书连名单都没进？只会计算两个除以十，还没有回答这层联系。'))
SURVEY+=act(2,'从统计工作的用途理解它',p('英国国家统计局（ONS）在《Coverage estimation for Census 2021 in England and Wales》第3节说明，普查之后仍使用独立的覆盖调查估计漏计。这给出一个实际来由：调查既要明确所覆盖的人或物，也要检查没有观察到的部分。这里引用的是2021年普查的做法，未把它说成抽样调查的历史首创。<a href="#source-ons">来源S3</a>'))
sbody=textline('survey-population','先给研究对象划边界：某日馆内全部实体书。这个完整集合叫总体（population）。','总体由研究问题确定；地点、日期、对象类型改变，所指集合可能改变。')
sbody+=textline('survey-unit','一次选择和观察的基本对象是一本书，叫抽样单位（sampling unit）。','“书脊是否受损”附着在每一本实体书上。书名可有多本复本，因此只列书名不能区分单位。')
sbody+=textline('survey-frame','把每一本书的馆藏编号列成名册，作为选择入口，叫抽样框（sampling frame）。','框是操作上能找到单位的清单；总体是想描述的完整集合。两者理想上对应，实际可能有缺漏、重复或过期记录。')
sbody+=textline('survey-sample','从名册中实际选出并检查的那部分书，构成样本（sample）。','样本是总体中的一部分；样本中的观察结果是手上已有的数据，不能把尚未观察的书也算进这份数据。')
sbody+=textline('survey-census','若对总体内每一个单位都收集所需数据，这项调查叫普查（census）。','“每一个”区分了覆盖全体与只取一部分的调查。总体大并非定义条件，小总体也可以普查。')
sbody+=p('四个层次可以按问题检查：想描述哪一群，回答population；每次拿哪一个，回答unit；从哪里挑，回答frame；真正拿到了哪些，回答sample。名册虽然常有很多行，它仍是选择入口，不能仅因“很多”就称population。')
sbody+='<table><caption id="survey-tradeoff">调查办法与代价</caption><thead><tr><th>办法</th><th>得到什么</th><th>代价与限制</th></tr></thead><tbody><tr><td>Census</td><td>若成功覆盖并准确测量全体，就取得所定义总体的完整资料；没有由只选一部分产生的抽样波动。</td><td>可能费时、昂贵。检查会破坏单位时，对全体都检查会损坏全体。仍可能漏记、录入或测量错误。</td></tr><tr><td>Sample survey</td><td>较少单位通常需要较少资源，可以更快取得结果；破坏性检查能保留未抽中的单位。</td><td>样本会随所抽单位改变，结论具有抽样波动；框缺漏或非回应会限制对总体的描述。</td></tr></tbody></table>'
sbody+=p('因此选择调查办法要把目标精度、总体规模、资源与检查性质放在一起。规模小且容易接触的总体可能适合census；破坏性检查通常更适合sample survey。抽得少本身不会使样本有代表性，取样机制和框的质量仍需要交代。')+mount('survey-check')
SURVEY+=act(3,'把总体、单位、框与样本分开',sbody)
e1en='A museum has 24 glass negatives, each with a unique catalogue number. All 24 entries are up to date. Checking a negative for a digital catalogue causes no damage and takes one minute. (a) Identify the population and a suitable sampling frame. (2) (b) Give one reason why a census is practical. (1)'
e1zh='博物馆有24张玻璃底片，每张有唯一馆藏编号；24项登记都是最新的。为数字目录检查一张底片不会损伤它，耗时一分钟。(a) 指出总体与一个合适的抽样框。(2) (b) 给出普查可行的一条理由。(1)'
E1=total('e1',e1en,e1zh)
E1+=six('e1a','(a) Identify the population and a suitable sampling frame. (2)','(a) 指出总体与一个合适的抽样框。(2)',p('“24 glass negatives”给出了这次研究的完整集合；“unique catalogue number”和“up to date”保证编号可用于区分并找到这些单位。'),p('Identify要求指出对应对象。这里没有要求估计比例，先算百分比不会回答“总体是谁”。'),p('第一章③的population与frame分别回答研究范围和选择入口。'),p('不用数值公式；分别对照集合定义与清单定义。'),textline('e1a-pop','Population：这24张玻璃底片。','被研究的是底片本身，24只是总体大小。')+textline('e1a-frame','Sampling frame：这24张底片的最新馆藏编号清单。','每个编号唯一且资料最新，可作为抽取单位的入口。'),p('Population写完整对象；frame写清单。原创评价要点各1分，不把“24”单独当完整总体定义。'))
E1+=six('e1b','Checking a negative for a digital catalogue causes no damage and takes one minute. (b) Give one reason why a census is practical. (1)','为数字目录检查一张底片不会损伤它，耗时一分钟。(b) 给出普查可行的一条理由。(1)',p('不损伤、每张一分钟和总共24张，是本问用得到的限制。'),p('Give one reason要求用本情境评价可行性；罗列所有调查方法不会增加这条理由的支持。'),p('第一章③把资源和检查性质放进census选择。'),p('总时间等于单位数乘每单位所需时间，前提是逐张检查且每张确实一分钟。'),line('e1b-time-sub','<mtext>总检查时间</mtext>'+op('=')+num(24)+op('×')+num(1),'代入24张与每张1分钟，结果的单位为分钟。',operation='substitute time factors')+line('e1b-time','<mtext>总检查时间</mtext>'+op('=')+num(24),'计算24乘1；只需24分钟且不损伤底片。',before='24×1',operation='multiply'),p('一条可用理由：总体只有24张，全部检查耗时较少，所以census实际可行。原创评价1分；“普查永远准确”不由题面保证。'))
SURVEY+=act(4,'完整例题：小而可接触的总体',E1)
SURVEY+=act(5,'从一条名册记录倒着看',p('拿一条馆藏编号往回找：若它找不到实际底片，问题出在frame与population的对应；若底片找得到却没被选中，它只是没进这次sample。这个反向检查用的仍是③建立的四个层次。'))
SURVEY+=act(6,'覆盖全体也有测量边界',p('Census消除了“只选一部分”带来的抽样波动，不能同时消除题目问错、记录错或漏计。ONS的覆盖估计说明其现实工作也要处理漏计与重复计数；这是一条具体限制，不是对普查价值的否定。<a href="#source-ons">S3</a>'))
SURVEY+=act(7,'回到后面的任务',p('本对象供Q1(a)辨认总体与框、Q1(b)选择调查办法使用。'))
STAT=act(1,'已有读数还缺什么',p('仪器给出三个电池读数，所有数值都在纸上。算它们的平均可以完成；若要求平均再减去“所有电池的真实平均寿命”，纸上三次读数通常不给出那个总体量。两条式子都碰到了样本，但它们所需输入并不相同。'))
STAT+=act(2,'定义来自可实际计算的要求',p('Pearson的S2考纲4.2列出statistic及其sampling distribution；2013官方样卷评分采用“只由已知样本数据计算”来识别statistic。本课用这个可计算要求拆解定义，不声称已经核实这个术语的首创人物与年代。<a href="#source-spec">S1</a> <a href="#source-statistic">S4</a>'))
stbody=p('<strong>统计量（statistic）</strong>是一项只从样本观测和已知常数计算出的量。它的计算规则不含未知总体参数（unknown population parameters）。下面把每个限制落实到手边的数据。')
stbody+='<table><thead><tr><th>定义里的内容</th><th>如何检查</th></tr></thead><tbody><tr><td>A quantity</td><td>输出是一个量，如mean、最大值或极差；样本清单本身是输入。</td></tr><tr><td>Calculated</td><td>说明运算规则，换一个样本仍用同一条规则。</td></tr><tr><td>Observations in a sample</td><td>输入来自这次实际观测；X₁、X₂、X₃分别对应已观察的三个位置。</td></tr><tr><td id="stat-only">Only</td><td>逐个检查公式中的量：除观测外，是否还需要某个未知总体值？若需要，就不能仅凭样本完成计算。</td></tr><tr><td id="stat-unknown">Unknown parameters</td><td>总体参数是描述整个总体的固定数值。μ读作mu，常表示总体mean；本例即全部对象数值的平均。总体确定时μ已固定，样本未必给出它的数值；题面标作未知时，计算仍缺这个输入。</td></tr><tr><td id="stat-fixed">已知常数与n</td><td>固定样本量n读作“样本中的观测数”。n已知，3也已知，用这些数不引入未知参数；只取第一观测也可形成statistic。</td></tr></tbody></table>'
stbody+=p('实用检验是把公式当作一张输入清单：每遇到一个符号就问它的数值从哪里来。全部来自观测或已知常数，规则可以运行；碰到一个未知总体参数，计算就会在那里停下。这里检验“能否仅从样本算出”，还没有判断“它是不是好的总体估计”。')
stbody+=textline('stat-before-after','抽样之前，statistic的值会随将来抽到的样本而变；样本观测完成后，这次计算得到一个确定数值。','同一个计算规则可作用在许多不同样本上，所以谈它的分布时要保留抽样前的随机性。')+mount('stat-check')
STAT+=act(3,'把only展开成一份输入清单',stbody)
e2en='A temperature sensor gives three readings, 18, 21 and 19 degrees Celsius. The population mean temperature mu is unknown. (a) Calculate the range of the readings and explain why it is a statistic. (3) (b) Explain whether the range minus mu is a statistic. (1)'
e2zh='温度探头给出三个读数18、21、19摄氏度。总体平均温度μ未知。(a) 计算这些读数的极差，并解释它为什么是统计量。(3) (b) 解释极差减μ是否为统计量。(1)'
E2=total('e2',e2en,e2zh)
E2+=six('e2a','A temperature sensor gives three readings, 18, 21 and 19 degrees Celsius. (a) Calculate the range of the readings and explain why it is a statistic. (3)','温度探头给出三个读数18、21、19摄氏度。(a) 计算这些读数的极差，并解释它为什么是统计量。(3)',p('三个readings是这次sample的观测，单位为摄氏度；range是最大观测与最小观测的差。先明确range的含义，才能选择计算。'),p('Calculate和explain分别要数值与定义依据。题问跨度，用mean计算中心不能代替range。'),p('第二章③的only检验：最大值、最小值都能从这三个观测中找到。'),p('极差R等于样本最大值减样本最小值；取最大与最小不需要总体参数。'),line('e2-range-rule','<mi>R</mi>'+op('=')+'<mtext>样本最大值</mtext>'+op('−')+'<mtext>样本最小值</mtext>','这是range的定义，两个值取自同一样本。',objectId='R')+line('e2-max','<mtext>样本最大值</mtext>'+op('=')+num(21),'逐个比较18、21、19，21不小于另外两个值。',operation='compare observations',objectId='R')+line('e2-min','<mtext>样本最小值</mtext>'+op('=')+num(18),'逐个比较18、21、19，18不大于另外两个值。',operation='compare observations',objectId='R')+line('e2-range-sub','<mi>R</mi>'+op('=')+num(21)+op('−')+num(18),'将样本最大值和最小值代入定义。',before='max-min',operation='substitute extrema',objectId='R')+line('e2-range-result','<mi>R</mi>'+op('=')+num(3),'计算21减18，极差为3摄氏度。',before='21-18',operation='subtract',objectId='R'),p('Range为3摄氏度，规则只用样本观测，所以是statistic。原创评价：取对极值1分，差值1分，只用样本且无未知参数的理由1分。'))
E2+=six('e2b','The population mean temperature mu is unknown. (b) Explain whether the range minus mu is a statistic. (1)','总体平均温度μ未知。(b) 解释极差减μ是否为统计量。(1)',p('unknown明确说μ没有给出。range已由样本算出，不能由“range已知”推出整个差值已知。'),p('Explain要检查所需输入；不用猜一个μ做近似，因为题目没有允许替换未知量。'),p('第二章③的only与unknown parameters两项。'),p('把range的已知值代入后，若仍留下未知参数，表达式仍不能只由样本算出。'),line('e2b-sub','<mi>R</mi>'+op('−')+'<mi>μ</mi>'+op('=')+num(3)+op('−')+'<mi>μ</mi>','只替换已计算的R，μ按题面仍未知。',before='R-mu',operation='substitute known range',objectId='R-mu')+textline('e2b-input','这个结果仍需要μ的数值。','样本读数给出了R，却没有给出整个总体的mean。'),p('不是statistic，因为计算规则包含未知总体参数μ。原创评价1分落在这个具体理由。'))
STAT+=act(4,'完整例题：极差能算，未知参数还不能用',E2)
STAT+=act(5,'从输出倒查算法的输入',p('看到“极差减3”，可以倒着问这个3从哪里来：若题目给定它是已知校准常数，运算仍可完成。看到“极差减未知μ”，同样倒查就会找到缺失输入；外形相似不改变输入条件。'))
STAT+=act(6,'规则与分布分别检查',p('一个statistic不必使用每个观测，也不必先证明是无偏估计。还要分清规则和分布：例如样本中的成功次数只用样本，所以是statistic；它出现各种次数的概率可以依赖总体成功概率p。定义排除的是计算规则中的未知参数，没有排除分布含有总体参数。'))
STAT+=act(7,'回到后面的任务',p('本对象供Q2(a)、Q2(b)判断可计算性，并让Q3与Q4的统计量含义保持明确。'))
DIST=act(1,'会算一次mean，还不知道它怎样出现',p('A→B的mean为3已经算出。换成另一条路径，mean可能改变；换了路径也可能仍得到同一个mean。要比较mean5与mean1出现的机会，需要把所有可能样本如何流向输出算清。这是开场问题还缺的部分。'))
DIST+=act(2,'所追踪的对象从样本移到统计量',p('Pearson把“statistic及其sampling distribution”并列在S2考纲4.2，并在教材第6章安排为第三节。这里的数学构造只使用有限样本空间与互斥事件的可加性：把已知路径的概率送到它产生的统计量。范围出处是<a href="#source-spec">S1</a>，章节位置是<a href="#source-book">S2</a>；下面给出本课自己的完整证明，未把这个证明归给未经核实的首创者。'))
rules=p('样本空间（sample space）是本机制全部允许结果的集合；一条有序路径就是一个完整结果。A→B与B→A分别表示第一抽A/第二抽B和第一抽B/第二抽A。顺序在记录里不同，即使mean相同，仍是两个结果。')
rules+=textline('dist-event','事件（event）是一些允许结果组成的集合。','例如“第一抽A”包括所有以A开头的允许路径；“mean为5”包括所有输出5的允许路径。')
rules+=textline('dist-exclusive','不同完整路径互斥（mutually exclusive）：一组两次抽样不能既是AB又是BA。','因此给几个不同路径相加不会重复计算同一组抽样。对互斥事件，整体概率等于各部分概率之和。')
rules+=p('∩读作“交”，这里表示两事件同时发生；∪读作“并”，表示至少一个发生。竖线“|”读作“给定”。为了看清路径权重，先用E表示“第一抽某个指定身份”，F表示“第二抽某个指定身份”。这些事件字母和后文筹码身份F不是同一个对象；本段结束后路径仍直接用身份说明。')
pe='<mi>P</mi>'+op('(')+'<mi>E</mi>'+op(')');pf='<mi>P</mi>'+op('(')+'<mi>F</mi>'+op('|')+'<mi>E</mi>'+op(')');joint='<mi>P</mi>'+op('(')+'<mi>E</mi>'+op('∩')+'<mi>F</mi>'+op(')')
rules+=line('dist-positive',pe+op('>')+num(0),'条件事件E有正概率，才能在它发生的范围内重新计算比例。',objectId='probability',operation='state denominator condition')
rules+=line('dist-conditional-definition',pf+op('=')+rawfrac(joint,pe),'给定E后，只把E的全部机会当作新的整体；同时属于E和F的机会占这个整体的比例，定义为条件概率。',objectId='probability',operation='define conditional probability')
rules+=line('dist-conditional-multiply',pf+op('×')+pe+op('=')+rawfrac(joint,pe)+op('×')+pe,'等式两边同乘正数P(E)，等式仍成立。',before='P(F|E)=P(E∩F)/P(E)',objectId='probability',operation='multiply both sides by nonzero probability')
rules+=line('dist-product-cancel',pf+op('×')+pe+op('=')+joint,'右边分母P(E)与乘上的P(E)相消；可相消的依据是P(E)>0。',before='P(F|E)P(E)=[P(E∩F)/P(E)]P(E)',objectId='probability',operation='cancel nonzero factor')
rules+=line('dist-product-rule',joint+op('=')+pe+op('×')+pf,'把等式两侧交换，再用乘法交换律把先后事件的因子顺序排好；这只是同一关系的对称写法。',before='P(F|E)P(E)=P(E∩F)',objectId='probability',operation='symmetric equality and commute factors')
# Split the two genuine rewrites so no combined operation remains.
ledger.pop();rules=rules[:rules.rfind('<div class="math-line" id="dist-product-rule"')]
rules+=line('dist-product-symmetric',joint+op('=')+pf+op('×')+pe,'等式左右交换仍成立。',before='P(F|E)P(E)=P(E∩F)',objectId='probability',operation='symmetric equality')
rules+=line('dist-product-rule',joint+op('=')+pe+op('×')+pf,'两个实数相乘满足交换律，把第一事件概率放在前面。',before='P(E∩F)=P(F|E)P(E)',objectId='probability',operation='commute multiplication factors')
rules+=line('dist-independent',pf+op('=')+'<mi>P</mi>'+op('(')+'<mi>F</mi>'+op(')'),'若两次抽取独立，给定第一抽不会改变第二抽机会；这是独立在此处所提供的内容。',objectId='probability',operation='apply independence')
rules+=p('本例有放回还明确独立，因此每个指定身份在每次的机会都是三分之一。无放回时，从剩下身份中计算第二因子，不能使用独立那一步。下面先做放回全部路径，再重建无放回，二者共享计算规则但使用不同样本空间。')
rules+=derivation('main-wr-mean-v1')
rules+=p('现在才给这份完整“输出与概率”对应命名：统计量的抽样分布（sampling distribution of a statistic）。每次先取一个样本，再算同一个statistic；把所有样本的可能性归并后，得到它的全部取值与各自概率。单次样本的mean是一个数，这份分布描述按同一机制取样时那个数如何变化。')
rules+=p('改为无放回时，第一抽仍从A/B/C三枚中均匀选。给定第一抽是A，剩下的是B/C；它们均匀分到第二抽的机会。A已经不在袋内，A→A就不能发生。若先抽B或C，也各自列出剩余身份，不能只删路径而保留原概率。')
rules+=derivation('main-wo-mean-v1')
DIST+=act(3,'有序路径、映射与概率归并完整构造',rules)
e3en='Two labelled switches K and L have delays 0 ms and 2 ms respectively. A switch is selected uniformly at random, replaced, and a second independent uniform selection is made. Let T be the maximum of the two observed delays. (a) Find the sampling distribution of T. (5)'
e3zh='两个带身份的开关K、L的延迟分别为0毫秒和2毫秒。均匀随机选一个开关，放回后再独立均匀选一次。T是两个观察延迟的最大值。(a) 求T的抽样分布。(5)'
E3=total('e3',e3en,e3zh)+six('e3a',e3en,e3zh,p('“uniformly”使两个身份的每次机会相同；“replaced”和“independent”使第二次仍用原机会。maximum由两个观察延迟中较大的一个决定，单位毫秒。'),p('Find the sampling distribution要求列出全部T值和概率。总体只有两个身份，完整枚举四条路径能直接验证；随机模拟只给样本频率，不会给这里要求的精确理论概率。'),p('第三章③已经建立路径乘法、相同输出原像及互斥相加。改变的是路径送往哪个输出。'),p('这里使用T=max(X₁,X₂)。先比较两值而不求平均；随后对相同maximum的互斥路径相加。'),derivation('example-wr-maximum-v1'),p('完整分布：T为0毫秒的概率四分之一，为2毫秒的概率四分之三，其余为零。原创评价：四条有序路径1分，maximum映射1分，路径权重1分，归并1分，完整分布1分。'))
DIST+=act(4,'完整例题：把同一条路径送到maximum',E3)
DIST+=act(5,'从一个输出倒着寻找来源',p('主例有放回的输出5，可以倒着找到AC、BB、CA三个原像。正向计算回答“这条路径得到什么”，反向收集回答“这个输出由哪些路径产生”；两种方向共同使用③已建的同一对应。'))
DIST+=act(6,'改变机制就重新检查概率',p('“随机”单独一词不充分规定本课用的每条路径权重；这里把均匀和独立写明。无放回时还要说明第二抽在剩余身份中均匀。不同身份即使写着同一个数，也不能被合成一枚实物。图中每根柱高是精确概率，未运行抽样模拟，也不能把一张理论图当作真实抽样频率。'))
DIST+=act(7,'回到后面的任务',p('本对象供Q3(a)、Q3(b)构造两种机制的mean分布，并供Q4重新收集maximum为5的原像。'))
# Lower half, ordered independently, each subquestion keeps all six responsibilities.
q1en='A library has 2400 physical books on 1 September. The current accession register lists each copy with a unique number. A sample of 60 books is selected from this register. (a) Identify the population, sampling unit, sampling frame and sample. (4) (b) Checking the binding requires removing and reattaching the spine of each selected book. Give one advantage and one disadvantage of a sample survey rather than a census. (2)'
q1zh='9月1日，一所图书馆有2400本实体书。最新馆藏登记簿为每一本复本列出唯一编号；从这份登记簿中选出60本作为样本。(a) 指出总体、抽样单位、抽样框和样本。(4) (b) 检查装订需要对每本被选中的书拆下再装回书脊。给出抽样调查相较普查的一项优点和一项缺点。(2)'
Q1=total('q1',q1en,q1zh)
Q1+=six('q1a','The current accession register lists each copy with a unique number. A sample of 60 books is selected from this register. (a) Identify the population, sampling unit, sampling frame and sample. (4)','最新馆藏登记簿为每一本复本列出唯一编号；从这份登记簿中选出60本作为样本。(a) 指出总体、抽样单位、抽样框和样本。(4)',p('2400本限定研究的完整集合，日期限定库存时点。each copy使同名复本保持不同身份；from this register指出选择入口。60是这次实际取出的样本规模。'),p('Identify要求把四个术语分别落到情境对象。先求60占2400的百分比只能描述取样比例，不能替代这些身份。'),p('第一章③的四层：想描述的集合、每次取的单位、取样入口、实际抽取部分。'),p('按各定义逐项匹配；这是概念归属，没有必要制造数值推导。'),textline('q1a-pop','Population：9月1日图书馆的2400本实体书。','范围由研究时点、地点和实体对象共同限定。')+textline('q1a-unit','Sampling unit：一本有唯一馆藏编号的实体书。','每次抽取和检查发生在单本复本上。')+textline('q1a-frame','Sampling frame：最新馆藏登记簿中的全部复本编号。','取样从此清单发起。')+textline('q1a-sample','Sample：被选出的60本书。','它们是本次真正选入的数据来源，不等于全库。'),p('四个对象各1分，共4个原创评价要点。frame写“登记簿”而非“60本”，sample写“这次选出的60本”。'),'q1a-answer')
Q1+=six('q1b','(b) Checking the binding requires removing and reattaching the spine of each selected book. Give one advantage and one disadvantage of a sample survey rather than a census. (2)','(b) 检查装订需要对每本被选中的书拆下再装回书脊。给出抽样调查相较普查的一项优点和一项缺点。(2)',p('requires说明这项处理是每个被检查单位都要承担的步骤。sample与census比较时，总体和检查任务保持相同，只改变检查多少单位。'),p('Give one advantage and one disadvantage要求两面情境理由；单说抽样“更好”没有说明代价，也无法回答缺点。'),p('第一章③的资源与破坏性权衡，第一章⑥的误差边界。'),p('检查范围小可减少需要拆装的书；但只看部分书，结果会随样本改变。两句话分别讨论操作成本与统计不确定性。'),textline('q1b-benefit','抽样只需拆装被选中的60本，更多书可保持原状，也减少检查工作。','普查要对2400本都做相同处理；少处理单位通常降低成本与损伤风险。')+textline('q1b-cost','样本中的损坏情况可能与全库不同，换一组书可能得到不同结果。','未观察全部总体，样本选择带来抽样波动；这也是需要sampling distribution的原因。')+textline('q1b-limit','即使登记簿完整，也不能保证每个样本恰好代表全库。','框完整支持选择机会的覆盖，不消除随机样本间差别。'),p('原创评价：联系拆装成本/保存实物的优点1分；联系部分观察或抽样波动的缺点1分。不能把普查说成没有任何错误。'),'q1b-answer')
q2en='Three battery lifetimes X1, X2 and X3 are observed. The sample size is fixed at 3. The population mean mu is unknown. Let A be the first observed lifetime plus 3 hours, and let B be the sample mean minus mu. (a) Explain whether A is a statistic. (1) (b) Explain whether B is a statistic. (1)'
q2zh='观察三个电池寿命X₁、X₂、X₃，固定样本量为3；总体平均寿命μ未知。A是第一个观察寿命加3小时，B是样本平均减μ。(a) 解释A是否为统计量。(1) (b) 解释B是否为统计量。(1)'
Q2=total('q2',q2en,q2zh)
Q2+=six('q2a','Let A be the first observed lifetime plus 3 hours, and let B be the sample mean minus mu. (a) Explain whether A is a statistic. (1)','A是第一个观察寿命加3小时，B是样本平均减μ。(a) 解释A是否为统计量。(1)',p('first observed lifetime是已观察的第一个数；3 hours是已知固定常数，量纲与寿命相同。只用一个观测是否允许，是本问要检查的限定。'),p('Explain whether要依据定义给结论。不需要其余两个观测的具体数值，也不需要检验它是否准确估计总体mean。'),p('第二章③的输入清单和第二章⑥：statistic不要求使用全部观测。'),p('A的计算规则只需要X₁和已知常数3；两个输入都已给，不含未知参数。'),line('q2a-expression','<mi>A</mi>'+op('=')+var('x1')+op('+')+num(3),'将文字“第一观测加3小时”写成计算规则；3是已知常数。',operation='translate rule',objectId='A')+textline('q2a-input-one','X₁来自样本中的第一次观测。','即使未用X₂、X₃，已用的数据仍完全来自样本。')+textline('q2a-input-three','3小时已知，不是未知总体参数。','only限制额外未知输入，不排除固定常数。'),p('A是statistic。原创评价1分：理由需要指出仅用样本观测与已知常数；“用了所有三个观测”不符合这条规则的实际情况。'),'q2a-answer')
Q2+=six('q2b','The population mean mu is unknown. Let A be the first observed lifetime plus 3 hours, and let B be the sample mean minus mu. (b) Explain whether B is a statistic. (1)','总体平均寿命μ未知。A是第一个观察寿命加3小时，B是样本平均减μ。(b) 解释B是否为统计量。(1)',p('unknown使μ仍是缺少的总体输入。mean使用固定样本量3，因此求样本mean本身没有缺少样本量。'),p('本问辨认计算规则，不要求计算未知μ。把μ换成样本mean会改变题中B的定义。'),p('第二章③的only及第二章④E2(b)的未知参数检查。'),p('先将样本mean展开成三观测之和除以3，再逐符号核输入。'),line('q2b-expression','<mi>B</mi>'+op('=')+rawfrac(var('x1')+op('+')+var('x2')+op('+')+'<msub><mi>X</mi><mn>3</mn></msub>',num(3))+op('−')+'<mi>μ</mi>','用三项平均的定义展开sample mean；μ保留未知。',operation='expand sample mean',objectId='B')+textline('q2b-known','三个X与分母3均可由这次样本取得。','固定样本量的计数是已知信息。')+textline('q2b-unknown','减去的μ仍需要总体平均寿命。','题面明确没有给出这个参数，样本mean不能作为它的精确替身。'),p('B不是statistic，因为规则含未知总体参数μ。原创评价1分落在这一限定；并不因式子也使用了样本就自动成立。'),'q2b-answer')
q3en='A bag contains three distinct labelled counters D, E and F with values 2, 2 and 8. In each experiment two observations are taken in order. Let T be their mean. (a) Each selection is uniform; the first counter is replaced and the second selection is independent. Construct the full sampling distribution of T. (6) (b) Instead, take the two counters without replacement, uniformly from the counters remaining at each stage. Construct the full sampling distribution of T. (6)'
q3zh='袋中有三枚不同身份的筹码D、E、F，其值分别为2、2、8。每次试验按顺序取两个观测，T是它们的mean。(a) 每次均匀抽取；第一枚放回，第二抽独立。构造T的完整抽样分布。(6) (b) 改为无放回，每一步都从尚余筹码中均匀抽取。构造T的完整抽样分布。(6)'
Q3=total('q3',q3en,q3zh)+p('这份新数据保留已学方法，同时增加一个判断：D和E虽然都写2，仍是两枚不同的实物。下面的一份构造板分别保存(a)与(b)草稿；统一提交后才逐组核对。两个小问各有完整六项讲解。')+mount('build-sample')
Q3+=six('q3a','(a) Each selection is uniform; the first counter is replaced and the second selection is independent. Construct the full sampling distribution of T. (6)','(a) 每次均匀抽取；第一枚放回，第二抽独立。构造T的完整抽样分布。(6)',p('distinct labelled counters意味着D与E不合并成一个身份；它们数值相同只会影响映射。two observations in order要求保留顺序。replaced及independent允许第二次仍从全体独立均匀选。'),p('Construct full distribution要求路径、映射、权重和归并全部闭合。先把2与8当成两个等可能数，会忽略数值2来自两个身份，因此不能作为本题的起点。'),p('第三章③从身份路径开始，而非从去重后的数值开始；第二章的T规则只用两个观测。'),p('对每条允许路径用条件乘法；因独立放回可取两次各三分之一。T用两数之和除以2，相同T的互斥路径相加。'),derivation('task-wr-mean-v1'),p('完整分布：mean2与mean5各九分之四，mean8为九分之一，其余为零。原创评价：完整身份路径2分、映射1分、权重1分、原像归并与完整分布2分。D→E与E→D都留在mean2原像。'))
Q3+=six('q3b','(b) Instead, take the two counters without replacement, uniformly from the counters remaining at each stage. Construct the full sampling distribution of T. (6)','(b) 改为无放回，每一步都从尚余筹码中均匀抽取。构造T的完整抽样分布。(6)',p('Instead改变抽样机制，筹码与mean规则保持不变。remaining限定第二抽只能从未取走的实物中选；D抽走后E仍在，即使它们值相同。'),p('机制改变需要同时改允许路径与第二因子。只从(a)删掉DD/EE/FF而保留九分之一，会使总概率少于一，不能构成完整分布。'),p('第三章③无放回重建的“剩余身份→条件概率→新权重”链；Q3(a)的数值相同身份不同判断继续适用。'),p('路径乘法本身不要求独立：第一抽各三分之一；给定第一抽，剩余两身份第二抽各二分之一。mean公式不变。'),derivation('task-wo-mean-v1'),p('完整分布：mean2为三分之一，mean5为三分之二，mean8为零，其余为零。原创评价：排除同身份且保留DE/ED共2分、映射1分、新权重1分、归并与归一化2分。'))
q4en='Three distinct labelled cards G, H and J have values 1, 5 and 9. Draw one card uniformly, replace it, then make a second independent uniform draw. T is the maximum of the two values. Find all ordered paths giving T=5 and hence find P(T=5). (4)'
q4zh='三张不同身份的卡G、H、J分别写1、5、9。均匀抽一张，放回后再次独立均匀抽取。T为两个值的maximum。找出所有使T为5的有序路径，并由此求T为5的概率。(4)'
Q4=total('q4',q4en,q4zh)+six('q4',q4en,q4zh,p('本题的maximum已经在E3学过；新的中间目标是5，另有一个更大数9。最大值恰5要求两次都不超过5，同时至少一次等于5。'),p('“all ordered paths”让原像成为要交出的中间对象，hence要求用这些路径归并概率。只给最后分数无法证明找对了原像：本数据mean5和maximum5可能恰好得到同一个概率。'),p('第三章④E3的最大值映射，与第三章③的互斥原像相加。'),p('先排除含J的路径，因为任何9都会把maximum推到9；在剩下G/H路径里排除GG，因为其maximum是1。'),derivation('challenge-wr-maximum-v1'),p('目标原像为GH、HG、HH，概率三分之一。原创评价：无J且至少一个H的判断1分，完整原像1分，每条权重1分，归并概率1分。这一题只核本次原像判断，不据一次选对声称广泛迁移。'),'q4-answer')
# Short recall pauses and purposeful path/condition choices sit inside the proof.
def inspect_button(label,k,path,stage,back):
 return '<button type="button" data-action="inspect-path" data-condition="'+k+'" data-path="'+path+'" data-stage="'+stage+'" data-back="'+back+'">'+label+'</button>'
def proof_pause(id,question,answer,buttons):
 return '<aside class="proof-pause" id="'+id+'"><p>'+question+'</p>'+buttons+details(id+'-recall','先在心中回答，再翻开这张短卡',p(answer))+'</aside>'
DIST=DIST.replace('<div class="math-line" id="main-wr-AB-weight-sub"',proof_pause('pause-weight','已经算出AB的mean。它这条路径的机会来自哪两个阶段？可以翻卡核对，也可以选择反向路径比较。','第一次选A的机会为1/3。放回且独立后，第二次选B的机会仍是1/3。两阶段按条件乘法相乘；BA具有不同顺序，但本机制两因子相同。',inspect_button('选择AB的映射图','main-wr-mean-v1','AB','mapping','pause-weight')+inspect_button('改成反向BA','main-wr-mean-v1','BA','mapping','pause-weight'))+'<div class="math-line" id="main-wr-AB-weight-sub"')
DIST=DIST.replace('<h4 id="main-wr-grouping">',proof_pause('pause-preimage','先暂时固定输出5。哪些路径会汇到这里？可以从不同路径进入同一张概率图。','AC、BB、CA都得到mean5。它们是三个互斥样本；每条的1/9相加成3/9，再约成1/3。输出的机会取决于它接到哪些路径。',inspect_button('从AC查看归并','main-wr-mean-v1','AC','bars','pause-preimage')+inspect_button('从BB查看归并','main-wr-mean-v1','BB','bars','pause-preimage'))+'<h4 id="main-wr-grouping">')
DIST=DIST.replace('<div class="condition-proof" data-condition="main-wo-mean-v1">',proof_pause('pause-mechanism','第一枚取走后，第二抽的分母需要怎样改变？选择同一AB路径的两种机制，比较图中的条件。','无放回且从尚余身份均匀选时，给定第一抽A，第二抽只剩B和C，所以第二因子为1/2。第一因子仍为1/3，路径概率为1/6；只删掉AA/BB/CC而沿用1/9会缺失总概率。',inspect_button('AB：有放回','main-wr-mean-v1','AB','bars','pause-mechanism')+inspect_button('AB：改为无放回','main-wo-mean-v1','AB','bars','pause-mechanism'))+'<div class="condition-proof" data-condition="main-wo-mean-v1">')
# Final assembly uses only this freshly authored source and approved generic builder.
import base64, importlib.util
manifest=json.loads((R/'media-manifest.json').read_text())
frames=[]
for f in manifest['frames']:
 z=dict(f);path=z.get('relativePath') or z.get('path');z['url']='data:image/png;base64,'+base64.b64encode((R/path).read_bytes()).decode();frames.append(z)
def static_graph(key):
 f=next(f for f in frames if f['conditionKey']==key and f['stageId']=='bars' and not f.get('selectedPathId'))
 return '<figure class="manim-static" data-frame-id="'+f['frameId']+'"><img class="manim-frame" src="'+f['url']+'" alt="'+esc(C[key]['conditionText'])+'的精确抽样分布；横轴为T的数值，纵轴为概率。"><figcaption>真实Manim静图。横轴按数值距离排布；空心点表示概率0。柱高以图中分数为准。</figcaption></figure>'
# Examples are continuous, while current lower exercises retain freely opened local solutions.
for name in ['SURVEY','STAT','DIST']:
 globals()[name]=re.sub(r'<details id="(e[^\"]+-solution)"',r'<details open id="\1"',globals()[name])
# Place a dedicated graph within each relevant solution; no task result enters the construct controls.
DIST=DIST.replace('<div id="e3a-answer">',static_graph('example-wr-maximum-v1')+'<div id="e3a-answer">')
Q3=Q3.replace('<div id="q3a-answer">',static_graph('task-wr-mean-v1')+'<div id="q3a-answer">').replace('<div id="q3b-answer">',static_graph('task-wo-mean-v1')+'<div id="q3b-answer">')
Q4=Q4.replace('<div id="q4-answer">',static_graph('challenge-wr-maximum-v1')+'<div id="q4-answer">')
def distribution_table(key):
 c=C[key];return '<table><caption>'+esc(c['conditionText'])+'</caption><thead><tr><th>T</th><th>允许原像</th><th>概率</th></tr></thead><tbody>'+''.join('<tr><th>'+math(val('stat',b['value']))+'</th><td>'+(', '.join(b['pathIds']) or '空集')+'</td><td>'+mt(b['probability'])+'</td></tr>' for b in c['bars'])+'</tbody></table>'
MAINREF=details('main-reference','直接查看A/B/C两种机制的完整分布参考',distribution_table('main-wr-mean-v1')+distribution_table('main-wo-mean-v1')+p('此处同时呈现两种机制答案。每条路径的条件概率、代入与归并完整推导见第三章③；<a href="#main-wr-paths">有放回逐行推导</a>，<a href="#main-wo-paths">无放回逐行推导</a>。'))
SHARED=details('shared-task-solutions','同时查看D/E/F两机制分布参考',distribution_table('task-wr-mean-v1')+distribution_table('task-wo-mean-v1')+p('<a href="#q3a-work">有放回全步骤</a> · <a href="#q3b-work">无放回全步骤</a>'))
INTRO+=MAINREF
Q3+=SHARED
coverage=[]
for rid,k in [('pause-weight-recall','main-wr-mean-v1'),('pause-preimage-recall','main-wr-mean-v1'),('pause-mechanism-recall','main-wo-mean-v1')]:
 coverage.append({'sourceId':rid,'componentId':'main-map','conditionKey':k,'selector':'#'+rid,'kind':'reference','lineIds':[],'targets':['5'] if rid=='pause-preimage-recall' else []})
for k in ['main-wr-mean-v1','main-wo-mean-v1']:
 c=C[k]
 for b in c['bars']:
  for row in [x for x in ledger if x['lineId']==b['lineId'] or x['lineId'].startswith(b['lineId']+'-')]:
   lid=row['lineId'];coverage.append({'sourceId':lid,'componentId':'main-map','conditionKey':k,'selector':'#'+lid,'kind':'presented','lineIds':[lid],'targets':[str(b['value']['n'])] if lid==b['lineId'] else []})
 coverage.append({'sourceId':'main-'+c['mechanism']+'-table','componentId':'main-map','conditionKey':k,'selector':'#main-'+c['mechanism']+'-table','kind':'presented','lineIds':['main-'+c['mechanism']+'-table'],'targets':['1','3','5','7','9']})
 coverage.append({'sourceId':'main-reference-'+c['mechanism'],'componentId':'main-map','conditionKey':k,'selector':'#main-reference','kind':'reference','lineIds':[],'targets':['1','3','5','7','9']})
 for f in frames:
  if f['conditionKey']==k:coverage.append({'sourceId':'frame-'+f['frameId'],'componentId':'main-map','conditionKey':k,'kind':'frame','lineIds':f.get('lineIds',[]),'targets':['1','3','5','7','9'] if f['stageId']=='bars' else []})
for k,qid in [('task-wr-mean-v1','q3a'),('task-wo-mean-v1','q3b')]:
 coverage.append({'sourceId':'construction-feedback-'+k,'componentId':'build-sample','conditionKey':k,'kind':'feedback','lineIds':[],'targets':['2','5','8']})
 for rid in [qid+'-solution','shared-task-solutions']:
  coverage.append({'sourceId':rid+'-'+C[k]['mechanism'],'componentId':'build-sample','conditionKey':k,'selector':'#'+rid,'kind':'reference','lineIds':[],'targets':['2','5','8']})
SOURCE={'repository':'DialogueTutor','path':'references/generation-checks.md'}
def activity(id,objective,kind,title,prompt,**kwargs):return {'id':id,'objectiveId':objective,'type':kind,'title':title,'prompt':prompt,'source':SOURCE,**kwargs}
def quiz(id,objective,title,prompt,choices,answer,explanation,solution=None):
 a=activity(id,objective,'quiz',title,prompt,format='choice',choices=[{'id':str(i),'text':x} for i,x in enumerate(choices)],answer=str(answer),explanation=explanation)
 if solution:a['solutionId']=solution
 return a
activities=[
 activity('main-map','distribution','interactive','先作判断，再让路径汇合','选择当前抽法；可以保存预测、点路径、看映射及概率图。',bodyHtml='<div id="main-map" data-course-component="main-map"><div data-condition-controls></div><div data-prediction></div><p>图中的蓝圆表示第一观测X₁，紫方表示第二观测X₂，青菱形表示T；相同数值也保留位置角色。</p><div data-path-buttons></div><div class="stage-controls"><button type="button" data-action="stage" data-stage="paths">路径</button><button type="button" data-action="stage" data-stage="mapping">代入mean</button><button type="button" data-action="stage" data-stage="bars">概率归并</button></div><div data-media></div><nav data-proof-return aria-label="返回正文推导"></nav><div data-main-outcome></div></div>'),
 activity('build-sample','distribution','interactive','D与E同值，仍要分清身份','四组只用选择，不需打字。当前草稿统一提交后才核对；本条件冻结后可重开，旧记录仍保留。',bodyHtml='<div id="build-sample" data-course-component="build-sample"><div data-condition-controls></div><div data-construction></div><div data-construction-feedback role="status"></div></div>'),
 quiz('survey-check','survey','抽样框还是总体？','馆藏名册漏了新入库的书。研究目标仍为当日所有实体书。名册是什么？',['总体，因为它是个完整列表','抽样框，但它没有完整覆盖总体','样本，因为名单上有很多书'],1,'名单是实际选择入口，因此是frame。漏项使frame不能覆盖既定population；它不会自动改变研究目标。'),
 quiz('stat-check','statistic','只用第一个数可以吗？','样本有三次观测。规则“第一个观测加已知常数3”是否为statistic？',['是，只需样本观测和已知常数','不是，因为需要用全部三次观测','不是，因为需要先知道总体mean'],0,'statistic规则只依赖样本数据和已知常数。定义不要求用全部数据，也不要求一定是平均数。'),
 quiz('q1a-answer','survey','Q1(a) 先固定研究对象','选择population / unit / frame / sample的对应。',['2400本实体书 / 一本有独立编号的书 / 最新馆藏登记簿 / 选出的60本书','已取60本 / 一个书名 / 2400本实体书 / 馆藏登记簿','馆藏登记簿 / 一行文字 / 已取60本 / 2400本书'],0,'研究目标覆盖9月1日的2400本实体书；每本复本是一个单位；登记簿提供选择入口；实际选出的60本构成样本。','q1a-solution'),
 quiz('q1b-answer','survey','Q1(b) 拆装书脊怎样权衡？','检查每本书都需拆下再装回书脊。抽样相较普查的优点和缺点怎样搭配？',['普查保证没有任何测量错误','抽样减少需拆装的书，但未直接观察全库，结果会有抽样波动','抽样必然完全代表总体，无须关注抽法'],1,'只检查60本比检查2400本减少拆装工作与损伤风险；它只观察部分书，样本结果会随所选书改变。','q1b-solution'),
 quiz('q2a-answer','statistic','Q2(a) 判断计算输入','A是第一观测加已知3小时。',['不是，使用观测太少','是，规则没有未知总体参数','不能判断，必须知道总体mean'],1,'first observed lifetime属于样本；3小时已知。两个计算输入都可取得，所以A是统计量。','q2a-solution'),
 quiz('q2b-answer','statistic','Q2(b) 未知μ在哪里？','B是样本mean减未知总体mean μ。',['是，因为式子里出现样本mean','不是，因为还需未知总体参数μ','是，因为μ写成字母就成为已知数'],1,'减去μ仍需要这个未知总体参数。仅知道样本不能算出B，违反only from known sample data的限定。','q2b-solution'),
 quiz('q4-answer','distribution','Q4 原像比最后分数更有辨别力','选择所有且仅有maximum为5的路径，并给出对应条件。',['GH、HG、HH；没有J且至少有一个H','GJ、HH、JG；两数和为10','GG、GH、HG、HH；两数都不超过5'],0,'maximum恰为5要求没有9且至少一次为5。故GH/HG/HH各有1/9，总计1/3。第二项是mean为5的原像，虽然概率也恰为1/3，判断对象已换错。','q4-solution'),
 activity('recall-core','statistic','flashcards','两张短回忆卡','先在心中回答，再翻卡；自评仅用于安排再次回忆。',cards=[{'front':'一个计算规则成为statistic，需要怎样限制它的输入？','back':'它只使用样本中的已知观测与已知常数，不能含未知总体参数。不要求用全部观测。','hint':'检查only与unknown两个限定。'},{'front':'从三个不同身份中无放回取两枚。给定第一抽之后，第二因子为什么是1/2？','back':'第一个实物已取走，尚余两个身份；题设说从尚余身份均匀选，所以各为1/2。路径权重为1/3 × 1/2。','hint':'先问还有几个可选身份，再用均匀条件。'}])]
CSS='''<style id="course-style">html{color-scheme:light}body{background:#F7F9FB;color:#202C39}main{max-width:820px;padding:24px 16px 80px}.act{margin:28px 0}.reason{color:#465467;font-size:.95rem;margin:6px 0}.math-line,.logic-line{padding:12px 0;border-bottom:1px solid #D6DEE7}.expression{overflow-x:auto;padding:4px 0}math{color:#202C39;font-size:1.16em}mstyle[data-role=x1]{color:#2364AA}mstyle[data-role=x2]{color:#7250A4}mstyle[data-role=stat]{color:#0F7074}.path-proof{margin:24px 0}.path-proof h5{font-size:1.1rem}h4{font-size:1.12rem}.stem,.total-stem{border-left:4px solid #60768C;padding:4px 12px;background:#EDF2F7}.reference{margin:20px 0}.reference>summary{cursor:pointer;min-height:44px;padding:10px 0;font-weight:650}.reference[open]>summary{border-bottom:1px solid #CBD5E1}.question{margin:32px 0}fieldset{margin:14px 0;border:1px solid #B8C5D2;padding:12px 8px}legend{font-weight:650}label{display:inline-flex;gap:8px;align-items:center;margin:5px 10px 5px 0;min-height:44px}select{max-width:100%;min-height:44px;font:inherit;color:#202C39;background:#fff}button{min-height:44px;margin:4px;padding:8px 12px;font:inherit;color:#183A61;background:#EDF4FA;border:1px solid #7997B6;border-radius:6px;cursor:pointer}button[aria-pressed=true]{background:#D9E8F5;border-width:2px}button:disabled{cursor:default;opacity:.7}button:focus-visible,a:focus-visible,select:focus-visible,input:focus-visible,summary:focus-visible{outline:3px solid #2364AA;outline-offset:3px}.dt-activity,.dt-activity-body,.dt-authored,.dt-custom,[data-course-component],[data-media],[data-displayed-group]{padding-left:0!important;padding-right:0!important;margin-left:0!important;margin-right:0!important;min-width:0}.dt-activity{border-left:0!important;border-right:0!important}.manim-frame{display:block;width:100%;max-width:600px;height:auto;margin:0 auto;border:1px solid #BCC9D6}.manim-static{margin:20px 0}.manim-static figcaption{font-size:.9rem;color:#465467}#repair-panel{background:#EDF4F5;padding:12px 0}.stage-controls{display:flex;flex-wrap:wrap}table{font-variant-numeric:tabular-nums}th,td{padding:8px 4px}a{overflow-wrap:anywhere}@media(max-width:480px){main{padding-left:16px;padding-right:16px}body{font-size:17px}.dt-custom fieldset{padding-left:4px;padding-right:4px}label{display:flex}select{width:100%}.manim-frame{max-width:none}}</style>'''
END='<div id="repair-panel" hidden></div><div id="lesson-ending-state" aria-live="polite"></div>'+p('抽样推断要先明确“选谁、怎样选”，再明确“样本怎样变成一个数”。本课的完整构造把每个输出的概率落回允许身份路径；切换抽法时，路径与条件权重都重新检查。')+mount('recall-core')
sources=json.loads((R/'source-ledger.json').read_text());source_ids={'S1':'source-spec','S2':'source-book','S3':'source-ons','S4':'source-statistic','S5':'source-exam'}
SOURCES=p('本课所有E例题与Q练习均为独立原创；英文题面是本课原文，中文为本课译文。来源只支持所标范围、定义考核与现代用途，未冒充教材原题或历史起源。')+''.join('<p id="'+source_ids[s['id']]+'"><strong>'+s['id']+'</strong> <a href="'+esc(s['url'])+'">'+esc(s['location'])+'</a>。'+esc(s['supports'])+'</p>' for s in sources)
# Alias IDs used in authored prose point to the same source entry.
for alias,target in [('source-sams','source-statistic'),('source-scope','source-spec')]:
 for name in ['INTRO','SURVEY','STAT','DIST']:globals()[name]=globals()[name].replace('#'+alias,'#'+target)
sections=[]
for id,title,body in [('opening','Sampling：同样能取到，就同样可能吗？',CSS+INTRO),('survey','一 · 从调查对象到抽样决定',SURVEY),('statistic','二 · 样本怎样成为一个统计量',STAT),('distribution','三 · 由路径造出抽样分布',DIST),('practice-survey','原创练习 Q1 · 对象与调查决定',Q1),('practice-statistic','原创练习 Q2 · 计算规则的输入',Q2),('practice-construct','原创练习 Q3 · 同值不同身份',Q3),('practice-maximum','原创练习 Q4 · 中间阈值的maximum',Q4),('lesson-ending','回到原问题与下一次回忆',END),('sources','来源与题目归属',SOURCES)]:
 sections.append({'id':id,'title':title,'bodyHtml':body,'activityIds':re.findall('data-dt-activity="([^"]+)"',body)})
# Normalize every static semantic occurrence after composition, including tables and inline formulae.
from html.parser import HTMLParser
class RoleIndex(HTMLParser):
 def __init__(self,section):
  super().__init__(convert_charrefs=False);self.section=section;self.stack=[];self.out=[];self.roles=[];self.sequence=0
 def handle_starttag(self,tag,attrs):
  attrs=dict(attrs);entry={'tag':tag,'attrs':attrs}
  if tag=='mstyle' and 'data-role' in attrs:
   self.sequence+=1;role_=attrs['data-role'];anc=[x['attrs'] for x in self.stack]
   condition=next((a['data-condition'] for a in reversed(anc) if 'data-condition' in a),'concept-'+self.section)
   path=next((a['data-path'] for a in reversed(anc) if 'data-path' in a),'')
   lid=next((a['data-line'] for a in reversed(anc) if 'data-line' in a),next((a['id'] for a in reversed(anc) if 'id' in a),self.section))
   oid=attrs.get('data-occurrence','')
   if not oid or oid.startswith('-'):oid=lid+'-'+role_+'-'+str(self.sequence)
   attrs['data-occurrence']=oid;attrs['data-line-id']=lid;attrs['data-condition-key']=condition;attrs['data-path-id']=path
   entry['role']={'conditionKey':condition,'pathId':path,'lineId':lid,'occurrenceId':oid,'operandPosition':{'x1':0,'x2':1,'stat':'output'}[role_],'objectId':attrs['data-object-id'],'role':role_,'token':attrs['mathcolor'],'text':[],'variable':False}
  if tag=='mi':
   for a in self.stack:
    if 'role' in a:a['role']['variable']=True
  self.out.append('<'+tag+''.join(' '+k+('="'+esc(v)+'"' if v is not None else '') for k,v in attrs.items())+'>')
  if tag not in ['img','br','hr','input','meta','link']:self.stack.append(entry)
 def handle_endtag(self,tag):
  self.out.append('</'+tag+'>')
  if self.stack:
   item=self.stack.pop()
   if 'role' in item:
    r=item['role'];nums=re.findall(r'-?\d+',''.join(r.pop('text')));variable=r.pop('variable');r['exact']=None if variable or not nums else {'n':int(nums[0]),'d':int(nums[1]) if len(nums)>1 else 1};self.roles.append(r)
 def handle_data(self,data):
  self.out.append(data)
  for a in self.stack:
   if 'role' in a:a['role']['text'].append(data)
 def handle_entityref(self,name):self.out.append('&'+name+';')
 def handle_charref(self,name):self.out.append('&#'+name+';')
occurrences=[]
for section in sections:
 ri=RoleIndex(section['id']);ri.feed(section['bodyHtml']);section['bodyHtml']=''.join(ri.out);occurrences.extend(ri.roles)
lesson={'schemaVersion':1,'lessonId':'s2-ch6-sampling-original-run02','revision':'2026-09-08-original-02','title':'S2 Chapter 6 · Sampling and sampling distributions','language':'zh-CN','mode':'bgct','presentation':'document','generationPolicy':'no-typing','theme':'light','objectives':[{'id':'survey','title':'明确总体、单位、框与调查权衡','kind':'concept'},{'id':'statistic','title':'只用已知样本构成计算规则','kind':'concept'},{'id':'distribution','title':'按机制建立路径并归并统计量概率','kind':'procedure'}],'activities':activities,'sections':sections}
config={'data':D,'dataHash':HASH,'frames':frames,'coverage':coverage,'mappingOptions':['0','1','2','3','4','5','6','7','8','9'],'probabilityOptions':['0','1/9','2/9','1/3','4/9','1/2','2/3','8/9','1'],'lesson':{'lessonId':lesson['lessonId'],'revision':lesson['revision'],'activities':[a for a in activities if a['type']!='interactive'],'objectives':lesson['objectives']}}
activities[0]['script']=(R/'course.js').read_text().replace('__COURSE_CONFIG__',json.dumps(config,ensure_ascii=False,separators=(',',':')))
(R/'lesson.json').write_text(json.dumps(lesson,ensure_ascii=False,indent=2)+'\n')
(R/'math-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
(R/'role-occurrences.json').write_text(json.dumps(occurrences,ensure_ascii=False,indent=2)+'\n')
(R/'reference-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('approved_builder',R.parents[1]/'repo/plugins/dialogue-tutor/skills/dialogue-tutor/scripts/build_lesson.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
(R/'lesson.html').write_text(builder.assemble(lesson))
print('Built original lesson:',len(ledger),'math/logic lines,',len(frames),'actual frames')
