from pathlib import Path
from PIL import Image
import json, hashlib, math
import numpy as np
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2]
m=json.loads((ROOT/'media-manifest.json').read_text());d=json.loads((ROOT/'exact-data.json').read_text())
qa=ROOT/'media/qa';issues=[];numeric=[]
assert len(m['frames'])==51
assert hashlib.sha256((ROOT/'sampling_scene.py').read_bytes()).hexdigest()==m['sceneSourceHash']
assert hashlib.sha256((ROOT/'exact-data.json').read_bytes()).hexdigest()==m['dataHash']
for f in m['frames']:
 fp=ROOT/f['relativePath'];assert hashlib.sha256(fp.read_bytes()).hexdigest()==f['sha256']
 im=np.asarray(Image.open(fp).convert('RGB')).astype(int)
 for ob in f['objects']:
  if ob['kind'] not in ['value','result','sum','sample-size','axis-value','probability']:continue
  if ob['stageId']=='mapping' and ob['lineId'].endswith('-definition'):continue
  x,y,w,h=ob['bboxPx'];x0=max(0,math.floor(x)-2);y0=max(0,math.floor(y)-2);x1=min(1000,math.ceil(x+w)+2);y1=min(1250,math.ceil(y+h)+2)
  col=np.array([int(ob['token'][i:i+2],16) for i in (1,3,5)])
  mask=np.max(abs(im[y0:y1,x0:x1]-col),axis=2)<32
  ys,xs=np.where(mask)
  if len(ys):
   hh=int(ys.max()-ys.min()+1);numeric.append({'frameId':f['frameId'],'occurrenceId':ob['occurrenceId'],'role':ob['role'],'kind':ob['kind'],'pixelHeight':hh,'cssAt300':round(hh*.3,2),'bboxPx':ob['bboxPx']})
 for lab in f['labels']:
  x,y,w,h=lab['bboxPx']
  if x<0 or y<0 or x+w>1000 or y+h>1250:issues.append([f['frameId'],lab['label'],'out-of-bounds'])
for c in d['conditions'].values():
 F=lambda r:Fraction(r['n'],r['d'])
 for p in c['paths']:
  assert F(p['sum'])==F(p['x1'])+F(p['x2'])
  assert F(p['stat'])==(F(p['sum'])/c['sampleSize'] if c['statistic']=='mean' else max(F(p['x1']),F(p['x2'])))
  assert F(p['weight'])==F(p['firstProbability'])*F(p['secondProbability'])
 for b in c['bars']:
  assert F(b['probability'])==sum(F(p['weight']) for p in c['paths'] if p['allowed'] and F(p['stat'])==F(b['value']))
 assert sum(F(b['probability']) for b in c['bars'])==1
sel=['main-wr-AB-paths','main-wo-overview-paths','main-wr-AB-mapping','main-wr-BB-mapping','main-wr-AC-bars','main-wo-AB-bars']
canvas=Image.new('RGB',(900,750),'#ffffff')
for i,n in enumerate(sel):
 im=Image.open(ROOT/'media/frames'/f'{n}.png').convert('RGB');small=im.resize((300,375),Image.Resampling.LANCZOS);small.save(qa/f'{n}-300px.png');canvas.paste(small,((i%3)*300,(i//3)*375))
canvas.save(qa/'phone-contact-sheet.png')
extra=['task-wr-overview-bars','task-wo-overview-bars','example-wr-overview-bars','challenge-wr-overview-bars']
extra_canvas=Image.new('RGB',(600,750),'#ffffff')
for i,n in enumerate(extra):
 small=Image.open(ROOT/'media/frames'/f'{n}.png').convert('RGB').resize((300,375),Image.Resampling.LANCZOS)
 small.save(qa/f'{n}-300px.png');extra_canvas.paste(small,((i%2)*300,(i//2)*375))
extra_canvas.save(qa/'additional-phone-contact-sheet.png')
def run_lengths(a):
 edges=np.diff(np.r_[False,a,False].astype(int));return (np.where(edges==-1)[0]-np.where(edges==1)[0]).tolist()
def stroke(fid,token,box,orientation):
 im=np.asarray(Image.open(ROOT/'media/frames'/f'{fid}.png').convert('RGB')).astype(int)
 x,y,w,h=box;col=np.array([int(d['tokens'][token][i:i+2],16) for i in (1,3,5)])
 mask=np.max(abs(im[y:y+h,x:x+w]-col),axis=2)<32
 return run_lengths(mask[:,w//2] if orientation=='vertical' else mask[h//2,:])
strokes={
 'axis-baseline':stroke('main-wr-AC-bars','muted',[625,780,1,20],'vertical'),
 'bar-outline':stroke('main-wr-AC-bars','stat',[195,710,32,1],'horizontal'),
 'fraction-line':stroke('main-wr-BB-mapping','ink',[580,604,1,26],'vertical'),
 'selected-path-border':stroke('main-wr-AB-paths','ink',[550,355,1,30],'vertical'),
 'x2-square-border':stroke('main-wr-BB-mapping','x2',[644,332,26,1],'horizontal'),
 'zero-circle-edge':stroke('main-wo-AB-bars','stat',[220,789,24,1],'horizontal')}
result={'frameCount':len(m['frames']),'hashesVerified':True,'sourceMathRecomputed':True,'labelBoundsIssues':issues,
 'numericPixelMeasurements':numeric,'minNumericPixelHeight':min(n['pixelHeight'] for n in numeric),
 'minNumericCSSAt300':min(n['cssAt300'] for n in numeric),'strokePixelRuns':strokes,
 'phonePreviewWidth':300,'previews':sel+extra,'sceneSourceHash':m['sceneSourceHash'],'dataHash':m['dataHash']}
(qa/'pixel-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='numericPixelMeasurements'},ensure_ascii=False))
