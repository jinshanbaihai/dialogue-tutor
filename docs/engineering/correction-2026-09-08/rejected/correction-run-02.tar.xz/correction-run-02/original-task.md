# 本轮可知任务与生成边界

任务由父代理/root转交；此文件保留本轮实际可知的执行目标，不冒充未提供的完整用户会话逐字稿。

用户目标为修好 DialogueTutor skill，再由独立作者从空白生成完整 bgct 数学 HTML，并经教育、游戏、色彩、叙事、程序五席审查。完整课件正式冻结后若被退回，父代理先改skill，再交另一位独立作者空白生成，不能修补被退回整课。当前生成从五席批准的run02 skill开始，唯一主写目录为generation/correction-run-02。

课题是Edexcel IAL Statistics 2 Chapter 6 Sampling and sampling distributions，含总体、普查、样本、抽样单位、抽样框及调查利弊；统计量规则只用已知样本/常数、不含未知总体参数；在明确均匀/独立或剩余均匀条件下，从有序身份路径到统计量映射，再归并同输出原像概率；比较有无放回。不是假设检验章。

交互优先、可视化其次、文字再次，含义是在完整逐行数学中自然穿插选择、回忆卡和有限点击构造。保留连续主链，不强迫每个等号都点按钮。主流程免打字；完整解法自由打开；错答、跳过和重试均能继续。每个独立教学对象七幕，各下半小问六项。新数据独立原创，禁止把官方来源虚构成教材原题或历史首创。

使用真实Manim执行Scene生成PNG，保留精确分数、Scene、帧与行身份及hash。蓝圆X1、紫方X2、青菱形T按数学出现位置传到HTML变量、代入数值与结果；普通常量保持墨色。两个核心组件各自按条件保存接触、草稿、冻结提交；覆盖即时原生summary、公开与原生文件导入导出、坏记录拒绝、媒体迟到/失败和真实回忆item。

允许使用批准的通用skill/runtime/builder、原始来源与验证过的渲染环境。禁止读取或复制过去generation/run*、correction-run-01课程、题库、Scene和组件，或repo/docs/s2-ch6.html及repo/docs/lessons。作者没有修改skill、runtime、repo/tests或进行Git提交。Manim与作者风险助手有明确独立子任务，五席终审由root组织。

预览基础设施已确认sites-previewd mailbox unavailable。没有手工服务、改端口或更换浏览器绕过。jsdom只证明原生DOM行为分支，人工Image回调只证明媒体状态分支；真实PNG目视独立记录。浏览器排版、原生MathML解码、触控、Tab、200%缩放和真人学习效果不声称通过。
