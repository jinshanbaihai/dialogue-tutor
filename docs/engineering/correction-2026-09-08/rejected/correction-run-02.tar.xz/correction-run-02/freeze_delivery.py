from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
R=Path(__file__).parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hash_html=digest(R/'lesson.html');risk=json.loads((R/'author-risk-results.json').read_text())
assert risk['complete'] is True
baseline_hash=risk['htmlSha256']
nav=json.loads((R/'author-return-navigation-recheck.json').read_text())
assert nav['htmlSha256']==hash_html and all(x['status']=='pass' for x in nav['results'])
delta=json.loads((R/'return-navigation-delta.json').read_text())
assert delta['exactBaselineReconstruction'] and delta['baselineHtmlSha256']==baseline_hash and delta['finalHtmlSha256']==hash_html
assert risk.get('selectedFilter') is None,'Needs the full suite or explicitly combined full same-hash evidence'
recheck=json.loads((R/'author-risk-recheck.json').read_text())
assert recheck['htmlSha256']==baseline_hash and recheck['complete'] is True
by_name={x['name']:x for x in risk['results']}
for row in recheck['results']:
 assert row['name'] in by_name, 'Unexpected new coverage identity'
 by_name[row['name']]=row
assert len(by_name)==len(risk['results']) and all(x['status']=='pass' for x in by_name.values())
math=json.loads((R/'math-html-check-results.json').read_text());assert math['htmlSha256']==hash_html and all(x['status']=='pass' for x in math['numericActualHtmlRows'])
static=json.loads((R/'static-audit-results.json').read_text());assert static['htmlSha256']==hash_html and not static['brokenStaticLinks'] and not static['adjacentSameExpressions']
scene=json.loads((R/'media-manifest.json').read_text());assert scene['sceneSourceHash']==digest(R/'sampling_scene.py')
for f in scene['frames']:assert digest(R/f['relativePath'])==f['sha256']
(R/'author-review.md').write_text(f'''# 本轮作者候选自检完成，等待完整独立终审

最终冻结HTML为 `{hash_html}`。下文明确区分旧候选完整套和最终候选的定向回归，不把旧hash的通过冒充新hash完整实跑。作者从本轮新目录编写数据、题面、正文、组件与Manim Scene，没有复制失败旧课。

原生DOM完整作者套在基线HTML `{baseline_hash}`运行{len(risk['results'])}项。原73项完整运行71通过、2项旧测试期望失败原样保留在author-risk-results.json。同hash定点复查保留在author-risk-recheck.json，分别核对具名项目后，完整覆盖均通过。原输入、可见DOM片段、导出状态与三种证据fixture边界均留存。具体测试脚本为author-risk-tests.cjs；测试助手独立固定题面期望，未调用作者评分器作裁判。运行历史保留测试辅助工具的MathML兼容修正、允许新提交新增真实feedback接触的期望修正、以及拒绝文案改取可见panel的说明。随后root在尚未冻结时发现正文返回链接受scroll重绘影响。最终候选只增加独立返回导航节点并改变一处写入容器；return-navigation-delta.json将这两处逆改后精确还原基线HTML hash，证明变动边界。最终候选另外实际执行{len(nav['results'])}个返回导航定向DOM回归（6按钮→scroll→当前图片回调→真实返回与焦点），全通过，记录在author-return-navigation-recheck.json。383条MathML与静态检查也重新执行于最终hash。没有声称73项完整套在最终hash重新执行。这些测试不代表五席终审通过。

数学核验包含6条件固定题面Fraction复算，以及实际最终HTML中{math['numericCount']}条数字MathML右端独立计算。另{math['symbolicLogicalCount']}行是定义、逻辑判断、条件概率的符号变换，由作者逐项阅读前提与理由；不会把它们伪报为数值执行。math-ledger.json共444行，相邻表达式没有重复同式假运算。统计量定义逐项区分已知样本/常数与未知总体参数；maximum题目实际选择原像，避免只凭相同的1/3误判。

3个教学对象各自七幕；下半Q1a/Q1b/Q2a/Q2b/Q3a/Q3b/Q4各有六项。主链连续可读，完整例题默认打开；当前练习全解可自由打开。主推导内有6个实际改变路径/阶段/机制的选择按钮和3张局部回忆卡。两个核心组件分别保存条件草稿、不可变提交和来源接触；旧反馈接触进入后续辅助判断，重试后历史反馈仍可查。

真实Manim共51帧。主例两机制同用0至1/3概率轴；新同值身份任务两机制同用0至2/3轴。15个mapping的显式selectedPathId与frame-contract一致；7张WO paths仅上移末行9源px，其余44 PNG哈希不变。色彩部件复审报告由root保存，不能代替全HTML色彩终审。作者实际查看原300px接触表与修后7张326px接触表，记录仅为PNG目视。

有效图宽配方为360−左右main各16−img边框各1=326px；所有真实媒体祖先水平padding由本课CSS重要声明清零。CSS规则核查与像素预算不冒充浏览器布局实测。受已知预览基础设施不可用限制，未验证真实浏览器排版、原生MathML呈现、图像解码、触控、Tab导航、200%缩放或真人学习效果。jsdom几何fixture只验证指定呈现范围下的分支；Image人工回调只验证真实代码的加载状态分支。

reading-record.json按真实时序记录完整主skill与必需references、原named依赖入口和适用路由。两份文风入口在作者自检阶段补读，未伪造为起草前读取；33项文风检查、8b/8c与原单字脚本实际输出均已保存。模型精确标识、温度、随机种子未暴露，见generation-context.json。

此处的稳定性证据只覆盖本次生成。完整候选冻结后若终审退回，由root先修skill，再交新的独立作者从空目录生成；本目录不补丁修改退回的完整课件。
''')
# Reproduction caches/dependencies are environment auxiliaries, not source deliverables.
paths=[p for p in R.rglob('*') if p.is_file() and not any(x in p.parts for x in ['check-deps','__pycache__','manim-cache']) and p.name!='delivery-manifest.json']
files={str(p.relative_to(R)):digest(p) for p in sorted(paths)}
manifest={'schemaVersion':1,'frozenAt':datetime.now(timezone.utc).isoformat(),'status':'whole author candidate frozen for independent five-seat review; no whole-course expert approval claimed','htmlSha256':hash_html,'baselineBehaviorChecks':len(by_name),'authorBehaviorCoverage':{'baseline':'author-risk-results.json','baselineHtmlSha256':baseline_hash,'recheck':'author-risk-recheck.json','recheckReplacesOnlySameNameSameHtmlEvidence':True,'baselineEffectivePass':sum(x['status']=='pass' for x in by_name.values()),'finalHtmlNavigationRecheck':'author-return-navigation-recheck.json','finalHtmlNavigationPass':len(nav['results']),'scopeProof':'return-navigation-delta.json','full73RerunOnFinalHtml':False},'actualNumericHtmlRows':math['numericCount'],'symbolicLogicalRows':math['symbolicLogicalCount'],'manimFrames':len(scene['frames']),'files':files,'excluded':'Python bytecode, local jieba check-deps and Manim cache; generic skill/runtime and validated render environment are external approved inputs recorded by hashes','mutationRule':'No candidate edits after this freeze; rejected complete lesson returns to root skill correction and fresh-author generation loop'}
(R/'delivery-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
core=['lesson.html','lesson.json','course.js','author.py','generation-contract.md','author-risk-tests.cjs','author-risk-results.json','author-risk-recheck.json','author-return-navigation-recheck.cjs','author-return-navigation-recheck.json','author-risk-notes.md','math-html-check-results.json','delivery-manifest.json']
print(json.dumps({k:digest(R/k) for k in core},indent=2))
