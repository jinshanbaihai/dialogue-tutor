"""Evaluate actual final HTML numeric MathML, against fixed original problem statements."""
from pathlib import Path
from fractions import Fraction as F
import json,re,ast,xml.etree.ElementTree as ET,hashlib
R=Path(__file__).parent;html=(R/'lesson.html').read_text();ledger=json.loads((R/'math-ledger.json').read_text())
# Independent original identities, values, mechanisms and statistic names.
conditions={'main-wr':({'A':1,'B':5,'C':9},True,'mean'),'main-wo':({'A':1,'B':5,'C':9},False,'mean'),'task-wr':({'D':2,'E':2,'F':8},True,'mean'),'task-wo':({'D':2,'E':2,'F':8},False,'mean'),'example-wr':({'K':0,'L':2},True,'maximum'),'challenge-wr':({'G':1,'H':5,'J':9},True,'maximum')}
expected={};origins={}
for prefix,(values,wr,stat) in conditions.items():
 mass={}
 for a,x in values.items():
  for b,y in values.items():
   v=F(x+y,2) if stat=='mean' else F(max(x,y));p=F(1,len(values)*(len(values) if wr else len(values)-1)) if wr or a!=b else F(0)
   mass[v]=mass.get(v,F(0))+p
   if p:
    for suffix in ['sub','sum','result']:expected[prefix+'-'+a+b+'-'+suffix]=v
   for suffix in ['weight-sub','weight-product','weight-numerator','weight']:expected[prefix+'-'+a+b+'-'+suffix]=p
 for v,p in mass.items():
  for suffix in ['','-add','-numerators','-count']:expected[prefix+'-bar-'+str(v)+suffix]=p
 for suffix in ['start','common','numerators','sum','one']:expected[prefix+'-mass-'+suffix]=F(1)
expected.update({'intro-sub':F(3),'intro-sum':F(3),'intro-result':F(3),'e1b-time':F(24), 'e1b-time-sub':F(24),'e1b-time-result':F(24),'e2-max':F(21),'e2-min':F(18),'e2-range-sub':F(3),'e2-range-result':F(3)})
def tag(n):return n.tag.split('}')[-1]
def expression(n):
 t=tag(n)
 if t=='mn':return n.text or ''
 if t=='mi' and n.text=='max':return 'max'
 if t=='mo':return {'×':'*','−':'-','÷':'/'}.get(n.text,n.text or '')
 if t=='mfrac':return '('+expression(n[0])+')/('+expression(n[1])+')'
 if t in ['mrow','mstyle','math']:return ''.join(expression(c) for c in n)
 raise ValueError('symbolic '+t)
def arithmetic(s):
 def visit(n):
  if isinstance(n,ast.Constant) and isinstance(n.value,int):return F(n.value)
  if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -visit(n.operand)
  if isinstance(n,ast.BinOp):
   a,b=visit(n.left),visit(n.right)
   if isinstance(n.op,ast.Add):return a+b
   if isinstance(n.op,ast.Sub):return a-b
   if isinstance(n.op,ast.Mult):return a*b
   if isinstance(n.op,ast.Div):return a/b
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='max':return max(map(visit,n.args))
  raise ValueError('non numeric operation')
 return visit(ast.parse(s,mode='eval').body)
results=[];symbolic=[]
for row in ledger:
 lid=row['lineId'];match=re.search(r'<div class="math-line" id="'+re.escape(lid)+r'"[^>]*><div class="expression">(<math.*?</math>)',html)
 if not match:
  assert row['operation']=='premise',lid+' missing numeric/symbolic line'
  symbolic.append({'lineId':lid,'review':'logical premise reviewed against original definition/context'});continue
 root=ET.fromstring(match.group(1));children=list(root[0]);eq=[i for i,n in enumerate(children) if tag(n)=='mo' and n.text=='=']
 if not eq:symbolic.append({'lineId':lid,'review':'non-numeric condition/definition'});continue
 try:rhs=''.join(expression(n) for n in children[eq[-1]+1:]);v=arithmetic(rhs)
 except (ValueError,SyntaxError):symbolic.append({'lineId':lid,'review':'symbolic formula, conditional probability definition or premise transformation; author directly reviewed operation/reason'});continue
 if lid not in expected:raise AssertionError('No independent expectation for numeric line '+lid)
 assert v==expected[lid],(lid,v,expected[lid]);results.append({'lineId':lid,'actualMathMLRightHandSide':rhs,'actual':str(v),'independentExpected':str(expected[lid]),'operation':row['operation'],'reason':row['reason'],'status':'pass'})
report={'htmlSha256':hashlib.sha256(html.encode()).hexdigest(),'numericActualHtmlRows':results,'symbolicOrLogicalRows':symbolic,'numericCount':len(results),'symbolicLogicalCount':len(symbolic),'expectationSource':'Six original fixed identity lists and E1/E2/intro statements, independently encoded here; no import of author or make_data scoring helpers'}
(R/'math-html-check-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('Actual HTML numeric MathML checked:',len(results),'symbolic/logical separate:',len(symbolic))
