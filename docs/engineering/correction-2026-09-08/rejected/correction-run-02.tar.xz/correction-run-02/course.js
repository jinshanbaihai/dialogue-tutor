(function () {
'use strict';
const CFG=__COURSE_CONFIG__, DATA=CFG.data.conditions, HASH=CFG.dataHash;
const IDS=['main-map','build-sample'];
const states={}, roots={}, loads={}; let transferReady=false, serial=0;
const clone=x=>JSON.parse(JSON.stringify(x));
const conds=id=>Object.keys(DATA).filter(k=>DATA[k].base===(id==='main-map'?'main':'task'));
const el=(tag,text,attrs={})=>{let n=document.createElement(tag);if(text!==null)n.textContent=text;Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,v));return n;};
const button=(text,action)=>el('button',text,{type:'button','data-action':action});
const frac=q=>q.d===1?String(q.n):q.n+'/'+q.d;
const mm=q=>q.d===1?'<mn>'+q.n+'</mn>':'<mfrac><mn>'+q.n+'</mn><mn>'+q.d+'</mn></mfrac>';
const role=(r,v)=>'<mstyle data-role="'+r+'" data-object-id="'+({x1:'X1',x2:'X2',stat:'T'}[r])+'" mathcolor="'+CFG.data.tokens[r]+'">'+v+'</mstyle>';
const variable=r=>role(r,r==='stat'?'<mi>T</mi>':'<msub><mi>X</mi><mn>'+(r==='x1'?1:2)+'</mn></msub>');
const math=x=>'<math xmlns="http://www.w3.org/1998/Math/MathML"><mrow>'+x+'</mrow></math>';
const value=(r,q)=>role(r,mm(q));
const pathFormula=p=>math(variable('stat')+'<mo>=</mo><mfrac><mrow>'+variable('x1')+'<mo>+</mo>'+variable('x2')+'</mrow><mn>2</mn></mfrac>')+math(variable('stat')+'<mo>=</mo><mfrac><mrow>'+value('x1',p.x1)+'<mo>+</mo>'+value('x2',p.x2)+'</mrow><mn>2</mn></mfrac>');
const probability=(v,p)=>math('<mi>P</mi><mo>(</mo>'+variable('stat')+'<mo>=</mo>'+value('stat',v)+'<mo>)</mo><mo>=</mo>'+mm(p));
function stampRoles(node,k,path,line){node.querySelectorAll('[data-role]').forEach((n,i)=>{const role=n.getAttribute('data-role');n.setAttribute('data-condition-key',k);n.setAttribute('data-path-id',path);n.setAttribute('data-line-id',line);n.setAttribute('data-occurrence',line+'-'+role+'-'+i);n.setAttribute('data-operand-position',({x1:'0',x2:'1',stat:'output'})[role]);});}
const now=()=>Date.now();
const blankDraft=()=>({paths:[],mapping:{},weight:null,distribution:{}});
function fresh(id){let s={stateVersion:1,dataHash:HASH,componentId:id,conditionKey:conds(id)[0],rounds:{},contacts:{},visibleSolutionIds:[],submissions:[]};conds(id).forEach(k=>{s.contacts[k]={};s.rounds[k]=id==='main-map'?{predictionDraft:null,activeId:null,skipped:false,pathId:null,stageId:'paths',requested:null,displayed:null,mediaStatus:'idle',pathSelections:[]}:{draft:blankDraft(),activeId:null,skipped:false};});return s;}
function dict(x){return x!==null&&typeof x==='object'&&!Array.isArray(x);}
function same(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function assert(ok,msg){if(!ok)throw new Error('本课记录未接收：'+msg);}
function keys(x,allowed,msg){assert(dict(x)&&Object.keys(x).every(k=>allowed.includes(k)),msg);}
function idtime(x){assert(typeof x==='number'&&Number.isFinite(x)&&x>0,'时间无效');}
function validDraft(d,k){
 keys(d,['paths','mapping','weight','distribution'],'草稿字段不明');const c=DATA[k],pids=c.paths.map(p=>p.id),vs=c.bars.map(b=>String(b.value.n));
 assert(Array.isArray(d.paths)&&new Set(d.paths).size===d.paths.length&&d.paths.every(p=>pids.includes(p)),'路径候选不明');
 keys(d.mapping,d.paths,'映射不是本人已选路径');Object.values(d.mapping).forEach(v=>assert(CFG.mappingOptions.includes(v),'映射候选不明'));
 assert(d.weight===null||['independent','remaining','old','equiprobable'].includes(d.weight),'权重候选不明');
 keys(d.distribution,vs,'分布输出不明');Object.values(d.distribution).forEach(v=>assert(CFG.probabilityOptions.includes(v),'概率候选不明'));
}
function checkDraft(d,k){const c=DATA[k],correct=c.paths.filter(p=>p.allowed).map(p=>p.id),missing=correct.filter(x=>!d.paths.includes(x)),extra=d.paths.filter(x=>!correct.includes(x)),mapping=d.paths.filter(x=>{const p=c.paths.find(p=>p.id===x);return p.allowed&&d.mapping[x]!==frac(p.stat);}),weight=d.weight!==(c.mechanism==='wr'?'independent':'remaining'),distribution=c.bars.filter(b=>d.distribution[String(b.value.n)]!==frac(b.probability)).map(b=>String(b.value.n));return {missing,extra,matched:d.paths.filter(x=>correct.includes(x)),mapping,weight,distribution,correct:!missing.length&&!extra.length&&!mapping.length&&!weight&&!distribution.length};}
function validate(id,s){
 keys(s,['stateVersion','dataHash','componentId','conditionKey','rounds','contacts','visibleSolutionIds','submissions'],'组件字段不明');
 assert(s.stateVersion===1&&s.dataHash===HASH&&s.componentId===id,'组件身份、版本或数学数据不匹配');assert(conds(id).includes(s.conditionKey),'条件不明');
 assert(dict(s.rounds)&&same(Object.keys(s.rounds).sort(),conds(id).sort()),'条件草稿不全');
 assert(Array.isArray(s.submissions),'提交历史无效');const seen=new Set();
 s.submissions.forEach(sub=>{keys(sub,['id','conditionKey','at','assistance','draft','check','choice'],'提交字段不明');assert(typeof sub.id==='string'&&sub.id.length>0&&!seen.has(sub.id),'提交ID重复或不明');seen.add(sub.id);assert(conds(id).includes(sub.conditionKey),'提交条件不明');idtime(sub.at);assert(Array.isArray(sub.assistance)&&sub.assistance.every(src=>CFG.coverage.some(x=>x.sourceId===src&&x.componentId===id&&x.conditionKey===sub.conditionKey)),'提交辅助来源不明');if(id==='main-map'){assert(['more','equal','less'].includes(sub.choice),'判断选项不明');assert(sub.draft===undefined&&sub.check===undefined,'预测不是构造答卷');}else{validDraft(sub.draft,sub.conditionKey);assert(same(checkDraft(sub.draft,sub.conditionKey),sub.check),'核对记录与原草稿不一致');}});
 for(const k of conds(id)){const r=s.rounds[k];if(id==='main-map'){
  keys(r,['predictionDraft','activeId','skipped','pathId','stageId','requested','displayed','mediaStatus','pathSelections'],'预测阶段字段不明');assert(r.predictionDraft===null||['more','equal','less'].includes(r.predictionDraft),'预测草稿不明');assert(r.pathId===null||DATA[k].paths.some(p=>p.id===r.pathId&&p.allowed),'该机制没有这条可观察路径');assert(['paths','mapping','bars'].includes(r.stageId),'教学阶段不明');assert(['idle','loading','shown','failed'].includes(r.mediaStatus),'媒体状态不明');
  ['requested','displayed'].forEach(f=>{assert(r[f]===null||CFG.frames.some(x=>x.frameId===r[f]&&x.conditionKey===k),'媒体身份不明');});
  if(r.requested){const f=CFG.frames.find(f=>f.frameId===r.requested);assert(f.stageId===r.stageId&&(f.selectedPathId||null)===(r.pathId||null),'请求与当前路径阶段不匹配');}
  assert(r.mediaStatus!=='shown'||r.requested===r.displayed,'已显示状态未提交当前请求');assert(r.mediaStatus==='idle'||r.requested!==null,'媒体状态缺请求');assert(Array.isArray(r.pathSelections)&&r.pathSelections.every(x=>DATA[k].paths.some(p=>p.id===x&&p.allowed)),'主动路径记录不明');
 }else{keys(r,['draft','activeId','skipped'],'构造阶段字段不明');validDraft(r.draft,k);}
 assert(typeof r.skipped==='boolean','跳过状态无效');assert(r.activeId===null||s.submissions.some(x=>x.id===r.activeId&&x.conditionKey===k),'当前冻结提交属于其他条件');if(r.activeId){const frozen=s.submissions.find(x=>x.id===r.activeId);assert(id==='build-sample'?same(r.draft,frozen.draft):r.predictionDraft===frozen.choice,'锁定视图与冻结答卷不一致');}
 }
 keys(s.contacts,conds(id),'接触条件不明');for(const k of conds(id)){assert(dict(s.contacts[k]),'接触记录不全');Object.entries(s.contacts[k]).forEach(([src,t])=>{assert(CFG.coverage.some(x=>x.sourceId===src&&x.componentId===id&&x.conditionKey===k),'接触来源不明');idtime(t);});}
 assert(Array.isArray(s.visibleSolutionIds)&&new Set(s.visibleSolutionIds).size===s.visibleSolutionIds.length&&s.visibleSolutionIds.every(x=>CFG.coverage.some(v=>v.componentId===id&&v.kind==='reference'&&v.selector==='#'+x)),'已揭示区域不明');return clone(s);
}
function runtime(){return window.DialogueTutor.instance;}
function save(id,action=false){if(action)document.dispatchEvent(new CustomEvent('dt:exploration',{detail:{activityId:id,state:clone(states[id])}}));else runtime().restoreExploration(id,states[id]);}
function shown(n){for(let x=n;x&&x.nodeType===1;x=x.parentElement){if(x.hidden)return false;if(x.tagName==='DETAILS'&&!x.open)return false;const style=getComputedStyle(x);if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse')return false;}return true;}
function inViewport(n){const r=n.getBoundingClientRect();return r.width>0&&r.height>0&&r.bottom>0&&r.top<window.innerHeight&&r.right>0&&r.left<window.innerWidth;}
function contact(id,k,src,t=now()){if(!states[id])return;const a=states[id].contacts[k];a[src]=a[src]?Math.min(a[src],t):t;}
function sync(id){const s=states[id];if(!s)return;CFG.coverage.filter(v=>v.componentId===id&&v.selector).forEach(v=>{const n=document.querySelector(v.selector);if(!n||!shown(n))return;if(v.kind==='presented'&&!inViewport(n))return;contact(id,v.conditionKey,v.sourceId);if(v.kind==='reference'&&n.tagName==='DETAILS'&&!s.visibleSolutionIds.includes(n.id))s.visibleSolutionIds.push(n.id);});save(id);}
function syncAll(){IDS.forEach(sync);}
function merge(id,incoming){const local=states[id],s=validate(id,incoming);if(local){for(const k of conds(id))for(const [src,t] of Object.entries(local.contacts[k]))s.contacts[k][src]=s.contacts[k][src]?Math.min(t,s.contacts[k][src]):t;local.submissions.forEach(a=>{const b=s.submissions.find(x=>x.id===a.id);assert(!b||same(a,b),'同一提交ID的冻结内容冲突');if(!b)s.submissions.push(clone(a));});s.visibleSolutionIds=[...new Set([...s.visibleSolutionIds,...local.visibleSolutionIds])];}return s;}
function assistance(id,k){return Object.keys(states[id].contacts[k]);}
function active(id){const s=states[id];return s.submissions.find(x=>x.id===s.rounds[s.conditionKey].activeId);}
function gotoLine(id){const n=document.getElementById(id);if(!n)return;for(let x=n;x;x=x.parentElement)if(x.tagName==='DETAILS')x.open=true;CFG.coverage.filter(v=>v.kind==='presented'&&v.lineIds.includes(id)).forEach(v=>contact(v.componentId,v.conditionKey,v.sourceId));syncAll();if(n.scrollIntoView)n.scrollIntoView({behavior:'auto',block:'start'});n.tabIndex=-1;n.focus({preventScroll:true});renderEnding();}
function renderCondition(id,area){const s=states[id];area.replaceChildren();conds(id).forEach(k=>{const b=button(DATA[k].mechanism==='wr'?'有放回 · 独立均匀':'无放回 · 剩余均匀','condition');b.dataset.condition=k;b.setAttribute('aria-pressed',String(k===s.conditionKey));area.append(b);});}
function frameFor(k,p,stage){return CFG.frames.find(f=>f.conditionKey===k&&f.stageId===stage&&(f.selectedPathId||null)===(p||null));}
function requestFrame(k,p,stage,action=true){const s=states['main-map'],r=s.rounds[k],f=frameFor(k,p,stage);assert(f,'该路径阶段没有实际静帧');r.pathId=p;r.stageId=stage;r.requested=f.frameId;r.mediaStatus='loading';const token=++serial;loads['main-map']=token;drawMedia();if(action)save('main-map',true);else save('main-map');
 const img=new Image();img.onload=()=>{if(loads['main-map']!==token||states['main-map'].conditionKey!==k||states['main-map'].rounds[k].requested!==f.frameId)return;const rr=states['main-map'].rounds[k];rr.displayed=f.frameId;rr.mediaStatus='shown';contact('main-map',k,'frame-'+f.frameId);save('main-map');drawMedia();renderEnding();};
 img.onerror=()=>{if(loads['main-map']!==token||states['main-map'].conditionKey!==k||states['main-map'].rounds[k].requested!==f.frameId)return;states['main-map'].rounds[k].mediaStatus='failed';save('main-map');drawMedia();};img.src=f.url;
}
function drawMedia(){const root=roots['main-map'];if(!root)return;const s=states['main-map'],k=s.conditionKey,r=s.rounds[k],box=root.querySelector('[data-media]');box.replaceChildren();if(!r.requested){box.append(el('p','尚未请求图。可先选择一条路径，也可直接查看当前完整分布。'));return;}
 const f=CFG.frames.find(f=>f.frameId===r.requested),c=DATA[k],p=c.paths.find(p=>p.id===r.pathId),currentLine=r.stageId==='bars'?(p?c.bars.find(b=>frac(b.value)===frac(p.stat)).lineId:c.bars[0].lineId):(p?p.linePrefix+'-sub':c.base+'-'+c.mechanism+'-paths');
 const captions={paths:p?'当前请求检查'+p.id+'是否是本机制的允许路径；下一步把两个观测放入mean。':'当前请求列出本机制路径；下一步选择一条路径。',mapping:'当前请求计算'+(p?p.id:'')+'的mean；下一步找出相同输出的其他路径。',bars:'当前请求展示本条件全部输出的概率；下一步按原像核查总质量。'};
 box.append(el('p',captions[r.stageId],{'data-media-caption':''}));const link=el('a',p&&r.stageId!=='bars'?'阅读当前路径代入行':'阅读当前条件的'+(r.stageId==='bars'?'概率归并行':'完整路径集合'),{href:'#'+currentLine,'data-current-link':''});box.append(link);
 const status=el('p',r.mediaStatus==='shown'?'当前请求图已加载。':r.mediaStatus==='failed'?'当前图加载失败；下面链接保留当前条件的书面推导。':'正在加载当前请求；旧图与旧公式已隐藏。',{'data-media-status':'',role:'status'});box.append(status);
 const group=el('div',null,{'data-displayed-group':'','data-frame-id':r.displayed||''});group.hidden=r.mediaStatus!=='shown'||r.displayed!==r.requested;
 if(!group.hidden){const image=el('img',null,{src:f.url,alt:f.alt||captions[r.stageId]});image.className='manim-frame';group.append(image);if(p&&r.stageId!=='paths'){const formula=el('div',null,{'data-media-formula':''});formula.innerHTML=pathFormula(p)+(r.stageId==='paths'?'':math(variable('stat')+'<mo>=</mo>'+value('stat',p.stat)));group.append(formula);const target=el('p',null,{'data-media-target':''});target.innerHTML='目标输出：'+math(value('stat',p.stat))+(r.stageId==='bars'?'，其概率为'+math(mm(c.bars.find(b=>frac(b.value)===frac(p.stat)).probability)):'' );group.append(target);}}
 if(p)stampRoles(group,k,p.id,p.linePrefix+'-sub');box.append(group);if(r.mediaStatus==='failed')box.append(button('重试当前图','retry-image'));
}
function drawMain(){const root=roots['main-map'],s=states['main-map'],k=s.conditionKey,r=s.rounds[k],sub=active('main-map');if(!root)return;renderCondition('main-map',root.querySelector('[data-condition-controls]'));const q=root.querySelector('[data-prediction]');q.replaceChildren();q.append(el('p','在当前抽法中，mean为5与mean为1的概率怎样比较？'));
 [['more','mean为5较可能'],['equal','两者一样可能'],['less','mean为5较不可能']].forEach(([v,t])=>{const lab=el('label',null),input=el('input',null,{type:'radio',name:'opening-prediction',value:v});input.checked=r.predictionDraft===v;input.disabled=!!sub;lab.append(input,document.createTextNode(t));q.append(lab);});
 const submit=button('保存本条件的判断','submit-prediction');submit.disabled=!!sub;q.append(submit,button('跳过判断，继续观察','skip-prediction'),button('本条件再作一次判断','retry-prediction'));
 if(sub)q.append(el('p','已保存本条件的原判断：'+({more:'mean5较可能',equal:'一样可能',less:'mean5较不可能'}[sub.choice])+'。'+(sub.assistance.length?'提交前已呈现相关参考。':'本页未记录提交前参考。')+' 观察后再核对。'));
 if(r.skipped)q.append(el('p','本条件已跳过预测；仍可查看和返回。'));
 const paths=root.querySelector('[data-path-buttons]');paths.replaceChildren();DATA[k].paths.filter(p=>p.allowed).forEach(p=>{const b=button(p.firstId+' → '+p.secondId,'path');b.dataset.path=p.id;b.setAttribute('aria-pressed',String(p.id===r.pathId));paths.append(b);});
 drawMedia();drawMainOutcome();
}
function resultSeen(k){const c=DATA[k],targets=['1','5'];const seen=new Set();Object.keys(states['main-map'].contacts[k]).forEach(src=>{const cov=CFG.coverage.find(x=>x.sourceId===src&&x.componentId==='main-map'&&x.conditionKey===k);(cov?.targets||[]).forEach(t=>seen.add(t));});return targets.every(x=>seen.has(x));}
function chooseNext(id,outcome){const s=states[id],k=s.conditionKey;const qstate=runtime().getState().activities['q4-answer'];
 if(outcome==='incorrect'){const sub=active(id),kind=id==='main-map'?'equal':sub.draft.weight==='equiprobable'?'equal':sub.check.weight?'weight':sub.check.missing.length||sub.check.extra.length?'reverse':'equal';return {label:kind==='weight'?'重新计算第二抽的条件权重':kind==='reverse'?'按第一身份检查反向与重复身份':'检查每种输出的原像',action:'repair',kind,conditionKey:k,targetId:'repair-'+kind};}
 if(outcome==='skipped')return {label:'先读maximum的完整例题',action:'line',line:'e3a-work'};
 if(outcome==='assisted'){const other=conds('build-sample').find(c=>!Object.keys(states['build-sample'].contacts[c]).length&&!states['build-sample'].rounds[c].activeId);if(other)return {label:'构造尚未呈现的'+(DATA[other].mechanism==='wr'?'有放回':'无放回')+'新数据',action:'task',conditionKey:other};}
 if(id==='main-map'&&outcome==='correct'){const target=conds('build-sample')[0];return {label:states['build-sample'].rounds[target].activeId?'回看有放回构造':'按D/E不同身份构造有放回分布',action:'task',conditionKey:target};}
 return {label:qstate.answerRevealed||qstate.attempts.length?'回看maximum原像核对':'检查maximum：没有J且至少一个H',action:'quiz',activityId:'q4-answer'};
}
function nextButton(id,outcome){const spec=chooseNext(id,outcome);const b=button(spec.label,'next-task');b.dataset.next=JSON.stringify(spec);b.dataset.owner=id;return b;}
function mainOutcome(){const s=states['main-map'],k=s.conditionKey,sub=active('main-map'),r=s.rounds[k];if(sub){if(sub.assistance.length)return 'assisted';return sub.choice==='more'?'correct':'incorrect';}return r.skipped?'skipped':null;}
function drawMainOutcome(){const root=roots['main-map'];if(!root)return;const area=root.querySelector('[data-main-outcome]');area.replaceChildren();const k=states['main-map'].conditionKey;if(resultSeen(k)){area.append(el('p','当前两种概率已呈现，可以到收束核对原判断。'));const outcome=mainOutcome();area.append(nextButton('main-map',outcome||'skipped'));}}
function selectControl(values,value,attrs){const s=el('select',null,attrs);s.append(el('option','请选择',{value:''}));values.forEach(([v,t])=>s.append(el('option',t,{value:v})));s.value=value||'';return s;}
function drawBuild(){const root=roots['build-sample'];if(!root)return;const s=states['build-sample'],k=s.conditionKey,c=DATA[k],r=s.rounds[k],d=r.draft,sub=active('build-sample');renderCondition('build-sample',root.querySelector('[data-condition-controls]'));const area=root.querySelector('[data-construction]');area.replaceChildren();
 const one=el('fieldset',null);one.append(el('legend','1 · 选择你认为允许的完整有序路径集合'));c.paths.forEach(p=>{const label=el('label',null),input=el('input',null,{type:'checkbox',name:'path-selection',value:p.id});input.checked=d.paths.includes(p.id);input.disabled=!!sub;label.append(input,document.createTextNode(p.id));one.append(label);});area.append(one);
 const two=el('fieldset',null);two.append(el('legend','2 · 给你所选的每条路径选择mean'));if(!d.paths.length)two.append(el('p','先在第1组选择你自己的路径。这里不会替你补路径。'));d.paths.forEach(id=>{const p=c.paths.find(p=>p.id===id),label=el('label',p.id+'：');const sel=selectControl(CFG.mappingOptions.map(v=>[v,v]),d.mapping[id],{'data-map-path':id,'aria-label':id+'的mean'});sel.disabled=!!sub;label.append(sel);two.append(label);});area.append(two);
 const three=el('fieldset',null);three.append(el('legend','3 · 选择各允许身份路径的权重与理由'));const w=selectControl([['independent','1/3 × 1/3 = 1/9；两抽独立且各从三枚均匀选'],['remaining','1/3 × 1/2 = 1/6；给定第一抽，第二抽从剩余两枚均匀选'],['old','1/9；删掉不允许路径后仍沿用有放回的旧权重'],['equiprobable','1/3；把三种mean直接当成等可能结果']],d.weight,{name:'weight','aria-label':'路径权重和理由'});w.disabled=!!sub;three.append(w);area.append(three);
 const four=el('fieldset',null);four.append(el('legend','4 · 为候选输出填写归并概率（可选择0）'));c.bars.forEach(b=>{const v=String(b.value.n),label=el('label','mean '+v+'：'),sel=selectControl(CFG.probabilityOptions.map(v=>[v,v]),d.distribution[v],{'data-distribution':v,'aria-label':'mean '+v+'的概率'});sel.disabled=!!sub;label.append(sel);four.append(label);});area.append(four);
 area.append(button(sub?'本条件已冻结提交':'统一提交四组','submit-construction'),button('重开本条件草稿','retry-construction'),button('先跳过，仍可看完整例题','skip-construction'));
 const out=root.querySelector('[data-construction-feedback]');out.replaceChildren();if(sub){drawFeedback(out,sub);contact('build-sample',k,'construction-feedback-'+k);save('build-sample');out.append(nextButton('build-sample',sub.assistance.length?'assisted':sub.check.correct?'correct':'incorrect'));}else if(s.submissions.some(x=>x.conditionKey===k))out.append(el('p','上次冻结提交保留在历史中；本轮草稿重新开放。'));else if(r.skipped)out.append(el('p','本条件尚未提交。可以先读完整例题，再回来构造。'),nextButton('build-sample','skipped'));
 s.submissions.filter(x=>x.conditionKey===k&&x.id!==r.activeId).forEach(previous=>{const history=el('details',null,{open:'','data-frozen-history':previous.id});history.append(el('summary','上次冻结提交与逐项反馈（保留原答卷）'));const draft=el('p','当时所选路径：'+(previous.draft.paths.join('、')||'空集')+'；当时权重选择：'+(previous.draft.weight||'未选择')+'。');history.append(draft);drawFeedback(history,previous);out.append(history);});
}
function drawFeedback(area,sub){const k=sub.conditionKey,c=DATA[k],q=sub.check;area.append(el('p','本次冻结核对：'+(q.correct?'四组均与题设相符。':'下面逐项说明本次草稿的差异。')+(sub.assistance.length?'提交前已打开或呈现本条件参考；这是有辅助核对。':'本页未记录提交前参考；这里只说明这一次构造。')));
 area.append(el('p','匹配路径：'+(q.matched.join('、')||'无')+'；缺少路径：'+(q.missing.join('、')||'无')+'；多选路径：'+(q.extra.join('、')||'无')+'。'));
 [...q.missing,...q.extra,...q.mapping].filter((x,i,a)=>a.indexOf(x)===i).forEach(id=>{const p=c.paths.find(x=>x.id===id),row=el('p',id+'：'+(q.extra.includes(id)?'同一实物已取走，无放回时第二次不能再取它。':q.missing.includes(id)?'它是题设允许的有序身份路径，需要保留；反向路径是另一个结果。':'你的mean映射需按两个观测重新代入。')+' ');const values=el('span',null);values.innerHTML=' 两个观测：'+math(value('x1',p.x1)+'<mo>,</mo>'+value('x2',p.x2))+'；当前路径权重：'+math(mm(p.weight))+'。 ';row.append(values);row.append(el('a','查看此路径的逐行推导',{href:'#'+p.linePrefix+'-sub'}));area.append(row);});
 if(q.weight)area.append(el('p',c.mechanism==='wo'?'权重需重算：第一抽从三枚选，给定第一抽后第二抽只剩两枚，所以每条允许路径为1/3 × 1/2 = 1/6。删路径不会使旧的1/9自动正确。':'每条身份路径是两次独立均匀抽取，故权重为1/3 × 1/3 = 1/9；输出mean没有因此等可能。'));
 if(q.weight){const first=c.paths.find(p=>p.allowed);area.append(el('a','逐行核对第一因子、条件第二因子与乘积',{href:'#'+first.linePrefix+'-weight-sub'}));}
 q.distribution.forEach(v=>{const b=c.bars.find(x=>String(x.value.n)===v),row=el('p','mean '+v+'的原像为'+(b.pathIds.join('、')||'空集')+'；当前每条允许原像路径的权重为'+(b.pathIds.length?frac(c.paths.find(p=>p.id===b.pathIds[0]).weight):'0（空原像）')+'，互斥相加后的概率为'+frac(b.probability)+'。 ');row.append(el('a','查看该输出的每一步归并',{href:'#'+b.lineId}));area.append(row);});
 area.append(el('p','原始草稿和上述差异已冻结；重开不会删除历史。'));}
function repair(id,spec){const area=document.getElementById('repair-panel');area.replaceChildren();const k=spec.conditionKey,c=DATA[k];area.append(el('h3',spec.kind==='weight'?'重新计算当前机制的条件权重':spec.kind==='reverse'?'按顺序核对缺少和多出的身份路径':'输出值为什么不等可能？',{id:spec.targetId||'repair-equal'}));
 if(id==='main-map'){[1,5].forEach(v=>{const b=c.bars.find(b=>b.value.n===v),p=el('p','mean '+v+'来自'+(b.pathIds.join('、')||'没有允许路径')+'。');p.innerHTML+=' '+probability(b.value,b.probability);area.append(p);});area.append(el('p','随机均匀首先作用于每阶段可选身份；统计量会把多条路径归入一个值。应先找原像，再加权。'));}
 else{const sub=active(id);if(sub)drawFeedback(area,sub);area.append(el('p','先固定第一身份，再列第二身份，可检查反向是否遗漏；无放回时先划去已取走的同一实物，再把第二因子改为二分之一。D和E数值相同，身份仍不同。'));}
 area.hidden=false;gotoLine('repair-panel');}
function renderEnding(){const area=document.getElementById('lesson-ending-state');if(!area||!states['main-map']||!states['build-sample'])return;area.replaceChildren();const s=states['main-map'],k=s.conditionKey,c=DATA[k],sub=active('main-map'),seen=resultSeen(k),outcome=mainOutcome();area.dataset.conditionKey=k;area.dataset.scenario=(sub?'submitted':'unsubmitted')+'-'+(seen?'presented':'unpresented');area.append(el('p','回到开场 · '+(c.mechanism==='wr'?'有放回、独立均匀':'无放回、剩余均匀')));
 if(s.rounds[k].skipped)area.append(el('p','你在当前条件选择了跳过预测；尚无原判断时不作正确评价。'));
 if(!seen){area.append(el('p',sub?'你已保存本条件判断，但本页尚未记录两项概率都已呈现；现在还不评价判断。':'本条件尚未提交预测，也尚未记录两项概率都已呈现。可以先作判断，或直接看完整结果。'));const b=button('查看本条件完整分布','ending-show');area.append(b);}
 else{[1,5].forEach(v=>{const b=c.bars.find(b=>b.value.n===v),p=el('p',null);p.innerHTML=probability(b.value,b.probability);area.append(p);});area.append(el('p','mean5比mean1更可能，因为前者归入更多允许路径。'+(!sub?'你没有提交本条件原判断；这里只收束已经呈现的结果。':outcome==='assisted'?'你的提交前已有相关参考，这是有辅助核对。':outcome==='correct'?'你的本次原判断与结果一致；这只支持本次判断。':'你的本次原判断与结果不一致；请用两种输出的原像修正。')));area.append(nextButton('main-map',outcome||'skipped'));}
 const bs=active('build-sample');area.append(el('p',bs?'新数据最近冻结的当前机制构造：'+(bs.check.correct?'四组核对相符。':'仍有具体差异，回到构造板可见每项说明。'):'新数据当前机制尚无冻结提交；预测结果不能替代完整构造。'));
 const revs=window.DialogueTutor.getReviews(CFG.lesson,runtime().getState(),now()).filter(x=>x.activityId==='recall-core');revs.forEach(item=>{const b=button((item.due?'到期回忆：':'提前回忆：')+(item.cardIndex===0?'统计量的输入规则':'无放回第二因子'),'review-card');b.dataset.review=JSON.stringify(item);area.append(b);});const browse=button('普通浏览两张回忆卡','browse-cards');area.append(browse);
}
function restore(id,incoming){try{states[id]=merge(id,incoming);states[id].visibleSolutionIds.forEach(x=>{const n=document.getElementById(x);if(n)n.open=true;});save(id);if(id==='main-map'){drawMain();const r=states[id].rounds[states[id].conditionKey];if(r.requested)requestFrame(states[id].conditionKey,r.pathId,r.stageId,false);}else drawBuild();renderEnding();}catch(e){const n=roots[id];if(n)n.append(el('p',e.message,{role:'alert'}));}}
document.addEventListener('dt:activity-mounted',e=>{const id=e.detail.activityId;if(!IDS.includes(id))return;roots[id]=document.getElementById(id);const incoming=e.detail.state;if(incoming&&Object.keys(incoming).length)restore(id,incoming);else {states[id]=fresh(id);save(id);if(id==='main-map')drawMain();else drawBuild();}});
document.addEventListener('dt:restore',e=>{if(IDS.includes(e.detail.activityId))restore(e.detail.activityId,e.detail.state);});
document.addEventListener('dt:ready',()=>{runtime().beforeExport(()=>{syncAll();IDS.forEach(id=>validate(id,states[id]));});runtime().beforeImport(ctx=>{syncAll();if(ctx.validationError)return;IDS.forEach(id=>merge(id,ctx.incomingState.activities[id].exploration));});transferReady=true;renderEnding();});
document.addEventListener('change',e=>{const root=e.target.closest('[data-course-component]');if(!root)return;const id=root.dataset.courseComponent,s=states[id],r=s.rounds[s.conditionKey],t=e.target;if(active(id))return;
 if(id==='main-map'&&t.name==='opening-prediction')r.predictionDraft=t.value;
 if(id==='build-sample'){const d=r.draft;if(t.name==='path-selection'){d.paths=[...root.querySelectorAll('input[name="path-selection"]:checked')].map(x=>x.value);Object.keys(d.mapping).forEach(x=>{if(!d.paths.includes(x))delete d.mapping[x];});}if(t.dataset.mapPath){if(t.value)d.mapping[t.dataset.mapPath]=t.value;else delete d.mapping[t.dataset.mapPath];}if(t.name==='weight')d.weight=t.value||null;if(t.dataset.distribution){if(t.value)d.distribution[t.dataset.distribution]=t.value;else delete d.distribution[t.dataset.distribution];}drawBuild();}save(id,true);});
document.addEventListener('click',e=>{const link=e.target.closest('a[href^="#"]');if(link&&document.getElementById(link.hash.slice(1))){e.preventDefault();gotoLine(link.hash.slice(1));return;}const global=e.target.closest('[data-lesson-action]');if(global){if(global.dataset.lessonAction==='all-solutions'){document.querySelectorAll('details.reference').forEach(n=>n.open=true);syncAll();}gotoLine(global.dataset.lessonAction==='go-ending'?'lesson-ending':'main-reference');return;}
 const b=e.target.closest('[data-action]');if(!b)return;const a=b.dataset.action,root=b.closest('[data-course-component]'),id=root?.dataset.courseComponent,s=id&&states[id],k=s?.conditionKey,r=s?.rounds[k];
 if(a==='inspect-path'){syncAll();const ms=states['main-map'];ms.conditionKey=b.dataset.condition;drawMain();requestFrame(ms.conditionKey,b.dataset.path,b.dataset.stage);const go=el('a','返回刚才的推导位置',{href:'#'+b.dataset.back});roots['main-map'].querySelector('[data-proof-return]').replaceChildren(go);gotoLine('main-map');return;}
 if(a==='condition'){syncAll();s.conditionKey=b.dataset.condition;save(id,true);if(id==='main-map'){drawMain();const rr=s.rounds[s.conditionKey];if(rr.requested)requestFrame(s.conditionKey,rr.pathId,rr.stageId,false);}else drawBuild();renderEnding();return;}
 if(a==='submit-prediction'&&!active(id)){syncAll();if(!r.predictionDraft){root.querySelector('[data-main-outcome]').textContent='可选择一个判断，或跳过后继续。';return;}const sub={id:k+'-'+now()+'-'+(++serial),conditionKey:k,at:now(),choice:r.predictionDraft,assistance:assistance(id,k)};s.submissions.push(sub);r.activeId=sub.id;r.skipped=false;save(id,true);drawMain();}
 if(a==='retry-prediction'){r.activeId=null;r.skipped=false;save(id,true);drawMain();}
 if(a==='skip-prediction'){r.skipped=true;save(id,true);drawMain();}
 if(a==='path'){r.pathSelections.push(b.dataset.path);requestFrame(k,b.dataset.path,'paths');}
 if(a==='stage'){const stage=b.dataset.stage,path=r.pathId||DATA[k].paths.find(p=>p.allowed).id;requestFrame(k,path,stage);}
 if(a==='retry-image')requestFrame(k,r.pathId,r.stageId);
 if(a==='submit-construction'&&!active(id)){syncAll();const sub={id:k+'-'+now()+'-'+(++serial),conditionKey:k,at:now(),draft:clone(r.draft),check:checkDraft(r.draft,k),assistance:assistance(id,k)};s.submissions.push(sub);r.activeId=sub.id;r.skipped=false;save(id,true);drawBuild();}
 if(a==='retry-construction'){r.draft=blankDraft();r.activeId=null;r.skipped=false;save(id,true);drawBuild();}
 if(a==='skip-construction'){r.skipped=true;save(id,true);drawBuild();}
 if(a==='next-task'){const spec=JSON.parse(b.dataset.next);if(spec.action==='repair')repair(b.dataset.owner,spec);if(spec.action==='line')gotoLine(spec.line);if(spec.action==='task'){states['build-sample'].conditionKey=spec.conditionKey;save('build-sample');drawBuild();runtime().navigate('build-sample');}if(spec.action==='quiz')runtime().navigate(spec.activityId);}
 if(a==='ending-show'){const kk=states['main-map'].conditionKey;gotoLine('main-'+DATA[kk].mechanism+'-bar-1');gotoLine('main-'+DATA[kk].mechanism+'-bar-5');}
 if(a==='review-card')runtime().navigate('recall-core',JSON.parse(b.dataset.review));if(a==='browse-cards')runtime().navigate('recall-core');renderEnding();
});
document.addEventListener('click',e=>{if(e.target.closest('summary'))queueMicrotask(()=>{syncAll();drawMainOutcome();renderEnding();});});
document.addEventListener('toggle',()=>{if(transferReady){syncAll();renderEnding();}},true);
window.addEventListener('scroll',()=>{if(transferReady){syncAll();drawMainOutcome();renderEnding();}},{passive:true});
})();
