from pathlib import Path
import json
O=Path(__file__).resolve().parent
colors={'page':'#F7F9FB','surface':'#FFFFFF','soft':'#EEEDE8','ink':'#202C39','reason':'#465467','muted':'#586674','x1':'#2364AA','x2':'#7250A4','stat':'#0F7074','action':'#8C4A25','button-ink':'#183A61','button-fill':'#EDF4FA','button-line':'#7997B6','selected-fill':'#D9E8F5','control-line':'#7B8792','success':'#176B4B','error':'#AE3447'}
def lum(h):
 c=[int(h[i:i+2],16)/255 for i in [1,3,5]];c=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in c];return sum(a*b for a,b in zip(c,[.2126,.7152,.0722]))
def ratio(a,b):
 l,h=sorted([lum(a),lum(b)]);return (h+.05)/(l+.05)
rows=[]
for fg,bg,minimum in [('ink','page',4.5),('reason','page',4.5),('muted','surface',4.5),('x1','page',4.5),('x2','page',4.5),('stat','page',4.5),('action','page',4.5),('button-ink','button-fill',4.5),('button-ink','selected-fill',4.5),('success','soft',4.5),('error','soft',4.5),('control-line','surface',3),('button-line','surface',3),('button-line','page',3),('button-line','button-fill',3),('control-line','page',3),('control-line','button-fill',3)]:
 r=ratio(colors[fg],colors[bg]);rows.append({'foreground':fg,'foregroundHex':colors[fg],'background':bg,'backgroundHex':colors[bg],'ratio':r,'required':minimum,'passes':r>=minimum})
(O/'contrast-results.json').write_text(json.dumps({'method':'sRGB linear luminance exact opaque colors; no rounding before comparison; not computedStyle or browser pixels','pairs':rows},indent=2));print(json.dumps(rows,indent=2))
