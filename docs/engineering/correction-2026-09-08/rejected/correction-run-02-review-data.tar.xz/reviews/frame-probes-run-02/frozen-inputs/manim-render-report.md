# Manim 实际渲染报告 — correction-run-02

完成 51 张 1000×1250 PNG：主例两条件的全部允许路径×三阶段及两张路径概览，共47张；另含本轮追加授权的4张完整分布图。所有PNG由 `SamplingScene(Scene).render()` 内的实际 `CairoRenderer.update_frame()` 与 `camera.get_image().save()` 产生。文字使用Pango `Text`，数学使用 `MathTypst`；没有手绘替代教学图。

## 来源与复现

- 唯一精确数据：`exact-data.json`；SHA-256 `9695b34b11bbe735fb06a6ce73e335533beeef067cd6b4311b3026feb2f1ceaa`。
- Scene：`sampling_scene.py`；SHA-256 `daa7cf736a3b575bd887231abff0362e56bc48753dcee627fd23711d8fef8a6f`。
- Manim：`0.21.0`；CairoRenderer；指定字体 `work/manim-runtime/fonts/NotoSansCJKsc-Regular.otf`，已实际注册给Pango。
- 渲染：`source work/manim-runtime/env.sh && python generation/correction-run-02/sampling_scene.py`。
- 像素/算术核查：`python generation/correction-run-02/media/qa/audit.py`。
- `media/frame-contract.json` 在Scene渲染前枚举51个frameId；最终集合与manifest一致。
- 阅读记录见 `manim-reading.json`。依赖包实际缺少其SKILL所列的 `api/scene.md`，改完整读取已安装同版本Scene源文件；未访问旧generation课件或repo/docs课件。

## 状态合同

| conditionKey | PNG数 |
|---|---:|
| main-wr-mean-v1 | 28 |
| main-wo-mean-v1 | 19 |
| task-wr-mean-v1 | 1 |
| task-wo-mean-v1 | 1 |
| example-wr-maximum-v1 | 1 |
| challenge-wr-maximum-v1 | 1 |

- 主例帧ID：`main-wr-AB-paths`、`main-wr-AB-mapping`、`main-wr-AB-bars`，其余路径/机制同规则；概览为 `main-wr-overview-paths`、`main-wo-overview-paths`。
- 新增图：`task-wr-overview-bars`、`task-wo-overview-bars`、`example-wr-overview-bars`、`challenge-wr-overview-bars`。练习图应只放在对应全解区域。
- `media-manifest.json.frames` 为数组，每帧含frameId/conditionKey/stageId/pathIds/barIds/lineIds/objects/renderedRoles/relativePath/path/hash/sha256/dataHash/sceneSourceHash。
- pathIds描述图中出现的路径；paths帧包括被划除的对角身份。selectedPathId另存当前选择。bars帧的pathIds是目标输出原像，barIds是可见完整分布；targetBarId保存填充目标。
- 所有数值、允许资格、原像与权重均从数据消费。对象采用X1/X2/T及x1/x2/stat，按出现位置绑定，不按字符串全局染色；同一BB路径中的两个5分别蓝/紫，中间和、样本量、概率保持墨色。

## 构图与数值尺度

paths为3×3矩阵，行是第1次、列是第2次，蓝圆/紫方与文字联合辨认；单格显示身份及有序数值对。无放回对角用墨色斜线及“不允许重复”说明。mapping单独显示观测徽标、代入、和除以2、约分结果，统计量用青色与菱形。

主例柱图共同x区间0..10（输出刻度1/3/5/7/9，真实等数值距离），共同y区间0..1/3。目标柱填充青色，其余柱保留青色轮廓；下方独立区域显示原像及权重合并。两张task图共同y0..2/3、x刻度2/5/8；maximum两图共同y0..1，分别x0/2与x1/5/9，均明确写“最大值”。x=0使用NumberLine数值定位且保留左侧边距，不把0柱压在纵轴上。所有零概率显示空心青圈及墨色0。

## 实物证据

51张PNG哈希逐一验证；全部六个条件用Python Fraction重新核算每条路径的加和、mean/maximum、条件概率乘法、每个输出原像概率及总质量1。标签几何包围盒均在1000×1250内。证据在 `media/qa/pixel-audit.json`，可重跑脚本。

| 测量对象 | PNG实测px | 图宽300时CSS px |
|---|---:|---:|
| 数值角色的可定位字形最小值 | 61 | 18.3 |
| 路径行标A/B/C实际墨迹高度 | 56 | 16.8 |
| 纵横轴基线 | 6 | 1.8 |
| 非当前柱轮廓 | 9 | 2.7 |
| 当前路径边框 | 10 | 3.0 |
| X2方形边框 | 10 | 3.0 |
| 零概率圈边缘 | 10 | 3.0 |
| MathTypst分数横线 | 5 | 1.5 |

数值测量在manifest标注的出现位置裁切PNG，对对应角色颜色作阈值检测；这与声明font_size不同。Text按实际完整字形几何高56px缩放；标点、横画本身不是独立“54px高汉字”。字母行标又用PNG墨迹实测56px。完整混排字形与细节证据保存在manifest labels字段及 `media/qa/text-label-audit.json`。

实际目视包含WR/WO路径图、AB/BA/BB及WO-CA映射、WR-AC/WO-AB柱图、追加四种分布图。手机缩图采用真实PNG的300×375 Lanczos缩放：`media/qa/phone-contact-sheet.png` 与 `media/qa/additional-phone-contact-sheet.png`。当前格/柱、零圈、分数线、同值双角色和顺序对调可辨；图内没有重叠标签或裁切。追加柱概率标签用白底隔开辅助网格线。

## 验证边界

已验证源PNG及300px离线缩图；未访问课程HTML，也未验证真实浏览器图片解码、原生MathML computedStyle、实际页面祖先padding、触控/键盘或200%文字缩放。最终HTML若给图至少300px有效宽度，上表尺寸换算成立；浏览器层结果由整课验证另行确认。没有把几何包围盒、声明字号或离线缩图称为浏览器实测。51个状态全部自动核查，目视采用上述有代表性的12个状态，并非逐帧人工检查51张。
