"""51 data-driven Cairo/MathTypst PNGs for correction-run-02 only.

Run: source work/manim-runtime/env.sh && python generation/correction-run-02/sampling_scene.py
All mathematical values come from exact-data.json; no distribution is transcribed.
"""
from pathlib import Path
import hashlib
import json
import os
from fractions import Fraction
import manim
from manim import *

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / 'exact-data.json'
DATA = json.loads(DATA_FILE.read_text())
TOKENS = DATA['tokens']
OUT = ROOT / 'media'
FONT = ROOT.parents[1] / 'work/manim-runtime/fonts/NotoSansCJKsc-Regular.otf'
PIXELS_PER_UNIT = 100
FRAMES = []

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def rat(r):
    return Fraction(r['n'], r['d'])

def exact(n):
    n = Fraction(n)
    return {'n': n.numerator, 'd': n.denominator}

def plain(r):
    f = rat(r)
    return str(f.numerator) if f.denominator == 1 else f'{f.numerator}/{f.denominator}'

def inline(r):
    f = rat(r)
    return str(f.numerator) if f.denominator == 1 else f'{f.numerator} slash {f.denominator}'

def label(s, color='ink', height=.56):
    m = Text(s, font='Noto Sans CJK SC', color=TOKENS.get(color,color), disable_ligatures=True)
    # Scale actual glyph bounds, not Manim font_size.
    full = [g.height for g in m if g.height > .02]
    heights = [h for h in full if h > max(full)*.65]
    m.scale(height / min(heights))
    return m

def math(s, color='ink', height=.62):
    m = MathTypst(s, color=TOKENS.get(color,color), font_paths=[FONT.parent])
    # Ignore punctuation/fraction strokes when determining full digit/letter height.
    full = [g.height for g in m.family_members_with_points() if g.height > .02]
    heights = [h for h in full if h > max(full)*.5]
    m.scale(height/min(heights))
    for g in m.family_members_with_points():
        if g.height < .03 and g.width > .3:
            g.set_stroke(TOKENS.get(color,color),width=6)
    return m

def bbox(m):
    return [round((m.get_left()[0]+5)*100,2),round((6.25-m.get_top()[1])*100,2),round(m.width*100,2),round(m.height*100,2)]

class SamplingScene(Scene):
    def begin(self, c, p, stage, frame_id):
        self.clear()
        self.c, self.p, self.stage = c,p,stage
        self.record = {'frameId':frame_id,'conditionKey':c['id'],'stageId':stage,
            'pathIds':[],'barIds':[],'lineIds':[],'objects':[], 'labels':[]}
        question={'paths':'哪些有序路径允许？','mapping':'这条路径得到什么均值？','bars':'哪些路径合到这根柱？'}[stage]
        if p is None and stage=='bars':question=('均值' if c['statistic']=='mean' else '最大值')+'的完整抽样分布'
        self.add_label(label(question,height=.60).move_to([0,5.58,0]),'question')
        cond = '有放回 · 两次独立均匀' if c['mechanism']=='wr' else '无放回 · 在剩余身份中均匀'
        self.add_label(label(cond).move_to([0,4.66,0]),'condition')

    def add_label(self,m,name,kind='text'):
        self.add(m)
        self.record['labels'].append({'label':name,'kind':kind,'bboxPx':bbox(m),
            'glyphHeightsPx':[round(g.height*100,2) for g in m.family_members_with_points() if g.height > .12]})
        return m

    def occurrence(self,m,role,value,line,position,kind='value',path=None):
        path = path or self.p
        self.record['objects'].append({'objectId':{'x1':'X1','x2':'X2','stat':'T'}.get(role,role),
            'role':role,'value':value,'exact':value,'token':TOKENS.get(role,TOKENS['ink']),
            'conditionKey':self.c['id'],'pathId':path['id'] if path else None,
            'stageId':self.stage,'lineId':line,'operandPosition':position,
            'occurrenceId':f'{line}-{role}-{kind}', 'kind':kind,'bboxPx':bbox(m)})

    def formula(self,source,bindings,line,y,height=.62):
        m=math(source,height=height)
        if m.width>8.9:
            raise ValueError(f'Formula too wide: {source}: {m.width}')
        for key,role,value,position,kind in bindings:
            m.select(key).set_color(TOKENS[role])
        m.move_to([0,y,0]); self.add_label(m,line,'math')
        for key,role,value,position,kind in bindings:
            self.occurrence(m.select(key),role,value,line,position,kind)
        return m

    def paths(self,c,p):
        xs=[-2.0,.55,3.1]; ys=[1.65,-.30,-2.25]
        # Explicit role shapes and direction labels survive grayscale.
        col=VGroup(Square(side_length=.56,color=TOKENS['x2'],stroke_width=10),label('第2次（列）','x2')).arrange(RIGHT,buff=.2).move_to([.5,3.77,0])
        row=VGroup(Circle(radius=.28,color=TOKENS['x1'],stroke_width=10),label('第1次（行）','x1')).arrange(RIGHT,buff=.2).move_to([0,-3.80,0])
        self.add_label(col,'x2-column'); self.add_label(row,'x1-row')
        for i,u in enumerate(c['units']):
            self.add_label(label(f"{u['id']}·{plain(u['value'])}",'x2').move_to([xs[i],2.9,0]),f"column-{u['id']}")
            self.add_label(label(u['id'],'x1').move_to([-3.97,ys[i],0]),f"row-{u['id']}")
        for q in c['paths']:
            i=next(i for i,u in enumerate(c['units']) if u['id']==q['firstId'])
            j=next(i for i,u in enumerate(c['units']) if u['id']==q['secondId'])
            center=[xs[j],ys[i],0]
            cell=RoundedRectangle(width=2.30,height=1.80,corner_radius=.12,stroke_color=TOKENS['muted'],stroke_width=6,fill_color=TOKENS['surface'],fill_opacity=1).move_to(center)
            self.add(cell)
            if p and p['id']==q['id']:
                cell.set_stroke(TOKENS['ink'],width=10)
            identities=VGroup(label(q['firstId'],'x1'),label(q['secondId'],'x2')).arrange(RIGHT,buff=.09).move_to([xs[j],ys[i]+.45,0])
            self.add_label(identities,f"{q['id']}-identities")
            pair=math('({{ '+plain(q['x1'])+' : a }} , {{ '+plain(q['x2'])+' : b }})')
            pair.select('a').set_color(TOKENS['x1']);pair.select('b').set_color(TOKENS['x2'])
            pair.move_to([xs[j],ys[i]-.32,0]);self.add_label(pair,q['id']+'-ordered-values','math')
            self.occurrence(pair.select('a'),'x1',q['x1'],q['linePrefix']+'-sub',0,path=q)
            self.occurrence(pair.select('b'),'x2',q['x2'],q['linePrefix']+'-sub',1,path=q)
            if not q['allowed']:
                # Qualification stroke leaves values readable and does not recolor roles.
                self.add(Line([xs[j]-.98,ys[i]-.71,0],[xs[j]+.98,ys[i]+.71,0],color=TOKENS['ink'],stroke_width=9))
        allowed=[q for q in c['paths'] if q['allowed']]
        self.add_label(label('按行、列读有序对').move_to([0,-4.64,0]),'ordered-pair-reading')
        if c['mechanism']=='wo':
            self.add_label(label('斜线格：不允许重复').move_to([0,-5.52,0]),'excluded-diagonals')
        else:
            self.add_label(label('允许重复同一身份').move_to([0,-5.52,0]),'replacement-allowed')
        self.record['pathIds']=[q['id'] for q in c['paths']]
        self.record['selectedPathId']=p['id'] if p else None
        self.record['lineIds']=[p['linePrefix']+'-sub'] if p else ['main-'+c['mechanism']+'-paths']

    def mapping(self,c,p):
        prefix=p['linePrefix']
        for role,x,unit,value in [('x1',-2.45,p['firstId'],p['x1']),('x2',2.45,p['secondId'],p['x2'])]:
            shape=(Circle(radius=.88) if role=='x1' else Square(side_length=1.76)).set_stroke(TOKENS[role],10).move_to([x,2.82,0])
            self.add(shape)
            v=math('X_1' if role=='x1' else 'X_2',role).move_to([x,2.82,0]);self.add_label(v,role+'-variable','math')
            self.occurrence(v,role,value,prefix+'-definition',0 if role=='x1' else 1,'variable')
            val=label(f'{unit} = {plain(value)}',role).move_to([x,1.52,0]);self.add_label(val,role+'-unit-value')
            self.occurrence(val,role,value,prefix+'-definition',0 if role=='x1' else 1)
        self.add(Arrow([-1.45,2.82,0],[1.42,2.82,0],buff=.05,color=TOKENS['muted'],stroke_width=10,max_tip_length_to_length_ratio=.12))
        self.formula('{{ T : t }} = frac({{ '+plain(p['x1'])+' : a }} + {{ '+plain(p['x2'])+' : b }}, {{ '+str(c['sampleSize'])+' : n }})',
            [('t','stat',p['stat'],0,'variable'),('a','x1',p['x1'],0,'value'),('b','x2',p['x2'],1,'value'),('n','ink',exact(c['sampleSize']),2,'sample-size')],prefix+'-sub',.15)
        self.formula('{{ T : t }} = frac({{ '+plain(p['sum'])+' : s }}, {{ '+str(c['sampleSize'])+' : n }})',
            [('t','stat',p['stat'],0,'variable'),('s','ink',p['sum'],0,'sum'),('n','ink',exact(c['sampleSize']),1,'sample-size')],prefix+'-sum',-2.15)
        r=self.formula('{{ T : t }} = {{ '+plain(p['stat'])+' : r }}',
            [('t','stat',p['stat'],0,'variable'),('r','stat',p['stat'],1,'result')],prefix+'-result',-4.15,height=.75)
        diamond=Square(side_length=.55,color=TOKENS['stat'],stroke_width=10).rotate(PI/4).next_to(r,LEFT,buff=.45);self.add(diamond)
        self.add_label(label('相加，再除以样本量').move_to([0,-5.35,0]),'mapping-operation')
        self.record['pathIds']=[p['id']];self.record['barIds']=[]
        self.record['lineIds']=[prefix+s for s in ['-sub','-sum','-result']]

    def bars(self,c,p):
        target=next(b for b in c['bars'] if p['id'] in b['pathIds'])
        axis=Axes(x_range=[0,10,1],y_range=[0,1/3,1/9],x_length=7.1,y_length=4.5,tips=False,
            axis_config={'color':TOKENS['muted'],'stroke_width':6,'include_ticks':False,'include_numbers':False})
        axis.shift([-3.25,-1.64,0]-axis.c2p(0,0));self.add(axis)
        self.add_label(label('概率').move_to([-3.72,3.65,0]),'probability-axis')
        for y in [Fraction(0),Fraction(1,9),Fraction(2,9),Fraction(1,3)]:
            pt=axis.c2p(0,float(y));self.add(Line(pt+LEFT*.08,pt+RIGHT*7.1,color=TOKENS['line'] if y else TOKENS['muted'],stroke_width=5 if y else 6))
            tick=math(inline(exact(y)),height=.62).next_to(pt,LEFT,buff=.18);self.add_label(tick,'y-tick-'+str(y),'math')
        for b in c['bars']:
            x=float(rat(b['value'])); y=float(rat(b['probability']));base=axis.c2p(x,0);top=axis.c2p(x,y)
            selected=b['id']==target['id']
            if y:
                bar=Rectangle(width=.77,height=top[1]-base[1],fill_color=TOKENS['stat'],fill_opacity=1 if selected else 0,
                    stroke_color=TOKENS['stat'],stroke_width=10 if selected else 9).move_to((base+top)/2);self.add(bar)
            else:
                bar=Circle(radius=.14,color=TOKENS['stat'],stroke_width=10,fill_color=TOKENS['surface'],fill_opacity=1).move_to(base);self.add(bar)
                self.add_label(math('0',height=.62).move_to(base+UP*.57),b['id']+'-zero','math')
            self.occurrence(bar,'stat',b['value'],b['lineId'],0,'bar',path=None)
            self.record['objects'][-1]['probability']=b['probability'];self.record['objects'][-1]['barId']=b['id'];self.record['objects'][-1]['pathId']=None
            tick=self.add_label(math(plain(b['value']),'stat').move_to(base+DOWN*.60),b['id']+'-value','math')
            self.occurrence(tick,'stat',b['value'],b['lineId'],0,'axis-value')
            self.record['objects'][-1]['pathId']=None
        statlabel=VGroup(Square(side_length=.37,color=TOKENS['stat'],stroke_width=9).rotate(PI/4),label('均值 T','stat')).arrange(RIGHT,buff=.2).move_to([.4,-2.94,0]);self.add_label(statlabel,'statistic-axis')
        # A separate lower panel answers which paths contribute to the filled bar.
        self.add(Line([-4.5,-3.47,0],[4.5,-3.47,0],color=TOKENS['line'],stroke_width=5))
        preimage=[]
        for pid in target['pathIds']:
            q=next(q for q in c['paths'] if q['id']==pid)
            g=VGroup(label(q['firstId'],'x1'),label(q['secondId'],'x2')).arrange(RIGHT,buff=.08)
            preimage.append(g)
        pg=VGroup(*preimage).arrange(RIGHT,buff=.55).move_to([0,-4.12,0]);self.add_label(pg,'target-preimage')
        for pid,g in zip(target['pathIds'],pg):
            q=next(q for q in c['paths'] if q['id']==pid)
            for i,role in enumerate(['x1','x2']):
                self.occurrence(g[i],role,q[role],target['lineId'],i,'identity',q)
                self.record['objects'][-1]['occurrenceId']=f'{target["lineId"]}-{pid}-{role}-identity'
        selected_group=pg[target['pathIds'].index(p['id'])]
        self.add(Line(selected_group.get_corner(DL)+DOWN*.1,selected_group.get_corner(DR)+DOWN*.1,color=TOKENS['ink'],stroke_width=10))
        count=len(target['pathIds'])
        weight=next(q['weight'] for q in c['paths'] if q['id']==target['pathIds'][0])
        eq=math(f'{count} times ({inline(weight)}) = {inline(target["probability"])}',height=.62).move_to([0,-5.23,0]);self.add_label(eq,target['lineId'],'math')
        self.record['pathIds']=target['pathIds'];self.record['barIds']=[b['id'] for b in c['bars']]
        self.record['selectedPathId']=p['id'];self.record['targetBarId']=target['id']
        self.record['lineIds']=[b['lineId'] for b in c['bars']]+[p['linePrefix']+'-result',p['linePrefix']+'-weight']
        self.record['axis']={'xRange':[0,10],'xTicks':[plain(b['value']) for b in c['bars']],
            'yRange':[{'n':0,'d':1},{'n':1,'d':3}],'originPx':bbox(Dot(axis.c2p(0,0),radius=0))[:2],
            'xUnitsPerSceneUnit':10/7.1,'yUnitsPerSceneUnit':(1/3)/4.5}

    def save(self):
        self.renderer.update_frame(self,ignore_skipping=True)
        destination=OUT/'frames'/f'{self.record["frameId"]}.png'
        self.camera.get_image().save(destination)
        self.record.update({'relativePath':str(destination.relative_to(ROOT)),'path':str(destination.relative_to(ROOT)),
            'sha256':digest(destination),'hash':digest(destination),'width':1000,'height':1250,
            'dataHash':digest(DATA_FILE),'sceneSourceHash':digest(__file__)})
        self.record['renderedRoles']=[{'role':role,'token':TOKENS[role],
            'occurrenceIds':[o['occurrenceId'] for o in self.record['objects'] if o['role']==role]}
            for role in ['x1','x2','stat'] if any(o['role']==role for o in self.record['objects'])]
        FRAMES.append(self.record)
        print('FRAME',self.record['frameId'],flush=True)

    def overview_bars(self,c):
        ymax=Fraction(2,3) if c['base']=='task' else Fraction(1)
        xmin,xmax=(-1,3) if c['base']=='example' else (0,10)
        base=np.array([-3.25,-1.64,0.])
        # Independent numerical axes keep the x=0 bar away from the y-axis.
        xaxis=NumberLine(x_range=[xmin,xmax,1],length=7.1,include_ticks=False,include_numbers=False,
            color=TOKENS['muted'],stroke_width=6).move_to(base+RIGHT*3.55)
        yaxis=NumberLine(x_range=[0,float(ymax),float(ymax)/2],length=4.5,rotation=PI/2,
            include_ticks=False,include_numbers=False,color=TOKENS['muted'],stroke_width=6).move_to(base+UP*2.25)
        def xy(x,y):return xaxis.n2p(float(x))+UP*(yaxis.n2p(float(y))[1]-yaxis.n2p(0)[1])
        self.add(xaxis,yaxis)
        self.add_label(label('概率').move_to([-3.72,3.65,0]),'probability-axis')
        for y in [Fraction(0),ymax/2,ymax]:
            pt=yaxis.n2p(float(y));self.add(Line(pt,pt+RIGHT*7.1,color=TOKENS['line'] if y else TOKENS['muted'],stroke_width=5 if y else 6))
            self.add_label(math(inline(exact(y))).next_to(pt,LEFT,buff=.18),'y-tick-'+str(y),'math')
        for b in c['bars']:
            low=xy(rat(b['value']),0);high=xy(rat(b['value']),rat(b['probability']))
            if rat(b['probability']):
                bar=Rectangle(width=.90,height=high[1]-low[1],fill_color=TOKENS['stat'],fill_opacity=1,
                    stroke_color=TOKENS['stat'],stroke_width=10).move_to((low+high)/2)
            else:
                bar=Circle(radius=.14,color=TOKENS['stat'],stroke_width=10,fill_color=TOKENS['surface'],fill_opacity=1).move_to(low)
            self.add(bar);self.occurrence(bar,'stat',b['value'],b['lineId'],0,'bar')
            self.record['objects'][-1].update({'probability':b['probability'],'barId':b['id']})
            probability=math(inline(b['probability'])).move_to(high+UP*.68)
            self.add(Rectangle(width=probability.width+.16,height=probability.height+.10,
                fill_color=TOKENS['surface'],fill_opacity=1,stroke_width=0).move_to(probability))
            self.add_label(probability,b['id']+'-probability','math')
            self.occurrence(probability,'ink',b['probability'],b['lineId'],1,'probability')
            tick=self.add_label(math(plain(b['value']),'stat').move_to(low+DOWN*.60),b['id']+'-value','math')
            self.occurrence(tick,'stat',b['value'],b['lineId'],0,'axis-value')
        statname='均值 T' if c['statistic']=='mean' else '最大值 T'
        statlabel=VGroup(Square(side_length=.37,color=TOKENS['stat'],stroke_width=10).rotate(PI/4),label(statname,'stat')).arrange(RIGHT,buff=.2).move_to([.4,-2.94,0]);self.add_label(statlabel,'statistic-axis')
        self.add(Line([-4.5,-3.47,0],[4.5,-3.47,0],color=TOKENS['line'],stroke_width=5))
        self.add_label(label('互斥输出，概率相加').move_to([0,-4.15,0]),'normalization-reason')
        probability_sum=' + '.join(inline(b['probability']) for b in c['bars'])
        total=exact(sum(rat(b['probability']) for b in c['bars']))
        eq=math(probability_sum+' = '+inline(total)).move_to([0,-5.24,0])
        if eq.width>9:raise ValueError('Normalization formula too wide')
        self.add_label(eq,'normalization','math')
        self.record['pathIds']=[p['id'] for p in c['paths'] if p['allowed']]
        self.record['barIds']=[b['id'] for b in c['bars']]
        self.record['lineIds']=[b['lineId'] for b in c['bars']]
        self.record['axis']={'xRange':[xmin,xmax],'xTicks':[plain(b['value']) for b in c['bars']],
            'yRange':[exact(0),exact(ymax)],'plotLowerLeftPx':[175,789],'xUnitsPerSceneUnit':(xmax-xmin)/7.1,
            'yUnitsPerSceneUnit':float(ymax)/4.5}

    def construct(self):
        selected=os.environ.get('SAMPLING_FRAME_FILTER','')
        for c in DATA['conditions'].values():
            if c['base']!='main':
                fid=c['base']+'-'+c['mechanism']+'-overview-bars'
                if selected and fid not in selected.split(','):continue
                self.begin(c,None,'bars',fid);self.overview_bars(c);self.save();continue
            prefix='main-'+c['mechanism']
            jobs=[(None,'paths',prefix+'-overview-paths')]+[(p,s,p['linePrefix']+'-'+s) for p in c['paths'] if p['allowed'] for s in ['paths','mapping','bars']]
            for p,stage,fid in jobs:
                if selected and fid not in selected.split(','):continue
                self.begin(c,p,stage,fid);getattr(self,stage)(c,p);self.save()

def main():
    (OUT/'frames').mkdir(parents=True,exist_ok=True)
    planned=[]
    for c in DATA['conditions'].values():
        prefix=c['base']+'-'+c['mechanism']
        if c['base']=='main':
            planned.append({'frameId':prefix+'-overview-paths','conditionKey':c['id'],'stageId':'paths','selectedPathId':None})
            planned.extend({'frameId':p['linePrefix']+'-'+stage,'conditionKey':c['id'],'stageId':stage,'selectedPathId':p['id']}
                for p in c['paths'] if p['allowed'] for stage in ['paths','mapping','bars'])
        else:
            planned.append({'frameId':prefix+'-overview-bars','conditionKey':c['id'],'stageId':'bars','selectedPathId':None})
    (OUT/'frame-contract.json').write_text(json.dumps({'dataHash':digest(DATA_FILE),'frames':planned},ensure_ascii=False,indent=2))
    with register_font(str(FONT)), tempconfig({'renderer':'cairo','pixel_width':1000,'pixel_height':1250,
        'frame_width':10,'frame_height':12.5,'background_color':TOKENS['surface'],'write_to_movie':False,
        'save_last_frame':False,'media_dir':str(OUT/'manim-cache'),'text_dir':str(OUT/'manim-cache/texts'),
        'tex_dir':str(OUT/'manim-cache/Tex'),'typst_dir':str(OUT/'manim-cache/typst'),'verbosity':'WARNING',
        'progress_bar':'none'}):
        SamplingScene().render()
    manifest={'schemaVersion':1,'dataHash':digest(DATA_FILE),'sceneSourceHash':digest(__file__),
        'frameContractHash':digest(OUT/'frame-contract.json'),
        'manimVersion':manim.__version__,'renderer':'CairoRenderer','textRenderers':['Text/Pango','MathTypst/Typst'],
        'command':'source work/manim-runtime/env.sh && python generation/correction-run-02/sampling_scene.py',
        'font':str(FONT.relative_to(ROOT.parents[1])),'fontHash':digest(FONT),'frames':FRAMES}
    (ROOT/'media-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
