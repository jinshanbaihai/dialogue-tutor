from pathlib import Path
from PIL import Image
from fractions import Fraction as Q
from collections import defaultdict
import json,hashlib,math
import numpy as np
from scipy.ndimage import label,find_objects,map_coordinates
O=Path(__file__).resolve().parent;R=O/'frozen-inputs';D=json.loads((R/'exact-data.json').read_text());M=json.loads((R/'media-manifest.json').read_text());C=json.loads((R/'frame-contract.json').read_text())
rat=lambda r:Q(r['n'],r['d']);rgb=lambda h:np.array([int(h[i:i+2],16) for i in [1,3,5]])
P={k:rgb(v) for k,v in D['tokens'].items()};imgs={f['frameId']:Image.open(R/'frames'/Path(f['path']).name).convert('RGB') for f in M['frames']}
independent={};pathcount=0
for cid,c in D['conditions'].items():
 units={u['id']:rat(u['value']) for u in c['units']};n=len(units);pred={};dist=defaultdict(Q);pre=defaultdict(list)
 for aid,a in units.items():
  for bid,b in units.items():
   valid=c['mechanism']=='wr' or aid!=bid;weight=Q(1,n)*Q(1,n if c['mechanism']=='wr' else n-1) if valid else Q(0);v=(a+b)/2 if c['statistic']=='mean' else max(a,b);pred[aid+bid]=(a,b,a+b,v,valid,weight);dist[v]+=weight
   if valid:pre[v].append(aid+bid)
 for p in c['paths']:
  assert (rat(p['x1']),rat(p['x2']),rat(p['sum']),rat(p['stat']),p['allowed'],rat(p['weight']))==pred[p['id']]
  assert rat(p['firstProbability'])*rat(p['secondProbability'])==pred[p['id']][-1];pathcount+=1
 for b in c['bars']:assert rat(b['probability'])==dist[rat(b['value'])] and set(b['pathIds'])==set(pre[rat(b['value'])])
 independent[cid]={'distribution':{str(v):str(p) for v,p in sorted(dist.items())},'preimages':{str(v):p for v,p in pre.items()},'expectation':str(sum(v*p for v,p in dist.items()))}
assert [f['frameId'] for f in M['frames']]==[f['frameId'] for f in C['frames']]
glyphs=[];margins=[];bars=[];metadata=[]
for f,ct in zip(M['frames'],C['frames']):
 for k in ['frameId','conditionKey','stageId']:assert f[k]==ct[k]
 if f.get('selectedPathId')!=ct.get('selectedPathId'):metadata.append({'frameId':f['frameId'],'field':'selectedPathId','manifest':f.get('selectedPathId'),'contract':ct.get('selectedPathId'),'actualPathIds':f['pathIds']})
 im=imgs[f['frameId']];a=np.asarray(im);ys,xs=np.where(a.min(2)<180);margins.append({'frameId':f['frameId'],'left':int(xs.min()),'right':int(999-xs.max()),'top':int(ys.min()),'bottom':int(1249-ys.max())})
 for oi,o in enumerate(f['objects']):
  if o['kind'] in ['bar','axis-value']:continue
  x,y,w,h=o['bboxPx'];box=(math.floor(x),math.floor(y),math.ceil(x+w),math.ceil(y+h));crop=a[box[1]:box[3],box[0]:box[2]];fg=rgb(o['token']);delta=255-fg
  alpha=np.clip(((255-crop.astype(float))*delta).sum(2)/(delta*delta).sum(),0,1)
  # Color residual rejects crossing black exclusion strokes in blue/purple value glyphs.
  predicted=255-alpha[:,:,None]*delta;mask=(alpha>.5)&(np.max(abs(crop-predicted),axis=2)<12)
  ink_y,ink_x=np.where(mask);ink_height=int(ink_y.max()-ink_y.min()+1) if len(ink_y) else 0
  labs,num=label(mask);comps=[]
  for sl in find_objects(labs):
   yy,xx=sl;hh=yy.stop-yy.start;ww=xx.stop-xx.start
   if hh>=45 and ww>=5:comps.append({'bbox':[box[0]+xx.start,box[1]+yy.start,ww,hh],'height326':hh*.326})
  # Labels consist of individual bodies: equality strokes/commas are excluded explicitly.
  glyphs.append({'frameId':f['frameId'],'occurrenceId':o['occurrenceId'],'kind':o['kind'],'role':o['role'],'exact':o['exact'],'coloredInkRows':ink_height,'components':comps})
  if f['frameId'] in ['main-wr-BB-mapping','main-wr-AB-mapping'] and o['kind'] in ['value','sum','sample-size','result']:
   im.crop(box).save(O/f'body-{f["frameId"]}-{oi}.png')
 # independent filled/outlined bar geometry from actual color pixels, using values not author axis conversion.
 if f['stageId']=='bars':
  c=D['conditions'][f['conditionKey']];ymax=Q(1,3) if c['base']=='main' else Q(2,3) if c['base']=='task' else Q(1);xmin,xmax=(-1,3) if c['base']=='example' else (0,10)
  for b in c['bars']:
   xx=float(175+710*(rat(b['value'])-xmin)/(xmax-xmin));yt=float(789-450*rat(b['probability'])/ymax);bw=77 if c['base']=='main' else 90;selected=b['id']==f.get('targetBarId');solid=selected or c['base']!='main';edge=xx if solid else xx-bw/2
   if rat(b['probability'])==0:
    window=a[770:808,round(xx)-20:round(xx)+21];mask=np.max(abs(window.astype(int)-P['stat']),axis=2)<30;yy,zz=np.where(mask);cy=(yy.min()+yy.max())/2+770;assert abs(cy-789)<1.5;bars.append({'frameId':f['frameId'],'value':str(rat(b['value'])),'probability':'0','zeroCenterY':cy});continue
   sample_y=round((yt+789)/2);lo=round(xx-bw/2-10);hi=round(xx+bw/2+10);row=a[sample_y,lo:hi];ix=np.where(np.max(abs(row.astype(int)-P['stat']),axis=1)<30)[0]+lo;actual_cx=float((ix.min()+ix.max())/2);assert abs(actual_cx-xx)<1.5
   col=a[max(0,math.floor(yt)-10):790,round(edge)];mask=np.max(abs(col.astype(int)-P['stat']),axis=1)<30;yy=np.where(mask)[0]+max(0,math.floor(yt)-10);first=int(yy.min());assert abs(first-yt)<7
   bars.append({'frameId':f['frameId'],'value':str(rat(b['value'])),'probability':str(rat(b['probability'])),'expectedX':xx,'actualCenterX':actual_cx,'expectedTop':yt,'topTealPixel':first,'expectedHeight':789-yt,'measurementNote':'Stroke expands geometry by about half its width; first teal pixel is not centreline.'})
# Clean normal cross-sections; source and exact 326-width resampling, not parameter conversion.
spec=[('axis-y','main-wr-AB-bars',(175,410),(1,0),'muted',1.5),('axis-x','main-wr-AB-bars',(310,789),(0,1),'muted',1.5),('unselected-bar','main-wr-AB-bars',(491.5,590),(1,0),'stat',2.5),('current-cell','main-wr-AB-paths',(440,460),(1,0),'ink',3),('first-circle','main-wr-AB-mapping',(167,343),(1,0),'x1',2.5),('second-square','main-wr-AB-mapping',(657,320),(1,0),'x2',2.5),('zero-ring','main-wo-AB-bars',(246,775),(0,1),'stat',2.5),('exclusion-slash','main-wo-overview-paths',(230,510.714),(.5867,.8098),'ink',2.5),('grid','main-wr-overview-paths',(185,460),(1,0),'muted',1),('probability-grid','main-wr-AB-bars',(600,489),(0,1),'line',1),('T-diamond','main-wr-AB-bars',(439.596,905.919),(1,-1),'stat',2.5),('current-preimage-underline','main-wr-AB-bars',(430,1075),(0,1),'ink',3),('observation-arrow','main-wr-AB-mapping',(500,343),(0,1),'muted',2.5),('fraction-rule','main-wr-AB-mapping',(598,617.3),(0,1),'ink',1)]
lines=[]
for name,fid,xy,normal,color,floor in spec:
 for width in [1000,326]:
  im=imgs[fid];s=width/1000
  if width!=1000:im=im.resize((326,408),Image.Resampling.LANCZOS)
  a=np.asarray(im,dtype=float);n=np.array(normal,dtype=float);n/=np.linalg.norm(n);t=np.array([-n[1],n[0]]);center=(np.array(xy)+.5)*s-.5;ds=np.linspace(-8*s,8*s,601);values=[]
  for off in [-1,0,1]:
   co=center[:,None]+n[:,None]*ds+t[:,None]*off*s;pix=np.array([map_coordinates(a[:,:,k],[co[1],co[0]],order=1) for k in range(3)]).T;delta=255-P[color];alpha=np.clip(((255-pix)*delta).sum(1)/(delta*delta).sum(),0,1);values.append(float(np.trapezoid(alpha,ds)))
  lines.append({'class':name,'frameId':fid,'xy':xy,'width':width,'effectivePx':float(np.mean(values)),'threeSamples':values,'required':floor})
  if width==326:im.crop((int(xy[0]*s)-10,int(xy[1]*s)-10,int(xy[0]*s)+11,int(xy[1]*s)+11)).resize((168,168),Image.Resampling.NEAREST).save(O/f'line-{name}.png')
out={'independentMath':independent,'pathRecordsChecked':pathcount,'roleGlyphs':glyphs,'margins':margins,'bars':bars,'lines':lines,'metadataDifferences':metadata}
(O/'independent-probes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('paths',pathcount,'math',independent);print('metadata diffs',len(metadata));print('min margins',{k:min(m[k] for m in margins) for k in ['left','right','top','bottom']})
print('glyph component min',min(c['bbox'][3] for o in glyphs for c in o['components']),'empty glyph records',[g['occurrenceId'] for g in glyphs if not g['components']][:10])
for l in lines:print(l['class'],l['width'],round(l['effectivePx'],3),l['required'])
