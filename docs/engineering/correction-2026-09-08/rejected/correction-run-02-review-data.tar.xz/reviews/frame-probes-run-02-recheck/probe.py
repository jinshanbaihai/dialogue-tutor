from pathlib import Path
import json,hashlib,shutil
import numpy as np
from PIL import Image,ImageDraw
O=Path(__file__).resolve().parent;R=O.parents[1]/'generation/correction-run-02';OLD=O.parent/'frame-probes-run-02/frozen-inputs';F=O/'frozen-inputs';F.mkdir(exist_ok=True);(F/'frames').mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
M=json.loads((R/'media-manifest.json').read_text());C=json.loads((R/'media/frame-contract.json').read_text());B=json.loads((OLD/'media-manifest.json').read_text());bm={f['frameId']:f for f in B['frames']}
for src,dst in [('sampling_scene.py','sampling_scene.py'),('media-manifest.json','media-manifest.json'),('media/frame-contract.json','frame-contract.json'),('manim-render-report.md','manim-render-report.md'),('exact-data.json','exact-data.json'),('media/revision-m1-m2/final-hashes.json','author-final-hashes.json')]:shutil.copy2(R/src,F/dst)
scene=sha(R/'sampling_scene.py');checks=[];changed=[];mapping=[]
for f in M['frames']:
 p=R/f['path'];assert sha(p)==f['sha256']==f['hash'];assert f['sceneSourceHash']==scene;assert Image.open(p).size==(1000,1250)
 shutil.copy2(p,F/'frames'/p.name)
 change=sha(p)!=bm[f['frameId']]['sha256'];checks.append({'frameId':f['frameId'],'sha256':sha(p),'changed':change})
 if not change:continue
 assert f['conditionKey']=='main-wo-mean-v1' and f['stageId']=='paths'
 a=np.array(Image.open(p).convert('RGB'));b=np.array(Image.open(OLD/'frames'/p.name).convert('RGB'));mask=a.min(2)<180;ys,xs=np.where(np.any(a!=b,axis=2));rows=np.where(mask.any(1)&(np.arange(1250)>1000))[0];runs=np.split(rows,np.where(np.diff(rows)>1)[0]+1);runs=[(int(t[0]),int(t[-1])) for t in runs if len(t)]
 assert np.array_equal(a[:1120],b[:1120]);assert np.array_equal(a[1120:1220],b[1129:1229])
 last=runs[-1];prev=runs[-2];changed.append({'frameId':f['frameId'],'diffBBox':[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())],'inkRowRunsAfter1000':runs,'bottomPx':1249-last[1],'gapPx':last[0]-prev[1]-1,'footerPixelExactTranslationY':-9,'upperPixelsUnchanged':True})
 im=Image.fromarray(a);im.resize((326,408),Image.Resampling.LANCZOS).save(O/(f['frameId']+'-326.png'));im.crop((0,1020,1000,1250)).save(O/(f['frameId']+'-footer-source.png'))
for cf in C['frames']:
 if cf['stageId']!='mapping':continue
 key=(cf['conditionKey'],cf['selectedPathId'],cf['stageId']);matches=[f for f in M['frames'] if (f['conditionKey'],f.get('selectedPathId'),f['stageId'])==key];assert len(matches)==1
 f=matches[0];assert f['frameId']==cf['frameId'] and f['pathIds']==[key[1]]
 assert f['objects']==bm[f['frameId']]['objects'];assert f['labels']==bm[f['frameId']]['labels']
 mapping.append({'key':key,'match':f['frameId'],'count':len(matches),'pngUnchanged':f['sha256']==bm[f['frameId']]['sha256'],'objectsAndLabelsUnchanged':True})
assert len(checks)==51 and len(changed)==7 and len(mapping)==15
out={'inputHashes':{p.name:sha(p) for p in F.iterdir() if p.is_file()},'frames':checks,'mappingLookups':mapping,'changedFrames':changed,'unchangedPNGCount':sum(not f['changed'] for f in checks)}
(O/'independent-recheck.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
for start in [0,4]:
 batch=changed[start:start+4];s=Image.new('RGB',(326*len(batch),432),'#eeeeee');draw=ImageDraw.Draw(s)
 for i,r in enumerate(batch):draw.text((i*326+4,4),r['frameId'],fill='black');s.paste(Image.open(O/(r['frameId']+'-326.png')),(326*i,24))
 s.save(O/f'sheet-{start//4+1}.png')
print(json.dumps({'unchanged':out['unchangedPNGCount'],'mapping':len(mapping),'changedFrames':changed},ensure_ascii=False,indent=2))
H=json.loads((R/'media/revision-m1-m2/final-hashes.json').read_text())
for name,h in H['files'].items():assert sha(R/name)==h
for f in H['pngs']:assert sha(R/f['relativePath'])==f['sha256']
assert len(H['pngs'])==51 and H['dataHash']==sha(R/'exact-data.json')
out['authorFinalInventoryIndependentlyMatched']=True
out['viewCoverage']={'allSevenAt326':'sheet-1.png and sheet-2.png actually opened; each child 326x408','sourceFooterActuallyOpened':['main-wo-overview-paths'],'unchanged44':'reuse previous hash-identical independent review, not claimed newly opened'}
(O/'independent-recheck.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
