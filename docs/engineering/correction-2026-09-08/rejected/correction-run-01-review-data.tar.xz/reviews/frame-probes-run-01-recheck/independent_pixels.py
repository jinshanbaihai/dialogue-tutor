from pathlib import Path
from PIL import Image
import json, math
import numpy as np
from scipy.ndimage import map_coordinates, label, find_objects
O=Path(__file__).resolve().parent;R=O/'frozen-inputs';M=json.loads((R/'manim-manifest.json').read_text())
INK=(32,44,57);TEAL=(15,112,116);BLUE=(35,100,170);PURPLE=(114,80,164);GRID=(212,216,220);MUTED=(88,102,116)
imgs={f['frameId']:Image.open(R/'frames'/Path(f['file']).name).convert('RGB') for f in M['frames']}
# Bounds only locate glyphs. Actual dark pixel rows, not geometry height, determine body height.
glyphs=[];bottom=[];roles=[]
for f in M['frames']:
 a=np.asarray(imgs[f['frameId']]);ys,xs=np.where(a.min(2)<180)
 bottom.append({'frameId':f['frameId'],'lastInkRow':int(ys.max()),'blankBottomRows':int(1249-ys.max()),'leftInk':int(xs.min()),'rightInk':int(xs.max())})
 expect=['first-observation','second-observation'] if f['kind']=='grid' else ['first-observation','second-observation','statistic'] if f['kind']=='mean' else ['statistic']
 assert f['renderedRoles']==expect
 assert f['objectsMeaning']=='semantic mapping; not an inventory of visible glyphs'
 roles.append({'frameId':f['frameId'],'renderedRoles':expect})
 for ti,t in enumerate(f['textObjects']):
  if t['type']!='Text':continue
  assert ''.join(g['character'] for g in t['asciiGlyphBodies'])==''.join(c for c in t['text'] if c.isascii() and c.isalnum())
  for gi,g in enumerate(t['asciiGlyphBodies']):
   x,y,w,h=g['bounds'];x0=math.floor(x);y0=math.floor(y);x1=math.ceil(x+w);y1=math.ceil(y+h)
   crop=a[y0:y1,x0:x1]; yy,xx=np.where(crop.min(2)<180)
   hh=int(yy.max()-yy.min()+1);threshold=49 if g['character'].isdigit() else 55
   glyphs.append({'frameId':f['frameId'],'textIndex':ti,'text':t['text'],'character':g['character'],'crop':[x0,y0,x1,y1],'actualDarkPixelRows':hh,'requiredSourceRows':threshold,'px328':hh*.328,'px358':hh*.358,'pass':hh>=threshold})
   if f['frameId'] in ['main-wr-overview','main-wr-AB-mapping','main-wr-AB-grouping']:
    Image.fromarray(crop).resize((crop.shape[1]*4,crop.shape[0]*4),Image.Resampling.NEAREST).save(O/f'body-{f["frameId"]}-{ti}-{gi}.png')
# Direct normals sample rendered pixels with bilinear interpolation; integrate inferred foreground coverage.
# Three tangent offsets expose antialiasing phase; bar uses the teal interior as background.
specs=[
 ('axis-y','main-wr-AB-grouping',(220,480),(1,0),INK,1.5,12,None),
 ('axis-x','main-wr-AB-grouping',(330,750),(0,1),INK,1.5,12,None),
 ('tick','main-wr-AB-grouping',(562.5,760),(1,0),INK,1.5,12,None),
 ('first-circle','main-wr-overview',(186,460),(1,0),BLUE,2.5,12,None),
 ('second-square','main-wr-overview',(314,310),(1,0),PURPLE,2.5,12,None),
 ('statistic-diamond','main-wr-AB-grouping',(170.052,1030.052),(2**-.5,2**-.5),TEAL,2.5,12,None),
 ('zero-ring','main-nr-distribution',(262.8125,739),(0,1),MUTED,2.5,7,None),
 ('current-cell','main-wr-AB-paths',(488,460),(1,0),TEAL,3,12,None),
 ('current-bar','main-wr-AB-grouping',(373.65625,600),(1,0),INK,3,12,TEAL),
 ('exclusion-cross','main-nr-overview',(299,413.6),(-58/math.hypot(70,58),70/math.hypot(70,58)),(140,74,37),2.5,12,(238,237,232)),
 ('cell-grid','main-wr-overview',(258,615),(1,0),GRID,1,10,None),
 ('probability-guide','main-wr-AB-grouping',(330,415),(0,1),GRID,1,10,None),
 ('fraction-rule','main-wr-AB-mapping',(570,477.57),(0,1),INK,1,10,None)]
lines=[]
for name,fid,xy,normal,fg,floor,radius,inside in specs:
 for width in [1000,328,358]:
  im=imgs[fid];s=width/1000
  if width!=1000:im=im.resize((width,round(1250*s)),Image.Resampling.LANCZOS)
  a=np.asarray(im,dtype=float);n=np.array(normal);t=np.array([-n[1],n[0]]);center=(np.array(xy)+.5)*s-.5
  ds=np.linspace(-radius*s,radius*s,601);vals=[]
  for tangent in [-1,0,1]:
   coords=center[:,None]+n[:,None]*ds+t[:,None]*(tangent*s)
   pix=np.array([map_coordinates(a[:,:,k],[coords[1],coords[0]],order=1) for k in range(3)]).T
   bg=np.full_like(pix,255.)
   if name=='current-bar':bg[ds>0]=inside
   if name=='exclusion-cross':bg[:]=inside
   v=bg-np.array(fg);alpha=np.clip(((bg-pix)*v).sum(1)/(v*v).sum(1),0,1)
   vals.append(float(np.trapz(alpha,ds)))
  lines.append({'class':name,'frameId':fid,'sourceXY':xy,'targetWidth':width,'effectivePxThreeNormals':vals,'meanEffectivePx':float(np.mean(vals)),'requiredPx':floor,'pass':bool(np.mean(vals)>=floor) if width!=1000 else None})
  if width==328:
   box=(int(xy[0]*s)-12,int(xy[1]*s)-12,int(xy[0]*s)+13,int(xy[1]*s)+13)
   im.crop(box).resize((200,200),Image.Resampling.NEAREST).save(O/f'line-crop-{name}-328.png')
# Palette from actual common interior pixels and visual semantic mapping; WCAG formula locally evaluated.
def lum(rgb):
 v=np.array(rgb)/255;v=np.where(v<=.04045,v/12.92,((v+.055)/1.055)**2.4);return float(v@np.array([.2126,.7152,.0722]))
palette={str(c):1.05/(lum(c)+.05) for c in [INK,TEAL,BLUE,PURPLE,MUTED,(81,151,154)]}
out={'method':'Independent PNG pixel scans; metadata bounds locate Text glyphs only; foreground coverage normal integral for lines. No author helper imported.','asciiGlyphCount':len(glyphs),'asciiGlyphs':glyphs,'lines':lines,'bottom':bottom,'renderedRoles':roles,'contrastOnWhite':palette}
(O/'independent-pixels.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('glyphs',len(glyphs),'failures',[g for g in glyphs if not g['pass']]);print('digit min',min(g['actualDarkPixelRows'] for g in glyphs if g['character'].isdigit()),'capital min',min(g['actualDarkPixelRows'] for g in glyphs if g['character'].isalpha()))
print('bottom min',min(b['blankBottomRows'] for b in bottom),'contrast',palette)
for r in lines:
 if r['targetWidth']!=1000:print(r['class'],r['targetWidth'],round(r['meanEffectivePx'],3),r['pass'])
