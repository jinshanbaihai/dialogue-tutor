from pathlib import Path
from PIL import Image,ImageDraw
import json,math
import numpy as np
from fractions import Fraction as Q
from scipy.ndimage import label,find_objects
O=Path(__file__).resolve().parent;R=O/'frozen-inputs';M=json.loads((R/'manim-manifest.json').read_text());D=json.loads((R/'exact-math.json').read_text())
q=lambda d:Q(d['numerator'],d['denominator'])
fractions=[];bars=[]
for f in M['frames']:
 im=Image.open(R/'frames'/Path(f['file']).name).convert('RGB');a=np.asarray(im)
 for ti,t in enumerate(f['textObjects']):
  if t['type']!='MathTypst':continue
  for ri,(rx,ry,rw,rh) in enumerate(t['fractionRuleBounds']):
   tx,ty,tw,th=t['bounds']
   for side,(y0,y1) in [('numerator',(math.floor(ty)-1,math.floor(ry)-8)),('denominator',(math.ceil(ry)+8,math.ceil(ty+th)+1))]:
    x0=math.floor(rx)-1;x1=math.ceil(rx+rw)+1
    mask=a[y0:y1,x0:x1].min(2)<180;lab,n=label(mask);components=[]
    for sl in find_objects(lab):
     yy,xx=sl;h=yy.stop-yy.start;w=xx.stop-xx.start
     # True digit/cap bodies in these display fractions are above 50 rows;
     # plus-sign spans are separately visibly inspected, not used as digit evidence.
     if h>=50 and w>=5:components.append({'bounds':[x0+xx.start,y0+yy.start,w,h],'rows':h})
    assert components,(f['frameId'],ti,ri,side)
    fractions.append({'frameId':f['frameId'],'textIndex':ti,'ruleIndex':ri,'side':side,'components':components})
    if f['frameId'] in ['main-nr-overview','main-wr-AB-mapping','repair-weight-distribution']:
     im.crop((x0,y0,x1,y1)).save(O/f'fraction-{f["frameId"]}-{ti}-{ri}-{side}.png')
 if f['kind']=='bars' and not f['pathId']:
  c=D['cases'][f['caseId']];vals=[q(b['value']) for b in c['distribution']];main=f['caseId'] in ['main-wr','main-nr'];lo,hi=(Q(2),Q(6)) if main else (min(vals),max(vals));span=hi-lo;amin=lo-span/14;amax=hi+span/14;ymax=Q(1,3) if main else max(q(b['probability']) for b in c['distribution'])
  # Fill pixels independently locate segment centres and vertical extents, no author coordinate routine.
  teal=np.max(np.abs(a.astype(int)-np.array([81,151,154])),axis=2)<=2
  for b in c['distribution']:
   ex=float(220+685*(q(b['value'])-amin)/(amax-amin));ey=float(750-335*q(b['probability'])/ymax);x=round(ex)
   ys=np.where(teal[410:750,x])[0]+410;top=int(ys.min());row=teal[min(749,top+20)];xs=np.where(row[max(0,x-50):x+51])[0]+max(0,x-50);cx=float((xs.min()+xs.max())/2)
   assert abs(top-ey)<5 and abs(cx-ex)<2,(f["frameId"],str(q(b["value"])),ex,cx,ey,top)
   bars.append({'frameId':f['frameId'],'value':str(q(b['value'])),'probability':str(q(b['probability'])),'expectedCenterX':ex,'actualFillCenterX':cx,'expectedTopY':ey,'actualFillTopY':top,'expectedHeight':750-ey})
(O/'fraction-bodies-and-geometry.json').write_text(json.dumps({'fractions':fractions,'bars':bars},indent=2))
print('fraction numerator/denominator regions',len(fractions),'body min/max',min(z['rows'] for f in fractions for z in f['components']),max(z['rows'] for f in fractions for z in f['components']))
print('distribution bars independently measured',len(bars));print(json.dumps(bars,indent=2))
# Evidence montage only: 328-width originals retained unchanged within review derivatives.
names=['line-crop-axis-y-328','line-crop-current-bar-328','line-crop-first-circle-328','line-crop-exclusion-cross-328','line-crop-probability-guide-328','body-main-wr-overview-19-1','body-main-wr-AB-mapping-5-0','body-main-wr-AB-mapping-11-0']
out=Image.new('RGB',(880,540),'#dddddd');dr=ImageDraw.Draw(out)
for i,n in enumerate(names):
 x=(i%4)*220;y=(i//4)*270;dr.text((x+5,y+5),n.replace('line-crop-','').replace('body-main-wr-',''),fill='black');pic=Image.open(O/(n+'.png'));out.paste(pic,(x+5,y+25))
out.save(O/'probe-crops.png')
