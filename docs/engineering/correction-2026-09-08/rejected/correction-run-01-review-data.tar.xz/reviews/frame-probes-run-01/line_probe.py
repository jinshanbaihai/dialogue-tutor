from PIL import Image,ImageDraw
from pathlib import Path
import json,numpy as np
R=Path('reviews/frame-probes-run-01/frozen-inputs/frames');O=Path('reviews/frame-probes-run-01')
def scan(file,xy,direction,color,width):
 im=Image.open(file).convert('RGB');a=np.array(im,dtype=float);x,y=xy
 pixels=a[y,x-8:x+9] if direction=='vertical' else a[y-8:y+9,x]
 rgb=np.array(color);alpha=((255-pixels)*(255-rgb)).sum(axis=1)/((255-rgb)**2).sum();alpha=np.clip(alpha,0,1)
 return {'file':str(file),'xy':[x,y],'direction':direction,'targetWidth':width,'pixels':pixels.astype(int).tolist(),'effectiveWidthPx':float(sum(alpha)),'supportPixelsOverHalfInk':int(sum(alpha>.5))}
res=[]
# Isolated cross-sections away from labels, ticks and filled bars.
for width in [1000,328,358]:
 scale=width/1000
 for name,xy,di,color in [('main-wr-AB-grouping',(220,600),'vertical',(32,44,57)),('main-wr-AB-grouping',(330,775),'horizontal',(32,44,57)),('main-wr-AB-grouping',(372,590),'vertical',(32,44,57)),('main-wr-AB-paths',(488,460),'vertical',(15,112,116))]:
  file=R/f'{name}.png' if width==1000 else O/f'{name}-{width}.png'
  xx,yy=[round(z*scale) for z in xy];res.append(scan(file,(xx,yy),di,color,width))
# Pixel crops are enlarged with nearest neighbor only for inspecting sampling; originals remain available.
for name,box in [('main-wr-AB-grouping',(205,580,238,635)),('main-wr-AB-grouping',(320,760,350,790)),('main-wr-AB-paths',(478,430,498,490)),('main-nr-overview',(285,1040,710,1250))]:
 im=Image.open(R/f'{name}.png');crop=im.crop(box);p=O/f"detail-{name}-{box[0]}-{box[1]}.png";crop.save(p);crop.resize((crop.width*3,crop.height*3),Image.Resampling.NEAREST).save(O/f"detail3x-{name}-{box[0]}-{box[1]}.png")
(O/'line-sections.json').write_text(json.dumps(res,indent=2))
for r in res:print(r['file'],r['xy'],r['direction'],round(r['effectiveWidthPx'],3),r['supportPixelsOverHalfInk'])
# Bottom non-white numerical ink extent on grid footer.
a=np.asarray(Image.open(R/'main-nr-overview.png').convert('RGB'));mask=(a[1040:,:,:].min(axis=2)<180);ys,xs=np.where(mask);print('footer ink max y',ys.max()+1040,'bottom white rows',1249-(ys.max()+1040))
# All non-background colors at bars/role interiors and contrast with white.
def lum(rgb):
 v=np.array(rgb)/255;v=np.where(v<=.04045,v/12.92,((v+.055)/1.055)**2.4);return float(v@np.array([.2126,.7152,.0722]))
for name,xy in [('main-wr-AB-grouping',(265,700)),('main-wr-AB-grouping',(410,600)),('main-wr-AB-mapping',(545,415))]:
 pix=Image.open(R/f'{name}.png').convert('RGB').getpixel(xy);print('sample',name,xy,pix,1.05/(lum(pix)+.05))
