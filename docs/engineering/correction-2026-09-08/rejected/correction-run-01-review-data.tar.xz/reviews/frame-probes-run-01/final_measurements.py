from pathlib import Path
from PIL import Image
import numpy as np,json
O=Path('reviews/frame-probes-run-01');R=O/'frozen-inputs';M=json.loads((R/'manim-manifest.json').read_text());C=json.loads((R/'frame-contract.json').read_text())
# Clean isolated vertical axis section; y=450 avoids neighbouring bar labels.
clean=[]
for w in [1000,328,358]:
 p=R/'frames/main-wr-AB-grouping.png' if w==1000 else O/f'main-wr-AB-grouping-{w}.png'
 a=np.asarray(Image.open(p),dtype=float);x=round(220*w/1000);y=round(450*w/1000);rgb=a[y,x-4:x+5];fg=np.array([32,44,57]);alpha=np.clip(((255-rgb)*(255-fg)).sum(1)/sum((255-fg)**2),0,1)
 clean.append({'width':w,'xy':[x,y],'RGB':rgb.astype(int).tolist(),'coverageEquivalentPixels':float(sum(alpha))})
(O/'clean-axis-probe.json').write_text(json.dumps(clean,indent=2))
# Coverage records now state precisely which viewing layers were actually completed.
coverage=json.loads((O/'frame-coverage.json').read_text())
full={'main-nr-overview','main-wr-AB-mapping','main-wr-AB-grouping','repair-weight-distribution','main-nr-distribution','duplicates-distribution','example-max-distribution'}
for f in coverage:
 f['viewed328ContactSheet']=True;f['viewed358ContactSheet']=True;f['viewedFullSource']=f['frameId'] in full
 f['visualObservation']='Selected cell/pair/target bar and caption correspond; no detected clipping or conflicting numerical labels.'
 f['disposition']='REVISE common axis/emphasis stroke widths' if f['kind']=='bars' or f['pathId'] else 'Grid text readable; common bottom margin minor'
(O/'frame-coverage.json').write_text(json.dumps(coverage,indent=2))
# All contract entries reread compactly, plus source generated text declarations.
for i,f in enumerate(M['frames']):
 print(i+1,f['frameId'],f['lineIds'],f['pathIds'],f['barIds'])
 print('text:',[(t.get('text') or t.get('source')) for t in f['textObjects']])
# Exact repeated main axis metadata and pixel dimensions.
axes=[f['axis'] for f in M['frames'] if f['caseId'] in ['main-wr','main-nr'] and f['kind']=='bars'];assert all(a==axes[0] for a in axes);print('shared main axes',axes[0])
print('clean axes',clean)
