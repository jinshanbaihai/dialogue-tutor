from pathlib import Path
from PIL import Image,ImageDraw
from fractions import Fraction as Q
from collections import defaultdict
import json,hashlib,math
import numpy as np
from scipy.ndimage import label,find_objects
O=Path('reviews/frame-probes-run-01');R=O/'frozen-inputs'
D=json.loads((R/'exact-math.json').read_text());C=json.loads((R/'frame-contract.json').read_text());M=json.loads((R/'manim-manifest.json').read_text())
q=lambda d:Q(d['numerator'],d['denominator'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[];expected={}
# Independent enumeration from unit identity and stated uniform mechanism, no author helper import.
for cid,c in D['cases'].items():
 units={u['id']:q(u['value']) for u in c['units']}; n=len(units);paths={};dist=defaultdict(Q)
 for aid,a in units.items():
  for bid,b in units.items():
   if not c['replacement'] and aid==bid:continue
   prob=Q(1,n)*Q(1,n if c['replacement'] else n-1)
   t=(a+b)/2 if c['statistic']=='mean' else max(a,b)
   paths[aid+bid]=(a,b,t,prob);dist[t]+=prob
 assert {p['id']:(q(p['values'][0]),q(p['values'][1]),q(p['statisticValue']),q(p['probability'])) for p in c['paths']}==paths
 assert {q(b['value']):q(b['probability']) for b in c['distribution']}==dist
 for p in c['paths']:
  a,b,t,prob=paths[p['id']];assert q(p['sum'])==a+b;assert q(p['conditionalFactors'][0])*q(p['conditionalFactors'][1])==prob
 for b in c['distribution']:assert set(b['pathIds'])=={pid for pid,v in paths.items() if v[2]==q(b['value'])}
 expected[cid]={'units':{k:str(v) for k,v in units.items()},'replacement':c['replacement'],'statistic':c['statistic'],'distribution':{str(k):str(v) for k,v in sorted(dist.items())},'expectation':str(sum(k*v for k,v in dist.items()))}
assert [x['frameId'] for x in M['frames']]==[x['frameId'] for x in C['frames']]
math_components=[]
for i,(f,c) in enumerate(zip(M['frames'],C['frames'])):
 for k,v in c.items():assert f[k]==v,(f['frameId'],k)
 p=R/'frames'/Path(f['file']).name;im=Image.open(p).convert('RGB');assert im.size==(1000,1250);assert sha(p)==f['sha256']
 for width in [328,358]:
  dest=O/f"{f['frameId']}-{width}.png";im.resize((width,round(1250*width/1000)),Image.Resampling.LANCZOS).save(dest)
 for ti,t in enumerate(f['textObjects']):
  if t['type']!='MathTypst':continue
  x,y,w,h=t['bounds'];box=(max(0,math.floor(x)-2),max(0,math.floor(y)-2),min(1000,math.ceil(x+w)+2),min(1250,math.ceil(y+h)+2));crop=im.crop(box)
  arr=np.asarray(crop);mask=arr.min(axis=2)<180
  labs,num=label(mask);comps=[]
  for sl in find_objects(labs):
   yy,xx=sl;hh=yy.stop-yy.start;ww=xx.stop-xx.start
   if hh>=15 and ww>=5:comps.append({'box':[box[0]+xx.start,box[1]+yy.start,ww,hh],'height328':hh*.328,'height358':hh*.358})
  math_components.append({'frameId':f['frameId'],'textIndex':ti,'source':t['source'],'crop':box,'components':comps})
  if f['frameId'] in ['main-wr-AB-mapping','main-nr-overview','repair-weight-distribution','main-wr-AB-grouping']:
   crop.save(O/f"crop-{f['frameId']}-{ti}.png")
 checks.append({'index':i+1,'frameId':f['frameId'],'kind':f['kind'],'pathId':f['pathId'],'barIds':f['barIds'],'sourceSha256':f['sha256'],'sheet328':i//6+1,'sheet358':i//6+1})
for width in (328,358):
 for start in range(0,55,6):
  fs=M['frames'][start:start+6];cw=width+12;ch=round(1250*width/1000)+28
  sheet=Image.new('RGB',(cw*3,ch*2),'#d6d6d6');dr=ImageDraw.Draw(sheet)
  for j,f in enumerate(fs):
   x=(j%3)*cw+6;y=(j//3)*ch;dr.text((x,y+4),f['frameId'],fill='black');sheet.paste(Image.open(O/f"{f['frameId']}-{width}.png"),(x,y+22))
  sheet.save(O/f'sheet-{width}-{start//6+1:02}.png')
(O/'independent-math.json').write_text(json.dumps(expected,indent=2,ensure_ascii=False))
(O/'frame-coverage.json').write_text(json.dumps(checks,indent=2))
(O/'glyph-components.json').write_text(json.dumps(math_components,indent=2))
(O/'input-hashes.json').write_text(json.dumps({n:sha(R/n) for n in ['exact-math.json','frame-contract.json','manim_scene.py','manim-manifest.json','render-log.txt','visual-read-coverage.md']},indent=2))
print('independent expectation/distribution:',json.dumps(expected,ensure_ascii=False));print('55 hashes/contracts checked; generated 20 contact sheets, 110 scaled images, glyph-component JSON and selected crops')
print('CONTRACT non-frame requirements', {k:v for k,v in C.items() if k!='frames'})
print('small component height range',min(cc['box'][3] for t in math_components for cc in t['components']),max(cc['box'][3] for t in math_components for cc in t['components']))
