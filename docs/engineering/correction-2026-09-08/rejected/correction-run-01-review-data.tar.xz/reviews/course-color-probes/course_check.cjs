const fs=require('fs'),path=require('path'),assert=require('assert'),crypto=require('crypto');
const {JSDOM,VirtualConsole}=require('../../repo/node_modules/jsdom');
const O=__dirname,R=path.resolve(O,'../../generation/correction-run-01');
const html=fs.readFileSync(path.join(R,'lesson.html'),'utf8'),lesson=JSON.parse(fs.readFileSync(path.join(R,'lesson.json'))),M=JSON.parse(fs.readFileSync(path.join(R,'manim-manifest.json'))),D=JSON.parse(fs.readFileSync(path.join(R,'exact-math.json')));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');const byHash=new Map(M.frames.map(f=>[f.sha256,f]));const sleep=()=>new Promise(r=>setTimeout(r,10));
let out={scope:'Independent static DOM + actual JS events in jsdom. Image load is explicitly simulated; no layout, actual decoding, native MathML or browser screenshot claim.',inputHashes:{html:sha(Buffer.from(html)),json:sha(fs.readFileSync(path.join(R,'lesson.json')))}},errors=[];
let vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));let pending=[];
const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://independent-review.invalid/',virtualConsole:vc,beforeParse(w){w.HTMLElement.prototype.scrollIntoView=function(){};w.Image=class{set src(v){this._src=v;pending.push(this)}get src(){return this._src}};}}),w=dom.window,doc=w.document;
const flush=()=>{let p=pending.splice(0);p.forEach(i=>i.onload?.())};
const click=s=>{let e=doc.querySelector(s);assert(e,s);assert(!e.disabled,'disabled '+s);e.click()};
const change=(s,v)=>{let e=doc.querySelector(s);assert(e,s);if(e.tagName==='SELECT')e.value=v;else e.checked=true;e.dispatchEvent(new w.Event('change',{bubbles:true}))};
function ancestry(e){let a=[];for(let n=e;n;n=n.parentElement)a.push(n.tagName.toLowerCase()+(n.id?'#'+n.id:'')+(n.className?'.'+n.className:''));return a;}
(async()=>{
 await sleep();flush();await sleep();assert.deepEqual(errors,[]);assert.equal(doc.querySelectorAll('[data-dt-mounted=true]').length,28);
 out.controls=[...doc.querySelectorAll('[data-dt-activity]')].filter(e=>e.dataset.dtMounted==='true').map(e=>({activityId:e.dataset.dtActivity,title:e.querySelector('h3,h2')?.textContent,controls:[...e.querySelectorAll('button,input,select,summary')].map(c=>({tag:c.tagName,type:c.type,label:(c.getAttribute('aria-label')||c.textContent||c.closest('label')?.textContent||'').trim().slice(0,180),name:c.name,value:c.value,attributes:Object.fromEntries([...c.attributes].filter(a=>a.name.startsWith('data-')).map(a=>[a.name,a.value]))}))}));
 out.staticImages=[];for(let i of doc.querySelectorAll('img:not([data-explorer-image])')){let h=sha(Buffer.from(i.src.split(',')[1],'base64'));assert(byHash.has(h));out.staticImages.push({frameId:byHash.get(h).frameId,sha256:h,ancestors:ancestry(i),alt:i.alt})}
 out.explorer=[];
 for(const cid of ['main-wr','main-nr']){
  click(`#sampling-explorer [data-condition="${cid}"]`);flush();let s=w.CourseInspect.getState('sampling-explorer');assert.equal(s.currentFrame,cid+'-overview');
  for(let p of D.cases[cid].paths){
   click(`#sampling-explorer [data-path="${p.id}"]`);flush();
   for(let stage of ['paths','mapping','grouping']){
    click(`#sampling-explorer [data-stage="${stage}"]`);flush();let fid=`${cid}-${p.id}-${stage}`,state=w.CourseInspect.getState('sampling-explorer'),meta=w.CourseInspect.frameContract(fid),im=doc.querySelector('[data-explorer-image]');assert.equal(state.currentFrame,fid);assert.equal(sha(Buffer.from(im.src.split(',')[1],'base64')),M.frames.find(f=>f.frameId===fid).sha256);assert(!im.hidden);assert(!doc.querySelector('[data-explorer-formula]').hidden);assert(!doc.querySelector('[data-explorer-target]').hidden);let anchor=doc.querySelector('[data-explorer-line]').getAttribute('href');assert(stage==='paths'?anchor==='#'+cid+'-pathset':meta.lineIds.includes(anchor.slice(1)),fid+anchor);assert(doc.querySelector(anchor));assert.equal(doc.querySelector('#sampling-explorer [data-path][aria-pressed=true]').dataset.path,p.id);assert.equal(doc.querySelector('#sampling-explorer [data-stage][aria-pressed=true]').dataset.stage,stage);
    const formula=doc.querySelector('[data-explorer-formula]').textContent,target=doc.querySelector('[data-explorer-target]').textContent;let a=p.values[0].numerator/p.values[0].denominator,b=p.values[1].numerator/p.values[1].denominator,t=(a+b)/2;if(stage!=='paths')assert(formula.includes(String(t)));if(stage==='grouping')for(let peer of D.cases[cid].paths.filter(z=>(z.values[0].numerator/z.values[0].denominator+z.values[1].numerator/z.values[1].denominator)/2===t))assert(target.includes(peer.id));
    out.explorer.push({frameId:fid,conditionKey:state.conditionKey,path:p.id,stage,formula,target,anchor,imageHash:sha(Buffer.from(im.src.split(',')[1],'base64'))});
   }
  }
 }
 for(let p of ['AA','BB','CC'])assert(doc.querySelector(`#sampling-explorer [data-path=${p}]`).disabled);
 // Loading sequence: old image/formula/target hide; only latest completion commits.
 click('#sampling-explorer [data-path=AB]');assert(doc.querySelector('[data-explorer-image]').hidden);assert(doc.querySelector('[data-explorer-formula]').hidden);click('#sampling-explorer [data-path=AC]');let second=pending.pop(),first=pending.shift();second.onload();first.onload();assert.equal(w.CourseInspect.getState('sampling-explorer').currentFrame,'main-nr-AC-grouping');pending=[];out.loading='Three synchronized outputs hidden while pending; reversed load completion retains latest selection.';
 click('#sampling-explorer [data-path=BC]');let bad=pending.pop();bad.onerror();assert(doc.querySelector('[data-explorer-image]').hidden);assert(doc.querySelector('[data-explorer-status]').textContent.includes('未能显示'));out.loadFailure='Hidden stale image/formula/target; explanatory error shown; paper derivation link remains.';
 click('#sampling-explorer [data-stage=paths]');flush();assert.equal(w.CourseInspect.getState('sampling-explorer').contacts[D.cases['main-nr'].conditionKey].revealedThrough,3);
 out.explorerAncestors=ancestry(doc.querySelector('[data-explorer-image]'));
 // Construction completeness, visible feedback, frozen original choices and direct read.
 click('[data-construct-submit]');assert(doc.querySelector('[data-construct-status]').textContent.includes('还没有完成'));
 for(let p of ['AB','AC','BA','BC','CA','CB'])change(`[name=construct-path][value=${p}]`);
 for(let [p,v] of Object.entries({AB:2,AC:5,BA:2,BC:7,CA:5,CB:7}))change(`[data-map-path=${p}]`,String(v));
 change('[name=construct-reason][value=remaining]');change('[name=construct-distribution][value=thirds]');click('[data-construct-submit]');let cs=w.CourseInspect.getState('construction-four');assert(Object.values(cs.submissions.at(-1).componentChecks).every(Boolean));assert(doc.querySelector('[data-construct-result]').textContent.includes('本次原始选择'));out.constructFeedback=doc.querySelector('[data-construct-result]').textContent;
 click('[data-construct-retry]');click('[data-construct-skip]');await sleep();for(let x of ['a','b','c','d'])assert(doc.getElementById('q3-'+x+'-solution').open);
 // Actual native quiz wrong route, answer-reference disclosure, role-color nodes unchanged.
 const colorBefore=[...doc.querySelectorAll('[mathcolor]')].map(e=>e.getAttribute('mathcolor'));
 change('[name=dt-choice-main-equal][value=five]');click('[data-dt-activity=main-equal] [data-dt-control=submit]');assert(doc.querySelector('[data-dt-activity=main-equal] .dt-feedback-again'));let link=doc.querySelector('[data-dt-activity=main-equal] a[href="#branch-equal"]');assert(link);link.click();out.wrongFeedback=doc.querySelector('[data-dt-activity=main-equal] .dt-feedback-again').textContent;
 click('[data-open-all]');await sleep();assert([...doc.querySelectorAll('details[data-dt-solution]')].every(e=>e.open));out.fullRead={referenceBlocks:doc.querySelectorAll('details[data-dt-solution]').length,allOpenedByButton:true,proofLines:doc.querySelectorAll('[data-line-id]').length,mathNodes:doc.querySelectorAll('math').length};
 const roles={T:'#0F7074'};out.mathColors={};for(let e of doc.querySelectorAll('[mathcolor]'))out.mathColors[e.getAttribute('mathcolor')]=(out.mathColors[e.getAttribute('mathcolor')]||0)+1;
 for(let e of doc.querySelectorAll('mi'))if(e.textContent==='T')assert.equal(e.getAttribute('mathcolor'),'#0F7074');
 for(let e of doc.querySelectorAll('msub'))if(e.firstElementChild?.textContent==='X'&&['1','2'].includes(e.lastElementChild?.textContent))assert.equal(e.getAttribute('mathcolor'),e.lastElementChild.textContent==='1'?'#2364AA':'#7250A4');
 out.nativeMathStyleNote={jsdomFontSize:null,reason:'MathML getComputedStyle unsupported by this jsdom (TypeError); native rendering unverified; selector specificity reviewed statically.'};
 out.idsUnique=new Set([...doc.querySelectorAll('[id]')].map(e=>e.id)).size===doc.querySelectorAll('[id]').length;assert(out.idsUnique);out.jsdomErrors=errors;assert.deepEqual(errors,[]);
 fs.writeFileSync(path.join(O,'course-check-results.json'),JSON.stringify(out,null,2));console.log(JSON.stringify({frames:out.explorer.length,staticImages:out.staticImages.length,activities:out.controls.length,fullRead:out.fullRead,mathColors:out.mathColors,errors},null,2));dom.window.close();
})().catch(e=>{console.error(e.stack);dom.window.close();process.exitCode=1});
