# 本作者本轮来源读取范围

2026-09-08。完整链接及课堂用途在sources.json；此记录区分文献全文、相关页、题名元数据。

- Pearson S2范围：读取根本轮已核实的s2-scope.md全文。该文件明确2019 Issue3规范印刷p59、S1先备p55、S3边界p61，以及官方答案页Chapter6标题。本作者不把这项输入写成自己逐页读完规范。
- Pearson WST02_01_que_20201015.pdf：实际web open/read卷首与第6题（PDFp21附近，正文lines833–845）；题型要求解释sampling distribution及构造range分布。本文另写全部新题，不复制该题。文件名与内页考试日期不同，因此未断言考试场次日期。
- Pearson2013 SAM：实际官方PDF搜索结果提供统计量定义评分短语“calculation based only on known data from a sample”；用于核对only。没有声称读取整套样题。正文英语定义是现代S2的表述，不作为该PDF逐字引文。
- Pearson2014 examiner report：实际打开并读取Question2相关段（lines39–48附近）：仅给unit/frame通用定义而未对应餐厅顾客情境不完整。正文以博物馆画作与剧院交易原创情境响应这个检查点。
- Neyman1934：实际打开69页原论文扫描并截看题名/开头两页；题名、年代和部分调查近似整体的开头问题是采用范围。未读全篇，未转写争论细节。
- Fisher1922：实际检索作者档案与Rothamsted元数据；Adelaide条目已打开但正文无可提取内容，另一原扫描超时。因此只采用作者/题名/年代，没有以未读取正文支持细节主张。
- DeepTutor：实际读取固定commit的QuizBlock.tsx与FlashCardsBlock.tsx；选择提交/反馈、翻面/导航是借鉴入口。分支、完整构造、精确数据信息、Manim静帧、条件接触并集、冻结记录均为本项目原创适配。未重跑上游服务，未把旧组件DOM报告当成本课运行验证。
- Manim：实际读取skill、quickstart、building_blocks、basic.py、using_text与相关配置/API段；唯一helper另记录它实际调用的Scene/Camera/MathTypst/Text构造。当前课程自己的55帧由实际CE0.21.0渲染，pixel证据见manifest。

历史书籍与官方考试只承担上述可核验用途；数学的每个数值由本课原始有理数共同源生成。源码公开、数学正确性与学习掌握证据是三个不同层次。
