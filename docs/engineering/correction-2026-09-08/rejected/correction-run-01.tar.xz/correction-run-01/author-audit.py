"""Audit original authored prose and mathematical structure without loading media."""
from pathlib import Path
import json,re,hashlib
from html.parser import HTMLParser
R=Path(__file__).parent
ns={'__file__':str(R/'author.py')};exec((R/'author.py').read_text().split('# Synchronized explorer formula data')[0],ns)
class Text(HTMLParser):
 def __init__(self):super().__init__();self.out=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['style','script']:self.skip+=1
  if t in ['p','h1','h2','h3','h4','h5','tr','li','summary']:self.out.append('\n')
 def handle_endtag(self,t):
  if t in ['style','script']:self.skip-=1
 def handle_data(self,s):
  if not self.skip:self.out.append(s)
def text(s):p=Text();p.feed(s);return ''.join(p.out)
parts=[text(s['bodyHtml']) for s in ns['sections']]
for a in ns['activities']:
 parts.extend([a['title'],a.get('prompt',''),a.get('explanation','')]);parts.extend(x['text']+' '+x.get('feedback','') for x in a.get('choices',[]));parts.extend(' '.join(c.values()) for c in a.get('cards',[]));parts.append(text(a.get('bodyHtml','')))
plain='\n'.join(parts);(R/'lesson-readable.txt').write_text(plain)
patterns={
 '1_unnamed_view':'有人认为|有观点认为|批评者认为|支持者认为|一般认为|普遍认为|学界认为|不少人|某些.{0,4}|通常被用来|常被解读为|一直被视为|传统上认为|被认为是',
 '2_vague_source':'据报道|据悉|有分析认为|业内人士|相关研究表明',
 '3_both_sides':'双方各有道理|见仁见智|另一方面也应看到|取决于你的立场',
 '4_patronizing':'看得出|大家都知道|不言而喻|稍有常识',
 '5_negation':'不是|并非|不仅仅是|与其说|表面上是|真正的问题不在',
 '6_canned':'不可否认|值得注意的是|需要指出的是|有趣的是|可以说|某种程度上|在一定意义上|或许可以说|总的来说|在某种意义上|深刻|深远|重要意义|值得深思|引人深思|发人深省|说到底|总而言之|综上所述|——|！',
 '7_writer':'笔者|本文认为|我们都知道|我们不要不承认',
 '8_unbounded':'很可能|大概率|不确下结论上升|近年来|最近',
 '8b_translation':'们|被|一个|一种|一项|进行|作出|予以|加以|关于|对于|就.{0,6}而言|当.{0,12}的时候|之一|作为|使得|导致',
 'respect_1_dash':'——',
 'respect_2_contrast':'不是.{0,30}而是|不仅仅是|与其说|表面上是|真正的问题不在',
 'respect_3_double_negative':'没有.{0,20}也没有|不得不|不能不',
 'respect_4_law':'一律|必须|务必|切记|禁止|不许|不得|审判|定性|红线|硬约束|硬伤|台账|备案|整改|问责|验收|攻坚|症结|一刀切|打脸|碾压|驯服|毒瘤',
 'respect_5_judgement':'这证明|显然|众所周知|事实上|本质上|归根结底|你可能以为|其实不然'}
results={k:{'count':len(list(re.finditer(v,plain))),'matches':[{'match':m[0],'context':plain[max(0,m.start()-30):m.end()+60]} for m in re.finditer(v,plain)]} for k,v in patterns.items()}
(R/'style-search-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
proofs=ns['proofs'];ids={x['lineId'] for x in proofs};assert len(ids)==len(proofs);assert all(x.get('reason') for x in proofs)
for c in ns['C'].values():
 for row in c['paths']:
  for lid in row['lineIds']:assert lid in ids,lid
 for g in c['distribution']:assert g['lineId'] in ids
# Upper and lower coverage: inspect authored structure, not a generic row-count claim.
for sid in ['object-population','object-statistic','object-distribution']:
 b=next(s['bodyHtml'] for s in ns['sections'] if s['id']==sid);assert re.findall(r'data-act="([^"]+)"',b)==list('①②③④⑤⑥⑦')
for sid,n in [('practice-q1',3),('practice-q2',3),('practice-q3',4),('practice-q4',2)]:
 b=next(s['bodyHtml'] for s in ns['sections'] if s['id']==sid)
 for k in range(1,7):assert b.count(f'data-duty="{k}"')==n,(sid,k)
report={'scope':'Author self-audit, not independent expert review','sections':len(ns['sections']),'activities':len(ns['activities']),'proofRows':len(proofs),'meanPaths':sum(len(c['paths']) for c in ns['C'].values() if c['statistic']=='mean'),'allPaths':sum(len(c['paths']) for c in ns['C'].values()),'questionBlocks':len(ns['questions']),'upperSevenActs':3,'lowerSixDutySubquestions':12,'errorBranches':3,'textCharacters':len(plain),'searchCounts':{k:v['count'] for k,v in results.items()},'sourceSha256':hashlib.sha256((R/'author.py').read_bytes()).hexdigest()}
(R/'author-audit-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
