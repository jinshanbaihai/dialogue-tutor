#set page(width: auto, height: auto, margin: 0pt, fill: none)
#set text(size: 10pt)

$ frac(1,3) times frac(1,3) = frac(1,9) $
