#set page(width: auto, height: auto, margin: 0pt, fill: none)
#set text(size: 10pt)

$ frac(2,3) $
