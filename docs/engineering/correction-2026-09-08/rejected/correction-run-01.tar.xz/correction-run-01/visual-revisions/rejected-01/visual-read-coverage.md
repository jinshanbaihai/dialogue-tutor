# Visual render read coverage and evidence

## Read coverage

The following files were read in full. Output truncation around the basic.py/building_blocks boundary was repaired with a separate full basic.py read and the building_blocks tail.

- `research/dependencies/cowork-bundles/manim/SKILL.md` — SHA-256 `d86400bf5bda1760430d88b65b7268c52a50bcaf928be21006818b31a096fd7a`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/tutorials/quickstart.rst` — SHA-256 `844baaae5898fc0a6381dd4d8ad9730ee35ffb547fc2f628b60d76579f971931`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/tutorials/building_blocks.rst` — SHA-256 `3615efe105abfdf79e564b94b260f10ebe426e9fa0b421aa46a4bf8b365aac27`
- `research/dependencies/cowork-bundles/manim/repos/manim/example_scenes/basic.py` — SHA-256 `7d249b0e3441f01a4866d1fc3ca56d278f97c92e2e4eaa89ab40591f22f1189f`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/guides/using_text.rst` — SHA-256 `f39f03bc6fc464f8086e313a67c2941c5ebf75cff147037adebc37505460318a`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/guides/configuration.rst` — SHA-256 `5fa13e90b10075c61e8e9e49498826fac7a8d6b7f091ee2317f2283f8e7d5e9c`

- Required graphing API: `research/dependencies/cowork-bundles/manim/repos/manim/api/mobject-graphing.md`, lines 1901–2185, Axes constructor, styling, axis creation, numerical coordinate conversion.
- Frozen `exact-math.json` and `frame-contract.json` were read completely in compact JSON chunks. No frozen source modification.

## Render provenance

- Real ManimCE 0.21.0 `SamplingFrames(Scene)`, invoked by Manim CLI; construct adds Manim objects and captures each scene state using `Camera.capture_mobjects` and `get_image` during Scene.render.
- Final command: `. work/manim-runtime/env.sh` then `python generation/correction-run-01/render_frames.py`.
- Fractions and all rendered mathematical expressions use MathTypst; shapes, axes, bars and crosses are Manim objects.
- PNG files saved from camera pixels with PIL lossless PNG optimize/compress_level=9 only. No raster redrawing, manual SVG substitution, browser, Playwright or video.
- 55 PNGs; 1000×1250 each; total 6,081,252 bytes (base64 about 8,108,336 bytes).
- Ordinary label target heights are 51–55 px, key title/path labels 65 px, MathTypst reference digit 60 px. At a 328 px display width these correspond to 16.7–18.0 px ordinary text, 21.3 px titles/path labels and 19.7 px mathematics. Subscripts/punctuation naturally use their typographic sizes.
- Every frame retains exact conditionKey, lineIds, pathIds and barIds from contract; objects retain role/token/exact values. Each frame records its PNG hash and text bounds.
- Same main-wr/main-nr y-axis range 0 to 1/3, identical plotting geometry; numerical x spacing preserved. The duplicates y-axis is explicitly drawn at the plot left so x=0 cannot run through its label.

## Visual QA scope

- Final direct view_image inspection: main-wr-AB-mapping, main-wr-CC-mapping, main-wr-AB-grouping, main-nr-overview, duplicates-distribution, repair-weight-distribution.
- Earlier direct inspection of unchanged layouts: main-wr-AB-paths, main-nr-distribution, repair-reverse-distribution, example-max-distribution.
- Fixed overlapping large mean fractions, grid footer clipping, repair-weight fractional x-label overlap, faint fraction rules, missing X₁/X₂ labels, incorrect through-zero visual y-axis placement, and colored T/operand roles.
- Final inspected frames show no clipped content. All 55 recorded text bounding boxes pass programmatic in-frame validation. No claim of browser/mobile viewport execution or of manually inspecting all 55 individually.

## Font provenance

- Official font URL: https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf
- Family: Noto Sans CJK SC; font kept at `media/fonts/NotoSansCJKsc-Regular.otf`.
- Font SHA-256: `2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b`.
- License: SIL Open Font License 1.1; official license URL: https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/LICENSE
- Full license saved at `media/fonts/OFL-LICENSE.txt`; SHA-256 `6a73f9541c2de74158c0e7cf6b0a58ef774f5a780bf191f2d7ec9cc53efe2bf2`.

## Final artifact hashes

- `manim_scene.py` — SHA-256 `81eaadb66897016deaca3bd8ac6b42df21a603c64287d101d4af94b29cb85f7e`
- `render_frames.py` — SHA-256 `dd451ff3bb500b03c1fe49269932ecc42cfa17f10e74bd02247cd3032b2281df`
- `exact-math.json` — SHA-256 `9ef3d790e4a6c5a4428bc0d00c4916371655be140e8e6d0e34ce798bf76aeccb`
- `frame-contract.json` — SHA-256 `e9ef6f7adffc1c67fb6934545125bd201d4aecfd5fcd6639b5f4cd9a7621e299`
- `manim-manifest.json` — SHA-256 `342c10424cd4e749061d68a3ba467f41e8da7a1413cf5d28f057b27de5b0693a`
- `render-log.txt` — SHA-256 `c1120e1c2e5378c444c93bc7fbb1960c01eeda35beca3f77a1469b893ce9513c`
