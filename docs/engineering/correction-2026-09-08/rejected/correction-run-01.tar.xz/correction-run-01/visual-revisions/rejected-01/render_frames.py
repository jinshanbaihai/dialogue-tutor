"""Run after `. work/manim-runtime/env.sh`; render and verify frozen 55-frame contract."""
import subprocess, os, json, hashlib, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
cmd=['manim','-s','--renderer=cairo',str(ROOT/'manim_scene.py'),'SamplingFrames']
env=os.environ.copy();env.pop('FRAME_IDS',None);env['RENDER_COMMAND']='. work/manim-runtime/env.sh && '+ ' '.join(cmd)
with (ROOT/'render-log.txt').open('w') as log:
 log.write('COMMAND '+env['RENDER_COMMAND']+'\n');log.flush()
 subprocess.run(['manim','--version'],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
 subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
M=json.loads((ROOT/'manim-manifest.json').read_text());C=json.loads((ROOT/'frame-contract.json').read_text())
assert M['frameCount']==55
assert [f['frameId'] for f in M['frames']]==[f['frameId'] for f in C['frames']]
violations=[]
for frame in M['frames']:
 assert hashlib.sha256(Path(frame['file']).read_bytes()).hexdigest()==frame['sha256']
 for obj in frame['textObjects']:
  x,y,w,h=obj['bounds']
  if x<0 or y<0 or x+w>1000 or y+h>1250:violations.append([frame['frameId'],obj])
if violations:
 print(json.dumps(violations,ensure_ascii=False,indent=2));raise SystemExit('Text exceeds frame')
print('Verified 55 exact IDs, all PNG hashes, 1000×1250 text bounds; PNG bytes:',sum(Path(f['file']).stat().st_size for f in M['frames']))
