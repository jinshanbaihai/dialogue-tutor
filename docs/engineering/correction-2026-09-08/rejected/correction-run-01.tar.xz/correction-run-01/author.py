from pathlib import Path
from fractions import Fraction as F
import json, re, html, hashlib, base64, subprocess, sys
R=Path(__file__).parent
D=json.loads((R/'exact-math.json').read_text()); C=D['cases']; CONTRACT=json.loads((R/'frame-contract.json').read_text())
H=html.escape
activities=[];sections=[];blueprint=[];proofs=[];questions=[]
def val(v):return F(v['numerator'],v['denominator'])
def ex(s):
 if '<' in str(s):return str(s)
 s=str(s);out=[]
 if re.fullmatch(r'[\u4e00-\u9fff]+',s):return '<mtext>'+H(s)+'</mtext>'
 for tok in re.findall(r'[A-Za-z][₁₂]|Xn|x̄|X̄|σ²|max|[A-Za-zΑ-ω]|\d+(?:\.\d+)?|\s+|.',s):
  if tok.isspace():continue
  if re.fullmatch(r'[A-Za-z][₁₂]',tok):out.append(f'<msub mathcolor="{"#2364AA" if tok[1]=="₁" else "#7250A4"}"><mi>{tok[0]}</mi><mn>{1 if tok[1]=="₁" else 2}</mn></msub>')
  elif tok=='Xn':out.append('<msub><mi>X</mi><mi>n</mi></msub>')
  elif tok in ['x̄','X̄']:out.append(f'<mover><mi>{tok[0]}</mi><mo>¯</mo></mover>')
  elif tok=='σ²':out.append('<msup><mi>σ</mi><mn>2</mn></msup>')
  elif re.fullmatch(r'\d+(\.\d+)?',tok):out.append(f'<mn>{tok}</mn>')
  elif tok in ['T','t']:out.append(f'<mi mathcolor="#0F7074">{tok}</mi>')
  elif tok.isalpha():out.append(f'<mi>{H(tok)}</mi>')
  else:out.append(f'<mo>{H(tok)}</mo>')
 return ''.join(out)
def frac(a,b):return f'<mfrac><mrow>{ex(a)}</mrow><mrow>{ex(b)}</mrow></mfrac>'
def rat(q):
 q=val(q) if isinstance(q,dict) else F(q)
 return ex(q.numerator) if q.denominator==1 else frac(q.numerator,q.denominator)
def mm(s):return '<math xmlns="http://www.w3.org/1998/Math/MathML" displaystyle="true"><mrow>'+ex(s)+'</mrow></math>'
def eq(a,b):return mm(ex(a)+'<mo>=</mo>'+ex(b))
def p(s):
 parts=re.split(r'(<[^>]+>)',s)
 for i in range(0,len(parts),2):parts[i]=re.sub(r'(?<![\w/])(-?\d+)/(\d+)(?![\d/])',lambda m:mm(frac(m[1],m[2])),parts[i])
 return '<p>'+''.join(parts)+'</p>'
def line(i,a,b,why,kind='transformation'):
 proofs.append({'lineId':i,'lhs':a,'rhs':b,'reason':why,'kind':kind})
 return f'<div class="proof-line" id="{i}" data-line-id="{i}"><div class="equation"><a class="line-anchor" href="#{i}" aria-label="定位推导 {i}">·</a>{eq(a,b)}</div><p class="reason">{why}</p></div>'
def note(i,s,why):
 proofs.append({'lineId':i,'statement':s,'reason':why,'kind':'premise'})
 return f'<div class="proof-line" id="{i}" data-line-id="{i}">{p(s)}<p class="reason">{why}</p></div>'
def table(head,rows):return '<div class="table-scroll"><table><thead><tr>'+''.join('<th>'+x+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+x+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def details(i,body,label='直接阅读完整讲解'):
 return f'<details id="{i}" class="dt-worked-solution" data-dt-solution><summary>{label}</summary>{body}</details>'
def mount(a,at,reason,condition=None,prereqs=None):
 blueprint.append({'activityId':a['id'],'lineId':at,'conditionKey':condition,'objectiveId':a['objectiveId'],'type':a['type'],'source':a['source'],'placementReason':reason,'prerequisites':prereqs or [],'feedback':a.get('explanation','组件具体反馈及就地全解'),'record':'runtime客观选择/闪卡自评/探索按类型区分；构造仅组件核对'})
 activities.append(a);return f'<div data-dt-activity="{a["id"]}"></div>'
def choice(i,obj,title,prompt,choices,answer,explanation,solution=None,hint=None):
 a={'id':i,'objectiveId':obj,'type':'quiz','format':'choice','title':title,'prompt':prompt,'source':{'repository':'HKUDS/DeepTutor','path':'web/app/(workspace)/books/components/blocks/QuizBlock.tsx','commit':'42fab3cf429a1fbf36b257ab8d116a3814964202'},'choices':[{'id':x[0],'text':x[1],'feedback':x[2]} for x in choices],'answer':answer,'explanation':explanation}
 if solution:a['solutionId']=solution
 if hint:a['hint']=hint
 return a
def flash(i,obj,title,cards):return {'id':i,'objectiveId':obj,'type':'flashcards','title':title,'prompt':'先在心里回忆。翻面后按实际回忆出的要点自评；随时可以跳过。','source':{'repository':'HKUDS/DeepTutor','path':'web/app/(workspace)/books/components/blocks/FlashCardsBlock.tsx','commit':'42fab3cf429a1fbf36b257ab8d116a3814964202'},'cards':[{'front':x[0],'back':x[1],'hint':x[2]} for x in cards]}
def section(i,title,body):sections.append({'id':i,'title':title,'bodyHtml':body,'activityIds':re.findall(r'data-dt-activity="([^"]+)"',body)})
def act(n,title,body):return f'<section class="act" data-act="{n}"><h3>{n} · {title}</h3>{body}</section>'
def qblock(qid,en,zh):
 questions.append({'id':qid,'english':en,'chinese':zh})
 return f'<div class="question" id="{qid}-question"><p class="eyebrow">原创题 · 题干：</p><p><strong>英文原题</strong></p><p lang="en">{en}</p><p><strong>中文题面（我译的那一份）</strong></p><p>{zh}</p></div>'
def duties(qid,decode,method,link,formula,derivation,answer):
 return ''.join([f'<div class="duty" data-duty="{k}"><h4>{label}</h4>{content}</div>' for k,label,content in [(1,'① 题干给了这些条件',p(decode)),(2,'② 条件把方法指出来',p(method)),(3,'③ 接回已经建立的对象',p(link)),(4,'④ 这条规则接得上题目',p(formula)),(5,'⑤ 逐步计算，每步都有依据',derivation),(6,'⑥ 答案与原创评价要点',p(answer))]])
def image_frame(fid,caption):return f'<figure><img data-manim-frame="{fid}" src="@@FRAME:{fid}@@" alt="{H(caption)}" loading="lazy" width="1000" height="1250"><figcaption>{caption}</figcaption></figure>'
def units(c):return '；'.join(u['id']+'：'+mm(rat(u['value']))+c['unit'] for u in c['units'])
def mechanism(c):return '每次放回，重新独立且均匀抽取' if c['replacement'] else '不放回，每次从剩余身份中均匀抽取'
def pathset(c):return '{'+', '.join(x['id'] for x in c['paths'])+'}'
def weight(c,prefix=None):
 cid=prefix or c['id'];n=len(c['units']);d=n if c['replacement'] else n-1
 b=p('用 '+mm('I₁')+'、'+mm('I₂')+' 记两次抽到的身份。这里的 '+mm('I₁')+' 读作“I 下标一”；身份 A 与数值 '+mm(rat(c['units'][0]['value']))+' 分别保存。')
 b+=line(cid+'-first','P(I₁=A)',frac(1,n),f'第一抽在 {n} 个身份中均匀选择，每个身份分到总概率的 {n} 等份。')
 b+=line(cid+'-second','P(I₂=B | I₁=A)',frac(1,d),(f'放回后仍有 {n} 个身份；题目另外规定重新独立且均匀抽取，所以给定首抽 A 后，B 的条件概率仍是原来那一份。' if c['replacement'] else f'首抽 A 留在外面，剩余 {d} 个身份，B 在其中；从剩余身份均匀选择。'))
 b+=line(cid+'-rule','P(AB)',ex('P(I₁=A)')+'<mo>×</mo>'+ex('P(I₂=B | I₁=A)'),'AB 表示先 A 后 B 的同一次两抽事件；使用本章已经解释的条件概率乘法法则。')
 b+=line(cid+'-factors','P(AB)',frac(1,n)+'<mo>×</mo>'+frac(1,d),'把两步概率分别代入，不把第二抽的分母沿用成未经检查的数。')
 b+=line(cid+'-fraction','P(AB)',frac('1×1',str(n)+'×'+str(d)),'分数相乘：分子相乘，分母相乘。两个分母都是正整数。')
 b+=line(cid+'-numerator','P(AB)',frac(1,str(n)+'×'+str(d)),'只计算分子的乘法：一乘一仍是一。')
 b+=line(cid+'-weight','P(AB)',frac(1,n*d),'只计算分母的乘法。每条允许路径都有同样的两步选择数，所以每条允许路径采用这个权重。')
 if not c['replacement']:
  b+=line(cid+'-diagonal','P(I₂=A | I₁=A)','0','同一身份 A 已取走，剩余集合里没有 A。这里排除同一身份，两个不同单位仍然可能有相同数值。')
 return b

def mapping(c,prefix=None):
 out='';base=prefix or c['id'];sym='T'
 for row in c['paths']:
  a,b=[val(x) for x in row['values']];pid=row['id'];i=f'{base}-{pid}'
  out+=f'<div class="path-proof" data-path="{pid}"><h5>路径 {pid}：先 {pid[0]}，后 {pid[1]}</h5>'
  out+=p('抽到的两个观测分别为 '+mm(rat(a))+'、'+mm(rat(b))+c['unit']+'；身份顺序保留。')
  if c['statistic']=='mean':
   out+=line(i+'-sub',sym,frac(rat(a)+'<mo>+</mo>'+rat(b),2),'把这条路径的第一次、第二次观测代入“观测总和除以观测次数”。这里只代入，暂不相加。')
   out+=line(i+'-add',sym,frac(rat(row['sum']),2),'只把分子中的两个观测相加；分母仍为两次观测。')
   out+=line(i+'-div',sym,rat(row['statisticValue']),'把总和除以非零的样本量 2。所得均值的单位仍是'+c['unit']+'。')
  else:
   out+=line(i+'-sub',sym,ex('max(')+rat(a)+'<mo>,</mo>'+rat(b)+'<mo>)</mo>','max 读作 maximum，表示从括号内选取较大的值；相等时保留共同值。')
   out+=line(i+'-add',sym,rat(row['statisticValue']),'比较这两个已知观测，选取较大的值；相等时两者给出同一个结果。')
   out+=note(i+'-div','这一条路径给 '+mm('T')+' 的值是 '+mm(rat(row['statisticValue']))+c['unit']+'。','最大值从观测中选出，保留观测单位；这里不计算平均。')
  out+='</div>'
 return out

def grouping(c,prefix=None):
 out='';base=prefix or c['id'];den=val(c['paths'][0]['probability']).denominator
 for idx,g in enumerate(c['distribution']):
  t=rat(g['value']);lhs=ex('P(T=')+t+'<mo>)</mo>';ids=g['pathIds'];bid=f'{base}-group-{idx}'
  out+=note(bid+'-paths','使 '+mm(ex('T=')+t)+' 的完整路径集合：'+H('{'+', '.join(ids)+'}')+'。','逐条检查本题的映射结果；同一路径进入且只进入一个取值组，身份不同的反向路径分别保留。')
  out+=line(bid+'-events',lhs,'<mo>+</mo>'.join(ex('P('+x+')') for x in ids),'这些身份路径在同一次抽样中互斥，联合事件的概率等于各条路径概率相加。')
  out+=line(bid+'-sub',lhs,'<mo>+</mo>'.join(frac(1,den) for x in ids),'把每条路径经过条件乘法得到的概率分别代入，仍保留每一项。')
  if len(ids)>1:
   out+=line(bid+'-common',lhs,frac('+'.join('1' for x in ids),den),'所有分母相同，合成一个分数时只把分子相加，分母保留。')
   out+=line(bid+'-count',lhs,frac(len(ids),den),'计算分子中一的个数，得到本组允许身份路径的条数。')
  out+=line(bid,lhs,rat(g['probability']),'分子分母约去共同正因子；若已最简则保留原值。这里汇总的是路径质量，均值取值本身没有被预设为等可能。')
 out+=table(['统计量 '+mm('t')+'（'+c['unit']+'）','全部原像路径','概率 '+mm('P(T=t)')],[[mm(rat(g['value'])),', '.join(g['pathIds']),mm(rat(g['probability']))] for g in c['distribution']])
 out+=p('除此表列出的统计量取值外，概率为 0。每条允许路径已经出现一次，所以表的范围完整。')
 ps=[val(g['probability']) for g in c['distribution']]
 out+=line(base+'-total-sub','总概率','<mo>+</mo>'.join(rat(x) for x in ps),'把所有互斥的统计量取值概率相加，检查是否覆盖整个样本空间。')
 from math import lcm
 den2=lcm(*[x.denominator for x in ps]);nums=[x.numerator*(den2//x.denominator) for x in ps]
 out+=line(base+'-total-common','总概率','<mo>+</mo>'.join(frac(x,den2) for x in nums),'通分到共同正分母 '+str(den2)+'；每个分子和分母同乘对应倍数，分数值不变。')
 out+=line(base+'-total-one','总概率',frac('+'.join(map(str,nums)),den2),'同分母分数相加，只合并分子。')
 out+=line(base+'-total-sum','总概率',frac(sum(nums),den2),'计算分子中的整数和。')
 out+=line(base+'-total','总概率','1','相同的非零整数相除为一。这个检查需要连同“每条路径恰好归组一次”一起成立，单独总和为一不能排除错分组。')
 return out

def event(c,op,t,prefix):
 t=F(t);test={'eq':lambda x:x==t,'ge':lambda x:x>=t,'gt':lambda x:x>t}[op];sgn={'eq':'=','ge':'≥','gt':'>'}[op]
 gs=[g for g in c['distribution'] if test(val(g['value']))];ps=[val(g['probability']) for g in gs];den=val(c['paths'][0]['probability']).denominator
 lhs=ex('P(T'+sgn)+rat(t)+'<mo>)</mo>';ids=[x for g in gs for x in g['pathIds']]
 b=note(prefix+'-support','满足条件的取值：'+', '.join(mm(rat(g['value'])) for g in gs)+'；对应路径 '+', '.join(ids)+'。','按题目的 '+sgn+' 逐个比较支持集中的精确值，边界取值是否包含由符号决定。')
 b+=line(prefix+'-sum',lhs,'<mo>+</mo>'.join(ex('P(T=')+rat(g['value'])+'<mo>)</mo>' for g in gs),'不同统计量取值互斥，因此把满足条件的取值事件相加。')
 b+=line(prefix+'-sub',lhs,'<mo>+</mo>'.join(rat(x) for x in ps),'逐项代入本题已构造的分布。')
 nums=[int(x*den) for x in ps]
 b+=line(prefix+'-common',lhs,'<mo>+</mo>'.join(frac(n,den) for n in nums),'统一写成身份路径的共同分母 '+str(den)+'，为相加保留精确值。')
 b+=line(prefix+'-joined',lhs,frac('+'.join(map(str,nums)),den),'合并同分母分数，分子保留加法。')
 b+=line(prefix+'-num',lhs,frac(sum(nums),den),'只计算分子中的整数加法。')
 b+=line(prefix+'-answer',lhs,rat(sum(ps,F(0))),'约去分子分母的共同正因子，得到精确概率；概率没有物理单位。')
 return b

CSS='''<style>
body{background:#F6F5F2!important;color:#202C39!important;font-family:system-ui,-apple-system,"Noto Sans CJK SC",sans-serif}main{max-width:780px!important;margin:auto!important;padding:24px 24px 72px!important}p,li{font-size:17px;line-height:1.85}h1{font-size:clamp(28px,6vw,42px);line-height:1.3}h2{margin-top:2.5em;font-size:27px;line-height:1.45}h3{font-size:21px;margin:1.9em 0 .7em}h4{font-size:18px;margin-top:1.5em}h5{font-size:17px}a{color:#8C4A25}.act{margin-bottom:2em}.proof-line{padding:12px 10px;border-bottom:1px solid #D4D8DC;scroll-margin-top:20px;background:#fff}.proof-line:target,.proof-line.current-line{border-left:4px solid #8C4A25;background:#EEEDE8}.equation{display:flex;gap:10px;align-items:center;max-width:100%;overflow-x:auto;padding:3px 0}.line-anchor{color:#586674;text-decoration:none}.reason{font-size:15px!important;color:#586674;line-height:1.75!important;margin:5px 0 0}.question{border-left:4px solid #2364AA;padding:14px 18px;background:#fff;margin:1.5em 0}.eyebrow{color:#586674;font-size:14px}.table-scroll{overflow-x:auto}table{width:100%;border-collapse:collapse;font-size:16px}th,td{text-align:left;vertical-align:top;border-bottom:1px solid #D4D8DC;padding:10px}th{background:#EEEDE8}math{font-size:24px;math-style:normal;max-width:100%}figure{margin:24px auto;max-width:520px}figure img{width:100%;height:auto;display:block;border:1px solid #D4D8DC}figcaption{font-size:15px;line-height:1.7;margin-top:8px;color:#586674}.path-proof{margin:20px 0}.dt-worked-solution{margin:18px 0;background:#fff;padding:12px}summary{cursor:pointer;min-height:44px;line-height:1.8;color:#8C4A25;font-weight:600}button,select{font:inherit;font-size:16px;min-height:44px}button{border:1px solid #7B8792;background:#fff;color:#202C39;border-radius:7px;padding:9px 13px;cursor:pointer}button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #195FC4;outline-offset:3px}button[aria-pressed=true]{background:#EEEDE8;border:2px solid #8C4A25}.control-row{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.path-buttons{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}fieldset{min-width:0;margin:16px 0;border:1px solid #7B8792;padding:12px}legend{font-weight:650;font-size:17px}.option{display:flex;gap:9px;align-items:flex-start;margin:8px 0;padding:8px;min-height:44px;line-height:1.7;font-size:16px}.option input{margin-top:8px;accent-color:#8C4A25;min-width:20px;width:20px;height:20px}.feedback{padding:14px;border-left:4px solid #586674;background:#EEEDE8;line-height:1.8}.positive{border-color:#176B4B}.needs-work{border-color:#AE3447}.object-x1{color:#2364AA}.object-x2{color:#7250A4}.object-stat{color:#0F7074}.status{font-size:15px;line-height:1.75;color:#586674}.intro{font-size:19px;line-height:1.85}.short-nav{display:flex;flex-wrap:wrap;gap:12px;margin:22px 0}.duty{margin-bottom:18px}.construction-table{font-size:15px}.construction-table td{padding:6px}.proof-line p:first-child{margin-top:0}.no-js-note{color:#586674} .frame-loader{min-height:40px}.frame-output[hidden]{display:none}.full-read{margin:1em 0}
@media(max-width:600px){main{padding:16px 16px 56px!important}.question{padding:12px}.proof-line{padding:10px 6px}.reason{font-size:15px!important}h2{font-size:25px}table{font-size:15px}figure{max-width:100%}.dt-activity{padding:12px 0!important;border-left:0!important;border-right:0!important}.dt-worked-solution{padding-left:0!important;padding-right:0!important}.dt-card{padding:12px!important}math{font-size:24px}.option{padding:6px 0}fieldset{padding:10px 8px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*:before,*:after{animation:none!important;transition:none!important}}
</style>'''
intro=CSS+p('三张借阅记录标签 A、B、C，分别写着 2、4、6 天。抽出一张，记录天数，再放回；第二次重新独立、均匀抽取。两次的平均天数会是多少？如果重复整个两抽程序，哪些平均数出现得多？')
intro+=p('先把手边的一次计算完成：抽到 A 后抽到 C。A 与 C 是记录的身份，2 与 6 是记录上的观测值。')
intro+=line('opening-sub','T',frac('2+6',2),'两次观测的平均数取总和除以观测次数，这里先把两个天数代进去。')
intro+=line('opening-add','T',frac(8,2),'先相加：2 天加 6 天，合计 8 天；分母的 2 表示两次观测。')
intro+=line('opening-div','T','4','再除以 2，平均天数为 4 天。除数是非零的观测次数。')
intro+=p('这次平均是 4 天，仍留下一个问题：4 天有多少条来路？这章会把一次样本、所有允许样本和统计量的分布接起来。题目均为原创，采用 Edexcel IAL S2 的术语与问法；完整书面推导随时可读，选择与翻卡穿插在关键关系旁。')
intro+='<nav class="short-nav"><a href="#object-population">总体与抽样</a><a href="#object-statistic">统计量</a><a href="#object-distribution">抽样分布</a><a href="#practice-q1">做题篇</a><a href="#closing">回顾与继续</a></nav><button type="button" class="full-read" data-open-all>直接展开全部参考讲解</button>'+p('每个参考块也能单独打开。作答、跳过与直接阅读都能继续；读过同题参考后再作答，会保留借助参考的记录。')
section('start','一次均值算完，概率问题刚刚开始',intro)

# OBJECT 1
b=act('①','先确定问题里的“全部”',p('一间图书馆想知道“本月借书的人等待了多久”。门口现在排着十个人，会员数据库有几千条记录。仅凭这两份名单，仍无法确定要调查谁：本月只来还书的人算不算？同一个人来了三次算几位？这些选择会改变分母，也会改变调查结论指向的人。')+p('把研究问题收紧成：2026 年 8 月，这间图书馆每一笔已完成借阅交易的柜台等待时间。现在，每一笔交易都有明确身份，起止时间也能核对。'))
b+=act('②','抽取一部分，需要交代它怎样代表全部',p('Neyman 在 1934 年讨论“代表性方法”的论文开头，把问题落在用一部分资料近似描述整体上；他分别讨论随机抽样和有目的地挑选。这里借用的问题是：调查结论要指向哪一个整体，抽取过程给了怎样的依据。'+ '<a href="#source-neyman">[历史来源]</a>'))
pop=p('研究所关心的全部单位称为<strong>总体（population）</strong>。单位是什么，由问题决定：研究人的等待体验，可以一人为单位；研究每次柜台服务，可以一笔交易为单位。相同的人多次出现，是否算多个单位，需要在抽取之前说清。')
pop+=table(['对象','含义','这间图书馆的落点'],[['population','研究所关心的全部单位，同时标明研究边界。','2026 年 8 月全部已完成借阅交易。'],['抽样单位（sampling unit）','一次被选中、被调查的单位。','一笔有独立交易编号的借阅交易。'],['抽样框（sampling frame）','实际用来挑选单位的名单或清单。','按交易编号整理的该月已完成借阅交易清单。'],['样本（sample）','从总体中抽取并用于调查的一部分单位；随之记录它们的观测。','抽中的那些交易，以及每笔交易的等待时间。'],['样本量（sample size）','抽取的观测次数或单位数，按设计说明。','无重复抽取 40 笔交易时，样本量为 40。']])
pop+=note('population-boundary','同一笔交易可以同时记录等待时间、借书册数和服务时长。','这是一个 sampling unit 的三个变量；按交易抽样时，三项测量不会自动变成三个抽样单位。')
pop+=note('population-duplicates','两笔交易恰好都等待 4 分钟，仍是两个单位、两个观测。','数值相等只描述测量结果相同；交易编号不同，抽取身份仍然不同。')
pop+=p('sampling frame 与 population 有两种职责：population 说明想研究谁，frame 说明实际从哪里抽。漏掉夜间交易的清单会让夜间交易没有入样机会；重复列出某笔交易会增加它被抽中的机会；过期条目可能选中已经不属于研究范围的单位。对 frame 随机抽取，可以把抽法说清，却不能把漏掉的单位补回来。')
pop+=p('对 population 中每个单位收集资料，称为<strong>普查（census）</strong>。只调查一个 sample，称为<strong>样本调查（sample survey）</strong>。census 在完整实施时不受“只抽到这一部分”的抽样波动影响，但仍可能有漏报、不回应和测量错误。sample survey 往往节省时间和费用，结论则需要考虑所抽样本的变化与覆盖。')
pop+=table(['条件','census 能解决什么','sample survey 能解决什么'],[['只有十二台在库设备，读数几秒即可取得','覆盖全部设备可行，可直接得到这十二台的资料。','更快一些，但可能漏掉少数异常设备。'],['一万只灯泡，需要测到烧坏才知道寿命','每只都测会用尽整批灯泡，无法再出售。','只破坏抽中的部分，保留其余产品；抽样设计与样本变化仍需检查。'],['名单漏掉周末来访者','即使调查名单全部条目，目标总体仍未被完整覆盖。','从同一漏框扩大样本，也不能恢复周末来访者的入样机会。']])
pop+=note('population-choice','先写出研究边界，再选择 sampling unit，再检查 frame，最后决定调查全部还是一部分。','先后顺序来自依赖：没有确定“全部是谁”，就无从检查名单是否完整；没有确定单位，也无法计算样本量。')
pop+=mount(flash('population-recall','population','心中重建三个对象',[('population、sampling unit、sampling frame 各回答什么问题？','population：研究关心的全部单位及边界。sampling unit：一次被抽取的单位。sampling frame：实际据以抽取的名单或清单。三者都要落到题目情境。','想一想：想研究谁、一次选谁、从哪份清单选择。')]),'population-choice','定义已经完整建立，心答用于提取区别',prereqs=['population-boundary','population-choice'])
b+=act('③','调查对象、名单和观测分开保存',pop)
en='A museum studies the condition of every painting in its east gallery on 1 September 2026. Its catalogue includes one entry for each painting, but still contains an entry for a painting moved to another building. (a) State the population and a sampling unit. (2) (b) Explain one problem with using this catalogue as the sampling frame. (2) (c) The gallery contains only 12 paintings and checking a painting takes one minute without damage. Give one reason for using a census and one limitation. (2)'
zh='博物馆研究 2026 年 9 月 1 日东展厅每幅画作的状况。目录原本每幅画一条，但仍保留一幅已移到另一座楼的画作。(a) 写出总体与一个抽样单位。(2) (b) 解释用这份目录作抽样框的一项问题。(2) (c) 东展厅只有 12 幅画，每幅检查需一分钟且不损坏画作。给出采用普查的一项理由及一项局限。(2)'
e=qblock('ex-pop',en,zh)
for sid,zen,czen,choices_,answer_,dec,met,form,der,ans in [
 ('a','(a) State the population and a sampling unit. (2)','(a) 写出总体与一个抽样单位。(2)',[('paintings','当天东展厅全部画作；其中一幅画作。','边界和抽取单位都落在画作。'),('catalogue','整份目录；一页目录。','目录提供名单；研究对象由画作条件确定。')],'paintings','every painting 与日期、地点一起界定总体；a sampling unit 要求一个可被抽取的单位。','State 要求写出情境中的对象；计算概率无法代替研究边界。','采用总体和抽样单位的定义，逐个检查地点、日期、对象。',note('ex-pop-a-pop','总体：2026 年 9 月 1 日东展厅全部画作。','题面 each painting 所在的研究范围同时受日期和东展厅限制。')+note('ex-pop-a-unit','抽样单位：当天东展厅中的一幅画作。','一次选择一幅画作并检查其状况；目录页数并不决定调查单位。'),'总体边界一项、单幅画作一项，各对应 1 个原创评价点。'),
 ('b','(b) Explain one problem with using this catalogue as the sampling frame. (2)','(b) 解释用这份目录作抽样框的一项问题。(2)',[('stale','目录存在已移走画作，抽取会选到总体以外的单位。','具体条目与总体边界不一致。'),('random','只要随机抽目录就没有问题。','随机化不能把过期条目变成研究总体成员。')],'stale','still contains 明确说过期条目仍在清单；moved to another building 把该画作排除在东展厅总体之外。','Explain 要求把名单缺陷和抽取后果连接起来；只给 frame 的通用定义仍未解释本题。','逐条比较 frame 条目和 population 成员，无需套数值公式。',note('ex-pop-b-entry','目录仍可能抽中已移走的画作。','该条目仍占据一个可被抽中的位置。')+note('ex-pop-b-outside','这幅画不属于当天东展厅的总体。','总体的地点边界是东展厅，另一座楼不在其中。')+note('ex-pop-b-result','抽中的单位可能无法提供目标总体的那份状况资料。','抽取资格与研究资格不一致；应更新目录后再抽取。'),'指出过期条目、解释抽中总体之外画作的后果，分别是原创评价点。'),
 ('c','(c) The gallery contains only 12 paintings and checking a painting takes one minute without damage. Give one reason for using a census and one limitation. (2)','(c) 东展厅只有 12 幅画，每幅检查需一分钟且不损坏画作。给出采用普查的一项理由及一项局限。(2)',[('scope','规模小且无损，检查全部可行；记录或测量仍会出错。','理由由规模与检测条件支持，局限落在非抽样误差。'),('perfect','普查能保证每条记录都正确。','覆盖全部不保证每次测量或抄录正确。')],'scope','only 12、one minute、without damage 共同支持普查可行；one limitation 要求保留真实局限。','这里比较调查方案，不需要计算抽样分布；是否可行由题面成本与破坏程度判断。','普查检查每幅画，所需检查时间按每幅时间乘幅数；准确性另检查测量与记录。',line('ex-pop-c-time','检查时间','12×1','12 幅，每幅检查一分钟，将单位工作量相加等价于乘法。')+line('ex-pop-c-min','检查时间','12','计算 12 乘 1，得到 12 分钟；未把组织和移动时间算进题目未给的量。')+note('ex-pop-c-limit','普查仍可能把一幅画的裂纹记错。','覆盖全部消除了这项“抽哪几幅”的变化，不能自动纠正测量和记录。'),'可行理由和具体局限各 1 个原创评价点；12 分钟只描述题目给出的检查用时。')]:
 qid='ex-pop-'+sid;sol=qid+'-solution';e+=qblock(qid,zen,czen)
 a=choice(qid+'-answer','population','例题 '+sid+' · 选择情境依据','按这道博物馆题的条件，选择成立的一项。',choices_,answer_,'完整依据在紧接的参考讲解中。',sol)
 e+=mount(a,'population-choice','例题每个小问保留作答与六项解释')+details(sol,duties(qid,dec,met,'回接本对象第③幕“调查对象、名单和观测分开保存”。',form,der,ans))
b+=act('④','在另一份名单里使用定义',e)
b+=act('⑤','同一资料可以先查看单位，也可以先查看变量',p('先查看单位，能检查谁有机会被抽中；先查看变量，能检查每个单位记录了什么。两种检查合起来，才能把“抽中十二幅画”和“取得十二次有效状况测量”分清。'))
b+=act('⑥','全查仍需要检查资料质量',p('完整 frame、完整回应和准确测量是三件不同的事。census 的优势随总体大小、检查成本和破坏程度改变。Pearson 的 2014 年 S2 主考报告特别指出，仅复述 sampling frame 与 sampling unit 的定义，缺少题目中的顾客情境，答题仍不完整。这个提醒在本例中对应“东展厅画作”这几个具体词。<a href="#source-examiner">[来源]</a>'))
b+=act('⑦','把对象接到做题篇',p('这组对象用于 Q1(a)、Q1(b)、Q1(c)。'))
section('object-population','上半 · 对象一：样本从一个有边界的总体中取得',b)

# OBJECT 2
b=act('①','相同样本能不能给出确定结果',p('拿到两个温度观测 2℃、8℃，平均温度可以算出来；如果还要求“平均温度减去未知的真实平均温度”，计算会停在未知数上。两个规则都提到样本，能否单靠手上的样本算出结果，界限发生在这里。'))
b+=act('②','样本的摘要与总体的描述量分开',p('Fisher 的 1922 年论文《On the mathematical foundations of theoretical statistics》把理论统计的基础作为专门问题讨论。本文采用现代 S2 的定义来区分参数与统计量；这份论文的年代和题名已核实，术语的“首次发明”不在这里作断言。<a href="#source-fisher">[来源]</a>'))
s=p('从全部总体值确定的描述量称为<strong>总体参数（population parameter）</strong>。例如全体对象的平均等待时间。总体固定时这个量固定；调查者是否知道它，是资料问题。样本观测会随抽取结果改变，用这些观测计算的规则也可能产生不同结果。')
s+=p('先把平均数建立起来。两次观测分别记为 '+mm('X₁')+'、'+mm('X₂')+'；下标只标抽取次序。把总量平均分成两份，每份的大小就是 mean。抽样前用大写表示可能取不同数值的<strong>随机变量（random variable）</strong>；抽样后的一次具体数值可以用小写。')
s+=line('mean-total','S','X₁+X₂','定义 S 为两个观测的总和；两项需要采用同一测量单位。','definition')
s+=line('mean-sharing','2T','S','平均分成两份，每份 T，相加得到 2T；总量仍为 S。')
s+=line('mean-both-divide',frac('2T',2),frac('S',2),'等式两边同除以非零的份数2；先保留两边的除法。')
s+=line('mean-divide','T',frac('S',2),'左边分子与分母的共同非零因子2约去，剩下T；右边保持原分数。')
s+=line('mean-rule','T',frac('X₁+X₂',2),'用定义 S 的两项观测之和替换 S。现在这条规则只依赖样本和已知常量 2。')
s+=p('这条两观测 mean 可以写作 '+mm('X̄')+'，读作“X bar”。一般样本量 '+mm('n')+' 是正整数；'+mm('Σ')+' 读作“sigma，求和”，表示把下标指定的观测逐项相加。')
s+=line('mean-general-sum','S','X₁+X₂+⋯+Xn','一般样本共有 n 项；这里 Xn 表示第 n 项。定义 S 为所有观测之和。','definition')
s+=line('mean-general-sharing','nX̄','S','把总量平均分为 n 份，每份样本均值 X bar；n 份相加恢复总和。')
s+=line('mean-general-both',frac('nX̄','n'),frac('S','n'),'两边同除以正整数n；先保留两边的除法。')
s+=line('mean-general-divide','X̄',frac('S','n'),'左边分子分母共同因子n非零，约去后留下样本均值；右边仍为S除以n。')
s+=line('mean-general-rule','X̄',frac('X₁+X₂+⋯+Xn','n'),'把总和 S 换回样本观测。平均数保留观测单位。')
s+=p('一种规则一旦由样本观测和已知常量完全确定，就称为<strong>统计量（statistic）</strong>。可以概括为：<span lang="en">A statistic is a quantity calculated only from the observations in a sample.</span> 这里按考试定义中强调的 only 条件表述。only 把计算来源收紧：规则中不含未知总体参数。')
s+=table(['定义中的部分','落到手上的含义'],[['a quantity','计算得到的量，例如 mean、maximum 或第一次观测；计算规则与这次结果分开。'],['calculated','先给一个已确定的规则；同一组样本输入应给出确定的结果。'],['only','除了样本与已知常量，不再索取未知的总体量。'],['observations','本次样本的观测 '+mm('X₁')+'、'+mm('X₂')+' 等；已知样本量也可使用。'],['in a sample','资料来自这次取得的样本，不能偷偷调用尚未观察的总体值。'],['does not involve unknown parameters','这是 only 的具体限制；若 '+mm('μ')+' 是未知总体 mean，减去它就无法只凭样本完成计算。']])
s+=note('statistic-test','检查程序：对规则中的每个输入问一句“样本或题目已给常量能否提供它？”','每个输入都能取得，且规则在所有允许样本上有定义，就能计算；缺少一个未知参数时，结果仍留有无法确定的部分。')
s+=p('字母形状不决定身份。若题面明确给定 '+eq('μ','5')+'，这个数在计算里就是已知常量；'+mm('X̄−μ')+' 可以由样本与 5 计算。若 '+mm('μ')+' 未知，同样形式就含未知参数。统计量的计算规则可以不含未知参数，它的抽样分布仍可能依赖总体参数；这两个层次不要合并。')
s+=p('例如“只取第一次观测”也是 statistic，规则直接给 '+eq('T','X₁')+'；它不需要利用所有观测。固定输出已知常数的规则也可视为退化 statistic。成为 statistic 不要求它善于估计总体参数，也不要求它一定是平均数。若规则含除法，还要检查允许样本会不会令除数为零。')
s+=mount(choice('statistic-known','statistic','把已知与未知分开','题目给 μ=5℃，样本均值已可计算。T=样本均值−μ 是否可由这份样本与已知常量计算？',[('yes','可以，因为 μ 的数值已经给定。','检查的是资料是否可用。'),('no','不可以，因为 μ 是希腊字母。','字母外形没有决定未知与否。')],'yes','给定 μ=5 后，计算只需要样本及常量 5；若 μ 未知才会缺少输入。'),'statistic-test','在定义后检查唯一关键边界',prereqs=['statistic-test'])
b+=act('③','把只用样本的计算规则造出来',s)
en='Two temperature observations from a sample are 2°C and 8°C. The population mean μ is unknown. Let U be the sample mean and let V=U−μ. (a) Calculate U and explain why U is a statistic. (3) (b) Explain why V is not a statistic under the stated conditions. (2)'
zh='某样本的两个温度观测为 2℃、8℃。总体均值 μ 未知。U 为样本均值，V=U−μ。(a) 计算 U，并解释 U 为什么是统计量。(3) (b) 在题目条件下解释 V 为什么不是统计量。(2)'
e=qblock('ex-stat',en,zh)
for sid in ['a','b']:
 qid='ex-stat-'+sid;sol=qid+'-solution'
 if sid=='a':
  e+=qblock(qid,'(a) Calculate U and explain why U is a statistic. (3)','(a) 计算 U，并解释 U 为什么是统计量。(3)')
  a=choice(qid+'-answer','statistic','例题 a · 检查计算来源','哪一组“结果＋理由”完整？',[('sample','U=5℃；只使用两次观测与已知样本量。','数值和来源条件一起满足。'),('population','U=5℃；因为它等于未知总体均值。','样本值不能在这里确定未知总体均值。')],'sample','样本平均为5℃，计算规则只用样本；不需要知道总体均值。',sol)
  der=line('ex-stat-a-sub','U',frac('2+8',2),'把两个温度观测代入两观测平均公式。')+line('ex-stat-a-add','U',frac(10,2),'只计算分子 2 加 8，得到 10。')+line('ex-stat-a-div','U','5','10 除以 2 得 5，单位℃。')+note('ex-stat-a-rule','U 是 statistic。','规则中的两个观测由样本给出，除数 2 是已知样本量，计算不索取未知总体参数。')
  body=duties(qid,'题干给两次温度、样本量 2；unknown 限定总体 μ 的信息状态。Calculate 与 explain 要求数值和理由。','平均两个观测使用样本 mean；用总体 mean 替换结果会额外假定尚未给定的数值。','回接第③幕 mean-rule 与 statistic-test。','公式 U=(X₁+X₂)/2 的分母由两次观测决定；可用总量平分来说明。',der,'U=5℃；结果 1 点、平均方法 1 点、只含样本/已知常量的理由 1 点，均为原创评价要点。')
 else:
  e+=qblock(qid,'The population mean μ is unknown. (b) Explain why V is not a statistic under the stated conditions. (2)','总体均值 μ 未知。(b) 在题目条件下解释 V 为什么不是统计量。(2)')
  a=choice(qid+'-answer','statistic','例题 b · 找到缺失的输入','V=U−μ 在这道题的计算停在哪里？',[('mu','U 能算，未知 μ 的数值不能从本样本取得。','断点是未知总体参数。'),('future','抽样前 U 未知，所以 U 和 V 都不是统计量。','statistic 在抽样前可以是随机变量；规则可计算性才是定义条件。')],'mu','V 含题面明说未知的 μ；样本值相同，μ 若不同，V 会不同。',sol)
  der=line('ex-stat-b-definition','V','U−μ','使用题目给定的计算规则。')+line('ex-stat-b-sub','V','5−μ','只把已经算出的样本值 U=5℃ 代入，μ 仍未知。')+note('ex-stat-b-stop','本题无法仅由样本得到 V 的一个确定数值。','μ 是未知总体参数；同一份 2℃、8℃ 的样本并未提供它。因此 V 不满足 statistic 的 only 条件。')
  body=duties(qid,'unknown 是决定本问的限定词；V 还引用本题 U 的计算结果。','Explain 要求指出额外未知输入；重新平均样本不能消除 μ。','回接第③幕 statistic-test 和 only 的逐词解释。','检查 V 的所有输入：U 来自样本，μ 来自未知总体参数。这里无需选择概率公式。',der,'V 含未知总体参数 μ，因此本题下不属于 statistic；“未知参数”与“无法仅由样本计算”各是 1 个原创评价点。')
 e+=mount(a,'statistic-test','例题区分规则与未知参数')+details(sol,body)
b+=act('④','计算一次，再检查规则的来源',e)
b+=act('⑤','固定规则与随机结果同时成立',p('从函数的角度看，statistic 是固定的计算规则；从抽样的角度看，输入会改变，输出也会改变。把同一规则应用于所有允许样本，就能研究它抽样前的概率，这正是下一个对象要处理的事情。'))
b+=act('⑥','计算规则的定义域也需要完整',p('规则若写成“第二个观测除以第一个”，就需要检查第一项能否为零。一个没有处理零分母的表达式，不能悄悄跳过那些样本再重新分配概率。Pearson 的样题评分以“only”强调样本资料的来源限制；这份课把未知参数条件明确写进每道相关题面。<a href="#source-sam">[来源]</a>'))
b+=act('⑦','把对象接到做题篇',p('这组对象用于 Q2(a)、Q2(b)、Q2(c)，也用于 Q3 与 Q4 的统计量映射。'))
section('object-statistic','上半 · 对象二：统计量的规则只需要样本和已知常量',b)

# OBJECT 3: prerequisites and full common-source construction
b=act('①','五个平均数，凭什么分同样多的概率',p('开头的三张标签可以给出平均数 2、3、4、5、6 天。看见五个不同的数，很容易给每个数分五分之一。可是平均 2 天只能来自两次都抽 A；平均 4 天可以来自 AC、BB、CA。问题落在每个结果接住了多少概率。'))
b+=act('②','把反复抽样的想法写成可穷尽的对象',p('总体只有几个值时，可以把规定抽法下的全部样本逐一写出，再对每个样本使用同一统计量规则。Pearson 的 S2 题目会先要求解释 sampling distribution，再要求构造一个统计量的分布；其 2020 年公开试卷第 6 题使用 range。这说明“分布”针对指定的 statistic，不能只背 mean 的一张表。这里改用完全原创的标签数据，先把全部路径算清。<a href="#source-paper">[题型来源]</a>'))
s=p('<strong>样本空间（sample space）</strong>是规定抽法下所有可能结果的集合。本课保留抽取顺序：AB 表示“先抽 A，再抽 B”，BA 表示“先抽 B，再抽 A”。一次完整两抽只会走其中一条路径。样本量是 2；允许路径的条数是另一个数量。')
s+=note('probability-finite','在一个明确规定为等可能的有限集合中，每个基本结果的概率为 1 除以结果数。','概率总和为1；设m是正整数，表示基本结果的个数，q表示每份相同的概率。仅列出不同结果还没有确认等可能。')
s+=line('finite-equal-total','mq','1','m个基本结果互斥并覆盖全部；各自概率q相加m次，得到mq，总质量为1。')
s+=line('finite-equal-divide',frac('mq','m'),frac(1,'m'),'等式两边同除以正整数m。')
s+=line('finite-equal-share','q',frac(1,'m'),'左边分子分母约去共同非零因子m，得到每份概率。')
s+=p('事件是这些可能结果中的一个集合。'+mm('P(E)')+' 表示事件 E 的概率。两事件<strong>互斥（mutually exclusive）</strong>，表示同一次试验不能同时发生；把互斥事件合在一起，概率相加。两条不同的完整身份路径互斥。若事件有重叠，直接相加会重复计算重叠部分。')
s+=note('conditional-meaning',mm('P(F | E)')+' 读作“已知 E 发生时，F 的条件概率”。','竖线左边是要问的事件，右边是已经限定的条件；把考虑范围收缩到 E 以后再计量 F 的比例。这里要求 P(E) 大于零。')
s+=line('conditional-definition','P(F | E)',frac('P(E∩F)','P(E)'),'条件概率定义：在 E 的概率质量中，E 与 F 共同部分占多少。∩ 表示两件事都发生。','definition')
s+=line('conditional-both-multiply','P(F | E)×P(E)',frac('P(E∩F)','P(E)')+'<mo>×</mo>'+ex('P(E)'),'等式两边同乘正数P(E)，先保留右边的分数与乘数。')
s+=line('conditional-multiply','P(F | E)×P(E)','P(E∩F)','右边的共同非零因子P(E)约去，只留下P(E∩F)。')
s+=line('conditional-sides','P(E∩F)','P(F | E)×P(E)','交换等式左右两边，数值关系不变。')
s+=line('conditional-rule','P(E∩F)','P(E)×P(F | E)','只用实数乘法交换律，把第一步概率写在前面。')
s+=p('<strong>独立（independent）</strong>表示知道 E 发生不改变 F 的概率；当 P(E) 大于零时，就是 '+eq('P(F | E)','P(F)')+'。只有确认这个条件，乘法法则才可写为两个未加条件的概率相乘。放回恢复可抽取对象；题目另外规定第二次重新独立、均匀抽取，才能沿用原来的概率。')
s+=note('mapping-definition','统计量规则 '+mm('T')+' 把每条允许样本路径映到一个数值。','map 表示把输入对应到输出；每个允许输入对应一个确定输出。多个输入可以得到同一个输出，这叫多对一。')
s+=p('某个数值 '+mm('t')+' 的<strong>原像（preimage）</strong>，就是所有使 '+mm('T=t')+' 的路径集合。把这些路径的概率相加，得到 '+mm('P(T=t)')+'。所有可能的 t 和各自的概率合起来，就是这个 statistic 的<strong>抽样分布（sampling distribution）</strong>。')
s+=p('定义句：<span lang="en">The sampling distribution of a statistic gives its possible values and their probabilities over all samples allowed by the stated sampling process.</span> 其中 statistic 指固定的计算规则；possible values 指规则的输出；probabilities 指整个抽样程序赋予的概率；all samples 指全部允许样本；stated sampling process 指样本量、是否放回、抽取权重以及顺序约定都已经固定。')
s+=note('distribution-definition','改变抽法，可能同时改变允许路径、路径权重和输出分布。','比较两个分布前要逐项检查上述条件；仅保留同一组总体数值，不足以保证分布相同。')
s+=p('本课使用的分数运算也放在手边：同分母相加时只加分子；不同分母先通分；相乘时分子相乘、分母相乘；约分时分子分母除以同一个非零数，分数值不变。均值可以是总体没有出现过的数值。概率介于 0 与 1，没有天、厘米等测量单位。')
s+=mount(flash('distribution-recall','distribution','心中把定义接成程序',[('sampling distribution 要同时交代什么？','固定抽样过程和统计量规则；列出所有可能统计量值，并给出每个值的概率。概率来自使该值出现的全部允许样本。','想一想：什么条件固定、什么量在变、给每个值配什么。')]),'distribution-definition','先提取定义的输入输出，再进入具体构造',prereqs=['conditional-rule','mapping-definition'])
# Main WR proof
c=C['main-wr'];s+=p('<strong>固定主条件：</strong>'+units(c)+'。两次抽取；'+mechanism(c)+'；记录顺序；'+mm('T')+' 为两次天数的平均。')
s+=line('main-wr-count-rule','路径数','3×3','第一抽有三个身份；对第一抽的每一个分支，第二抽都有三个身份。乘法计数把每层分支数相乘。')
s+=line('main-wr-count','路径数','9','只计算三乘三。这里九条路径等可能还需要下面的概率论证。')
s+=note('main-wr-pathset','全部允许路径：'+pathset(c)+'。','按首抽 A、B、C 各列一行，每行的第二抽再依 A、B、C 排列；九个格子既不遗漏，也不重复。')
s+=image_frame('main-wr-overview','主条件的 3×3 身份路径矩阵。蓝圆标第一次观测，紫方标第二次观测；每个格子是一条完整两抽路径。')
s+=weight(c)+mapping(c)
s+=p('九条路径的均值现在都有了。接下来先选一组完整来路，再把它们的概率相加。图中的青色菱形一直表示统计量 T。')
# Custom main preimage construction: no typing, own grouped evidence
main_multiset_body='''<div id="preimage-work"><p>让 T=4 天的路径有哪些？可以多选。先把完整的来路选出来，再统一核对。</p><fieldset><legend>选择所有使均值为 4 天的身份路径</legend>'''+''.join(f'<label class="option"><input type="checkbox" name="preimage-path" value="{x["id"]}">{x["id"]}</label>' for x in c['paths'])+'''</fieldset><button type="button" data-preimage-submit>核对这组来路</button><button type="button" data-preimage-retry>重新选择</button><p class="status" data-preimage-status aria-live="polite">尚未提交。</p><div data-preimage-result></div></div>'''
a={'id':'preimage-four','objectiveId':'distribution','type':'interactive','title':'把 4 天的全部来路放在一起','source':{'repository':'DialogueTutor','path':'author/custom-preimage','commit':'original-correction-01'},'bodyHtml':main_multiset_body,'script':'@@PREIMAGE_SCRIPT@@'}
s+=mount(a,'main-wr-CA-div','已知逐条映射后，主动构造一个输出的完整原像',c['conditionKey'],['main-wr-weight','main-wr-CA-div'])
a=choice('main-reverse','distribution','相同输出保留几条输入','在放回主条件下，T=3天的完整身份原像是哪一组？',[('single','只保留AB，BA的均值相同所以删去。','记录顺序时BA仍是另一条允许输入。'),('both','AB与BA都保留，它们对应不同的抽取次序。','输出相同可以归组，两条输入的概率都保留。')],'both','AB和BA是两个不同的完整样本事件，它们都给均值3天。','main-wr-distribution-solution')
a['remediation']={'bodyHtml':p('可以打开 <a href="#branch-reverse">“相同均值删反向路径”分支</a>，分别算两条输入，再回到完整原像这一行。分支末尾有新数据题。')}
s+=mount(a,'main-wr-BA-div','先核对多对一映射的全部输入，再继续概率相加',c['conditionKey'])
a=choice('main-equal','distribution','概率跟着来路走','放回、独立均匀抽取的主条件下，T=3 天的概率是多少？',[('five','五分之一：共有五个不同均值。','不同均值的来路数量并不相同；需要把 AB 和 BA 两条路径的概率相加。'),('two','九分之二：AB 与 BA 各贡献九分之一。','两条路径互斥，每条权重是九分之一。')],'two','T=3 的来路是 AB 与 BA，路径概率相加得到九分之二。','main-wr-distribution-solution','找出使两次总和等于 6 的全部有序身份路径。')
a['remediation']={'bodyHtml':p('先回到 <a href="#branch-equal">“不同均值等可能”分支</a>，那里逐行修复分母的来源，并提供一个新数据问题。')}
s+=mount(a,'main-wr-BA-div','从原像到概率时拦住均值等可能误解',c['conditionKey'])
s+=details('main-wr-distribution-solution',grouping(c)+image_frame('main-wr-distribution','完整抽样分布：柱高是精确概率。中间均值 4 的三条来路对应九分之三，约分后为三分之一。'),'看完整归组、概率相加与总质量检验')
# Explorer mount; controls represented in source statically within activity body
explorer_body='''<div id="sampling-explorer"><p>同一行的图、公式和原像一起切换。先选择抽法，再选择身份路径，最后选择看路径、均值或归组。归组画面会展开当前条件的完整参考，并记录本条件已读参考。</p><fieldset><legend>固定抽样条件</legend><div class="control-row"><button type="button" data-condition="main-wr" aria-pressed="true">放回 · 独立均匀</button><button type="button" data-condition="main-nr" aria-pressed="false">不放回 · 剩余均匀</button></div></fieldset><fieldset><legend>身份路径：先选行身份，再看列身份</legend><div class="path-buttons">'''+''.join(f'<button type="button" data-path="{x["id"]}">{x["id"]}</button>' for x in c['paths'])+'''</div></fieldset><fieldset><legend>看同一条路径的哪一步</legend><div class="control-row"><button type="button" data-stage="paths">① 身份路径</button><button type="button" data-stage="mapping">② 均值计算</button><button type="button" data-stage="grouping">③ 归组与概率</button></div></fieldset><p class="status" data-explorer-status aria-live="polite">先选一条路径。</p><div data-explorer-formula></div><div data-explorer-target></div><figure><img data-explorer-image alt="当前选择的真实 Manim 画面" width="1000" height="1250"><figcaption data-explorer-caption></figcaption></figure><p><a data-explorer-line href="#main-wr-pathset">回到对应书面推导行</a></p></div>'''
a={'id':'sampling-explorer','objectiveId':'distribution','type':'interactive','title':'把同一条路径、均值与柱子连起来','source':{'repository':'DialogueTutor','path':'author/custom-manim-explorer','commit':'original-correction-01'},'bodyHtml':explorer_body,'script':'@@EXPLORER_SCRIPT@@'}
s+=mount(a,'main-wr-pathset','已经完整教过书面映射，图式探索把同一对象的三个表征联动',c['conditionKey'],['conditional-rule','mapping-definition','main-wr-weight'])
b+=act('③','从概率前提，走到完整抽样分布',s)
# Original example with maximum
c=C['example-max'];en='Two labelled repair jobs A and B take 1 hour and 5 hours respectively. Select a job, record its time and replace it. Independently select again, with each job equally likely on each draw. Let M be the maximum of the two recorded times. (a) List all ordered samples and find M for each. (4) (b) Construct the sampling distribution of M. (4)';zh='两个有标签的维修任务 A、B 分别需 1 小时、5 小时。选一个记录用时后放回；再次独立抽取，每次各任务等可能。M 为两次记录用时的最大值。(a) 列出全部有序样本，并求每个样本的 M。(4) (b) 构造 M 的抽样分布。(4)'
e=qblock('ex-max',en,zh)+p('这道例题用字母 M；下方统一的路径图把目标统计量标成 T，这里明确约定 T=M。')
for sid in ['a','b']:
 qid='ex-max-'+sid;sol=qid+'-solution'
 if sid=='a':
  e+=qblock(qid,'(a) List all ordered samples and find M for each. (4)','(a) 列出全部有序样本，并求每个样本的 M。(4)')
  a=choice(qid+'-answer','distribution','最大值例题 a · 保留完整样本','哪一组身份路径完整？',[('four','AA、AB、BA、BB。','放回允许重复同一身份，顺序保留反向路径。'),('three','AA、AB、BB。','BA 是另一条允许的有序路径。')],'four','首抽两个选择，各接两个第二抽选择，共四条。',sol)
  der=line('ex-max-count-sub','路径数','2×2','每一层都有两个身份选择，且放回后第二层不减少。')+line('ex-max-count','路径数','4','计算两个分支数的乘积。')+note('ex-max-pathset',pathset(c),'逐行列首抽 A 或 B，再逐列列第二抽 A 或 B。')+mapping(c)
  body=duties(qid,'maximum 是两次中较大的记录，ordered 保留次序；independently 和 equally likely 明说抽取关系与权重。','需要先列路径再比较两观测；mean 会把题目要求的 statistic 换掉。','回接 mapping-definition：规则固定后，每条样本得到一个结果。','M=max(X₁,X₂)；max 逐项比较，相等时保留共同值。它只用样本，单位小时。',der,'AA→1，AB→5，BA→5，BB→5 小时。允许样本完整、最大值逐条正确是原创评价要点。')
 else:
  e+=qblock(qid,'(b) Construct the sampling distribution of M. (4)','(b) 构造 M 的抽样分布。(4)')
  a=choice(qid+'-answer','distribution','最大值例题 b · 合并相同输出','M=5 小时有多少条来路？',[('three','AB、BA、BB，共三条。','三条路径的最大值都为5。'),('one','只有 BB。','只要一项为5，最大值就是5。')],'three','每条路径四分之一，M=5 概率四分之三。',sol)
  der=weight(c)+grouping(c)+image_frame('example-max-distribution','最大值的完整抽样分布：1 小时一条来路，5 小时三条来路。')
  body=duties(qid,'Construct 要求取值与概率都给全；上一问已经得到每条路径的最大值。','把相同最大值归组并累加路径概率；仅列 1、5 还缺概率。','回接 conditional-rule、mapping-definition 和 distribution-definition。','每条路径概率等于第一抽概率乘给定首抽后的第二抽概率；同组路径互斥所以相加。',der,'P(M=1)=1/4，P(M=5)=3/4，其余值概率0；和为1。路径概率、归组、精确结果与完整性是原创评价要点。')
 e+=mount(a,'mapping-definition','原创例题逐小问选择后可直接读六项解释',c['conditionKey'])+details(sol,body)
b+=act('④','换一个统计量，程序仍能工作',e)
# No replacement contrast, all paths complete
c=C['main-nr'];s=p('现在只改抽法：A、B、C 仍记录 2、4、6 天，两次抽取、记录顺序、求 mean 都保留；第一张不放回，第二张从剩余身份中均匀选取。')
s+=line('main-nr-count-sub','路径数','3×2','第一抽三个身份；首抽取走后，每个第一抽分支只剩两个不同身份。')+line('main-nr-count','路径数','6','计算三乘二。')+note('main-nr-pathset','全部允许路径：'+pathset(c)+'。','3×3 矩阵去掉 AA、BB、CC；其余格子对应不同身份的有序两抽。')+image_frame('main-nr-overview','不放回后，只有同一身份的对角格消失；第二抽的权重也随剩余数量改变。')
s+=weight(c)+mapping(c)
a=choice('main-weight','distribution','抽法改变后重新核对权重','不放回且从剩余身份均匀抽取时，路径 AB 的概率是哪一个？',[('old','九分之一：沿用放回的权重。','第一抽后剩两个身份，条件概率的分母需要重算。'),('new','六分之一：三分之一乘二分之一。','第二抽给定首抽 A 后只剩B、C。')],'new','允许路径共六条，各自为三分之一乘二分之一，即六分之一。','main-nr-distribution-solution')
a['remediation']={'bodyHtml':p('打开 <a href="#branch-weight">“删除对角后仍用旧权重”分支</a>，从条件概率逐行重算；末尾有新数据问题。')}
s+=mount(a,'main-nr-weight','删除路径与重新归一化分开核对',c['conditionKey'])
s+=details('main-nr-distribution-solution',grouping(c)+image_frame('main-nr-distribution','不放回主条件的完整分布：3、4、5 天各有两条来路，各占三分之一。'),'查看不放回的完整归组与分布')
s+=p('把两套表并列时，比较的是同一个 T 在两种抽法下的分布。放回时 T=2 与 T=6 允许；不放回时对应同身份重复已经排除。T=4 的来路也从 AC、BB、CA 改成 AC、CA。概率相同与否应由两套路径权重计算，不能从图形看起来接近就决定。')
b+=act('⑤','从路径看分布，再从分布找原像',s)
b+=act('⑥','哪些前提一变，就需要重建',p('等可能的身份路径不保证等可能的统计量值；不放回时同一单位只取一次；两个不同单位仍可具有相同数值。若抽取权重不均匀，“路径条数除以总条数”通常失效，此时仍可按每条路径的实际概率相加。若把样本写成无序组合，反向路径的概率需要汇总进去，不能只删一个反向记录就保持旧权重。')+p('抽样分布是由总体、规则与抽法决定的理论分布；模拟多次抽样得到的频率会波动。频率图可以帮助观察，有限总体的完整枚举则给出这道题的精确分数。这份课的图直接由同一份有理数数据渲染，柱高不来自随机模拟。'))
b+=act('⑦','把对象接到做题篇',p('这组对象用于 Q3 的完整构造、Q4 的相同数值不同身份，以及三个错误分支的新问题。'))
section('object-distribution','上半 · 对象三：概率随全部允许样本汇入统计量',b)

# LOWER: all original subquestions retain complete stems and six duties
s=p('下半的题面先保留完整英文，再给逐小问中文对照。题后的选择用于确定方法；完整解答始终可打开。标注分数是本课原创评价建议；官方试卷的评分应以各卷评分细则为准。')
en='A theatre studies the waiting time of all ticket transactions completed at its box office during one weekend. Each transaction has a unique number. The available list omits transactions made after 8 p.m. (a) State the population and a sampling unit. (2) (b) Explain why the available list is an incomplete sampling frame and one consequence of using it. (2) (c) There are 1800 transactions. Checking a transaction takes 4 minutes without damage. Give one advantage and one disadvantage of a sample survey compared with a census. (2)';zh='剧院研究某周末售票处所有已完成购票交易的等待时间。每笔交易有唯一编号。现有清单漏掉晚上 8 点后的交易。(a) 写出总体和一个抽样单位。(2) (b) 解释现有清单为何不是完整抽样框，并说明使用它的一项后果。(2) (c) 共有 1800 笔交易；检查每笔需 4 分钟且无破坏。与普查相比，给出样本调查的一项优点及一项缺点。(2)'
s+=qblock('q1',en,zh)
rows=[('a','(a) State the population and a sampling unit. (2)','(a) 写出总体和一个抽样单位。(2)','哪个对象由题面直接界定？',[('transaction','该周末售票处全部已完成购票交易；其中一笔交易。','日期、地点、完成状态和单位均明确。'),('person','所有到过剧院的人；其中一位。','题目研究每笔交易，来访者也可能没购票或购票多次。')],'transaction','all ticket transactions 与 weekend、box office、completed 共同限定总体。','识别调查单位及总体边界；名单中的条目数尚未决定想研究谁。','使用 population 与 sampling unit 的定义：完整范围与单个可抽单位。',note('q1-a-pop','总体是该周末售票处全部已完成购票交易。','范围同时采用时间、地点和已完成交易这三个限制。')+note('q1-a-unit','一个抽样单位是其中一笔有唯一编号的交易。','题面按交易编号抽取；同一个人买票两次可产生两笔不同单位。'),'总体和抽样单位各 1 个原创评价点。'),('b','(b) Explain why the available list is an incomplete sampling frame and one consequence of using it. (2)','(b) 解释现有清单为何不是完整抽样框，并说明使用它的一项后果。(2)','清单漏掉晚间交易会带来哪项直接后果？',[('zero','晚 8 点后的交易没有从这份清单被抽中的机会。','这些总体成员不在抽取清单。'),('fixed','抽得足够多就能把漏掉的交易抽到。','在不含它们的名单上增大样本也无法选到它们。')],'zero','omits 指总体中一部分单位完全缺席，after 8 p.m. 给出具体缺失群体。','比较目标总体与实际清单；需要给出覆盖后果，不能仅写“不随机”。','frame 应提供目标单位的实际抽取入口；未列条目没有被选到的入口。',note('q1-b-missing','晚 8 点后的已完成交易属于目标总体。','总体包含整个周末，题目没有排除晚间交易。')+note('q1-b-noentry','这部分交易没有列在 frame 中。','题目明确说明清单漏掉这一时段。')+line('q1-b-prob','这些交易的入样概率','0','只从清单选取时，没有条目的单位无从被抽中。')+note('q1-b-impact','所得样本不能覆盖这部分交易；如果晚间等待模式不同，整体等待情况的估计可能偏离。','覆盖缺失是确定后果；偏离方向与幅度尚无数据，不能自行给定。'),'具体遗漏和入样后果各 1 个原创评价点。'),('c','(c) There are 1800 transactions. Checking a transaction takes 4 minutes without damage. Give one advantage and one disadvantage of a sample survey compared with a census. (2)','(c) 共有 1800 笔交易；检查每笔需 4 分钟且无破坏。与普查相比，给出样本调查的一项优点及一项缺点。(2)','哪个比较同时有题面依据和真实局限？',[('cost','抽样省检查时间；不同样本带来的抽样变化仍需考虑。','成本来自每笔4分钟，局限来自只选一部分。'),('damage','抽样能避免普查摧毁交易。','题面明确检查无破坏，不能用不存在的条件论证。')],'cost','1800 与每笔 4 分钟说明全查的检查用时；without damage 排除破坏性论点。','sample survey 与 census 比较成本及抽样变化，且分别保留一个优缺点。','全查的检查时间=单位数×每单位检查时间；抽样波动来自没有观察所有单位。',line('q1-c-time-sub','全查检查时间','1800×4','每笔4分钟，1800笔相加等价于1800乘4。')+line('q1-c-time','全查检查时间','7200','计算乘法，得到7200分钟；只含题面给出的检查用时。')+note('q1-c-benefit','检查较小的样本可以减少这项检查用时。','样本包含的交易数小于1800，每笔检查时间保持相同。')+note('q1-c-limit','样本调查有抽样变化，未必准确反映全部交易。','换一组被抽到的交易，样本平均等待时间可能变化；普查完整测量全部交易时没有这项抽样变化。'),'节省检查用时与考虑抽样变化各 1 个原创评价点。清单缺失是另一个问题，抽样或全查旧清单都需先修正。')]
for sid,en1,zh1,prompt,ch,ans,dec,met,form,der,last in rows:
 qid='q1-'+sid;sol=qid+'-solution';s+=qblock(qid,en1,zh1);s+=mount(choice(qid+'-answer','population','Q1('+sid+') · 根据题面判断',prompt,ch,ans,last,sol),'population-choice','下层每小问独立作答与完整六项解释')+details(sol,duties(qid,dec,met,'回接“总体与抽样”第③幕，特别是 population-choice 的依赖次序。',form,der,last))
section('practice-q1','做题篇 · Q1：一份有遗漏的交易清单',s)

s='';en='A sample consists of observations 3 and 9, measured in seconds. The population mean μ is unknown. Define U as the sample mean and V=U+μ. (a) Calculate U and explain whether it is a statistic. (3) (b) Explain whether V is a statistic under these conditions. (2) (c) In a separate situation, μ is given to be exactly 7 seconds. Explain whether U+μ can then be calculated as a statistic. (2)';zh='某样本含两个观测 3 秒、9 秒。总体均值 μ 未知。U 为样本均值，V=U+μ。(a) 计算 U，并解释它是否为统计量。(3) (b) 说明在这些条件下 V 是否为统计量。(2) (c) 在另一个情形中，μ 明确给定为 7 秒。解释此时 U+μ 是否可作为统计量计算。(2)';s+=qblock('q2',en,zh)
for sid in ['a','b','c']:
 qid='q2-'+sid;sol=qid+'-solution'
 if sid=='a':
  en1='(a) Calculate U and explain whether it is a statistic. (3)';zh1='(a) 计算 U，并解释它是否为统计量。(3)';prompt='U 的数值和计算来源是哪一组？';ch=[('six','6 秒；只用样本观测和已知样本量。','计算规则不需要总体均值。'),('unknown','无法计算，因为总体均值未知。','样本均值的规则不使用总体均值。')];ans='six';dec='Calculate 与 explain 同时要求结果与定义依据。';met='先平均两次观测，再检查公式输入；不需要估计未知 μ。';form='两观测 mean=(X₁+X₂)/2，分母是已知且非零的样本量。';der=line('q2-a-sub','U',frac('3+9',2),'只代入两次以秒计的观测。')+line('q2-a-add','U',frac(12,2),'只计算分子3加9。')+line('q2-a-div','U','6','12除以2得6，单位秒。')+note('q2-a-stat','U 是 statistic。','计算只用样本3、9及已知样本量2，不涉及未知总体参数。');last='U=6秒，且是statistic；计算方法、数值、计算来源各为原创评价点。'
 elif sid=='b':
  en1='(b) Explain whether V is a statistic under these conditions. (2)';zh1='(b) 说明在这些条件下 V 是否为统计量。(2)';prompt='未知 μ 出现在 V=U+μ 中，会造成什么？';ch=[('missing','同样的样本还缺 μ 的数值，因此不符合条件。','指出额外未知输入。'),('automatic','U 是统计量，所以加上任何字母后仍是。','新的表达式需重新检查全部输入。')];ans='missing';dec='under these conditions 回指总体 μ 未知；V 的规则含这个参数。';met='逐项追踪输入；已算出的 U 不能提供缺少的总体均值。';form='V=U+μ 是题给规则，将 U 代入后检查剩余项。';der=line('q2-b-rule','V','U+μ','题目定义。')+line('q2-b-sub','V','6+μ','仅把可从样本计算的 U 替换成6秒。')+note('q2-b-missing','V 在本题条件下不是 statistic。','μ 的数值未知；不能仅凭这份样本和已知常量完成6+μ的计算。');last='含未知总体参数，无法仅由样本确定；两点都要明确。'
 else:
  en1='(c) In a separate situation, μ is given to be exactly 7 seconds. Explain whether U+μ can then be calculated as a statistic. (2)';zh1='(c) 在另一个情形中，μ 明确给定为 7 秒。解释此时 U+μ 是否可作为统计量计算。(2)';prompt='条件改成 μ=7 秒后，哪个判断成立？';ch=[('given','可以；已知常量7与样本均值相加。','信息状态改变了计算所需的输入。'),('letter','仍不可以；式子里只要有 μ 就不行。','已知与未知由题面决定。')];ans='given';dec='separate situation 与 exactly 7 明确替换 μ 未知的条件。';met='更新参数的信息状态后再检查计算来源；不能沿用上一问的未知判断。';form='U+μ 的同一规则，此时 μ 可被已知常量7替换。';der=line('q2-c-rule','U+μ','U+7','题面把 μ 明确给成7秒。')+line('q2-c-sub','U+μ','6+7','把这份样本均值 U=6秒代入。')+line('q2-c-add','U+μ','13','相加得13秒。')+note('q2-c-stat','在本小问条件下，该规则只用样本和已知常量，因此可作为 statistic。','关键变化是 μ 已知；不声称上一问的未知条件仍成立。');last='可计算为13秒；已知常量与样本足够，因而符合定义。数值用于说明，评价重点是条件变化及理由。'
 s+=qblock(qid,en1,zh1)+mount(choice(qid+'-answer','statistic','Q2('+sid+') · 逐项检查输入',prompt,ch,ans,last,sol),'statistic-test','用三种信息状态检验定义边界')+details(sol,duties(qid,dec,met,'回接 statistic-test 与 mean-rule。',form,der,last))
section('practice-q2','做题篇 · Q2：参数的已知与未知',s)

# New four-component construction, independently entered before feedback
c=C['construct'];en='Three labelled jobs A, B and C have delays of 0, 4 and 10 minutes respectively. Select two jobs without replacement: the first job is uniformly selected from all three, and the second uniformly from the remaining two. Record the order. Let T be the mean of the two delays. (a) List all allowed ordered identity paths. (2) (b) Find T for every allowed path. (3) (c) Explain the probability of each allowed path. (2) (d) Construct the complete sampling distribution of T and check its total probability. (4)';zh='三个有标签的任务 A、B、C 分别延误 0、4、10 分钟。不放回抽取两个：第一抽在三者中均匀选择，第二抽从剩余两个中均匀选择，并记录顺序。T 为两次延误的均值。(a) 列出全部允许的有序身份路径。(2) (b) 求每条允许路径的 T。(3) (c) 解释每条允许路径的概率。(2) (d) 构造 T 的完整抽样分布并检查总概率。(4)'
s=qblock('q3',en,zh)+p('先完成下面四组选择，再一次提交。提交前不会逐组透露正确与否。你也可以直接打开每小问全解、查看提示或跳过；这些接触会记录到本题条件，稍后核对不会被标作独立证明。答案与数据保存在此单文件中，可检查来源；“独立”只描述页面记录的作答过程，不代表防作弊。')
cb='<div id="construction-work"><fieldset><legend>第 1 组 · 勾选完整允许路径集合</legend><div class="path-buttons">'+''.join(f'<label class="option"><input type="checkbox" name="construct-path" value="{a+b}">{a+b}</label>' for a in 'ABC' for b in 'ABC')+'</div></fieldset><fieldset><legend>第 2 组 · 为每条允许路径选择均值（分钟）</legend><p>即使第一组暂时漏选，仍把六行分别完成；最后才统一核对。</p>'
for path in c['paths']:
 cb+=f'<label class="option">{path["id"]} → <select name="construct-map" data-map-path="{path["id"]}" aria-label="路径 {path["id"]} 的均值"><option value="">请选择均值</option>'+''.join(f'<option value="{n}">{n} 分钟</option>' for n in [0,2,4,5,7,10])+'</select></label>'
cb+='</fieldset><fieldset><legend>第 3 组 · 选择路径概率的依据</legend>'
for value,txt in [('remaining','第一抽三分之一，给定首抽后第二抽二分之一，因此每条允许路径六分之一。'),('old','第一抽和第二抽都用三分之一，因此每条九分之一。'),('means','因为最后有三个均值，所以每条身份路径三分之一。')]:cb+=f'<label class="option"><input type="radio" name="construct-reason" value="{value}">{txt}</label>'
cb+='</fieldset><fieldset><legend>第 4 组 · 选择完整分布</legend>'
for value,txt in [('thirds','T 可取 2、5、7 分钟，各为三分之一；其余值概率0。'),('ninths','T 可取 2、5、7 分钟，各为九分之二；其余值概率0。'),('identity','T 可取 0、4、10 分钟，各为三分之一；其余值概率0。')]:cb+=f'<label class="option"><input type="radio" name="construct-distribution" value="{value}">{txt}</label>'
cb+='</fieldset><div class="control-row"><button type="button" data-construct-submit>提交四组并核对</button><button type="button" data-construct-retry>重新构造</button><button type="button" data-construct-hint>看一条路线提示</button><button type="button" data-construct-skip>跳过并读完整参考</button></div><p data-construct-status class="status" aria-live="polite">尚未提交；需要完成四组。</p><div data-construct-hint-panel hidden><p>按首抽身份分三行；每行只列剩余两种身份。把每一行均值算完，再按相同均值收集路径。概率的第二个分母由“剩余”决定。</p></div><div data-construct-result></div></div>'
a={'id':'construction-four','objectiveId':'construction','type':'interactive','title':'Q3 · 完整构造后一次提交','source':{'repository':'DialogueTutor','path':'author/custom-construction-four','commit':'original-correction-01'},'bodyHtml':cb,'script':'@@CONSTRUCTION_SCRIPT@@'}
s+=mount(a,'q3-question','新数值与不放回条件下重建四个相依部件；统一提交避免逐组反馈污染',c['conditionKey'],['mean-rule','conditional-rule','mapping-definition'])
for sid,en1,zh1,dec,met,form,der,last in [
 ('a','(a) List all allowed ordered identity paths. (2)','(a) 列出全部允许的有序身份路径。(2)','without replacement 排除重复身份；record the order 保留AB与BA。','逐行首抽、逐列第二抽，检查每条是否使用两个不同身份。','每个首抽分支有两个剩余身份，使用3×2计数。',line('q3-a-count-sub','路径数','3×2','首抽三个选择，每个分支再接两个剩余选择。')+line('q3-a-count','路径数','6','计算三乘二。')+note('construct-pathset',pathset(c),'按首抽A、B、C各列两条；恰有六条且每条身份不同。'),'AB、AC、BA、BC、CA、CB；完整性与顺序约定为原创评价点。'),
 ('b','(b) Find T for every allowed path. (3)','(b) 求每条允许路径的 T。(3)','mean 要对每条允许路径使用同一平均规则；0是合法观测，不会使分母为0。','把两次延误代入均值；只算一条或用最大值都不满足every path。','T=(X₁+X₂)/2，分母始终是样本量2；延误可以为0。',mapping(c),'AB、BA→2；AC、CA→5；BC、CB→7，单位分钟。每对反向路径的正确均值是原创评价点。'),
 ('c','(c) Explain the probability of each allowed path. (2)','(c) 解释每条允许路径的概率。(2)','first uniformly from all three、second uniformly from remaining two 分别给出两层条件概率。','按条件概率乘法逐路径计算；无放回的第二抽不独立于首抽身份。','P(AB)=P(首抽A)P(第二抽B|首抽A)。这条法则不要求独立；条件概率已经处理依赖。',weight(c),'每条允许路径概率为1/6；两步概率与相乘理由是原创评价点。'),
 ('d','(d) Construct the complete sampling distribution of T and check its total probability. (4)','(d) 构造 T 的完整抽样分布并检查总概率。(4)','complete 同时要求全部取值、对应概率和其余值概率0；check 要展示总和。','用上一问的路径权重给均值归组；直接对总体0、4、10列概率会混淆观测与统计量。','P(T=t)等于该t全部互斥原像路径的概率之和。',grouping(c)+image_frame('construct-distribution','Q3 新条件的完整分布，与本小问归组行属于同一参考块。'),'2、5、7分钟各1/3，其他取值0，三项总和1；原像、概率、完整性、质量检查各为原创评价点。')]:
 qid='q3-'+sid;s+=qblock(qid,en1,zh1)+details(qid+'-solution',duties(qid,dec,met,'回接上半第③对象的路径、权重、映射与归组；本题重新使用给定的0、4、10和不放回条件。',form,der,last))
section('practice-q3','做题篇 · Q3：在新条件下完整构造',s)

# Duplicate values preserve identity
c=C['duplicates'];en='Three labelled counters A, B and C show recorded visit counts of 0, 0 and 6 respectively. Two counters are drawn without replacement. The first is uniform among the three identities, and the second is uniform among the two remaining identities. The order is recorded. Let T be their sample mean. (a) Construct the sampling distribution of T. (6) (b) Find P(T≥3) and explain why T=0 is possible without replacement. (3)';zh='三枚有标签的筹码 A、B、C 分别标有来访次数 0 次、0 次、6 次。不放回抽取两枚：第一抽在三个身份间均匀，第二抽在剩余两个身份间均匀，并记录顺序。T 为样本均值。(a) 构造 T 的抽样分布。(6) (b) 求 P(T≥3)，并解释为什么不放回时 T=0 仍然可能。(3)'
s=qblock('q4',en,zh)+p('筹码承载的是来访次数这个观测，均值的单位为次；抽样程序仍然只抽两枚筹码。观测值0次不会把样本量改成0。')
for sid in ['a','b']:
 qid='q4-'+sid;sol=qid+'-solution'
 if sid=='a':
  en1='(a) Construct the sampling distribution of T. (6)';zh1='(a) 构造 T 的抽样分布。(6)';prompt='不放回时，AB 是允许路径吗？';ch=[('yes','允许；A 与 B 是不同身份，虽然都显示0。','身份决定是否已经取走。'),('no','不允许；两个观测值都为0。','同值不会把两个不同单位合成一个身份。')];ans='yes';dec='labelled 使A、B保持独立身份；without replacement 表示抽走的筹码不再放回。';met='先列身份路径再映射数值，避免把两个0合并成一个单位。';form='路径权重用3个身份再2个剩余身份；均值仍除以样本量2；归组时相同均值的互斥路径相加。';der=note('duplicates-pathset',pathset(c),'排除AA、BB、CC，保留AB与BA；因为不同身份可以写相同数值。')+weight(c)+mapping(c)+grouping(c)+image_frame('duplicates-distribution','Q4 的0均值来自AB、BA；3均值来自AC、CA、BC、CB。身份权重保留，重复数值按全部原像汇总。');last='P(T=0)=1/3，P(T=3)=2/3，其余值0。完整路径、权重、逐条映射与合并质量构成原创评价要点。'
 else:
  en1='(b) Find P(T≥3) and explain why T=0 is possible without replacement. (3)';zh1='(b) 求 P(T≥3)，并解释为什么不放回时 T=0 仍然可能。(3)';prompt='“T≥3”在这道题保留哪些均值？';ch=[('three','只保留3；0不满足大于或等于3。','支持集只有0、3。'),('none','没有；等于3不算。','≥明确包含边界等号。')];ans='three';dec='≥读作“大于或等于”，包括边界3；explain 要回到身份差别。';met='在已构造的支持集中筛选事件，再解释零均值的具体允许原像。';form='事件由满足不等式的统计量值组成；本题只有T=3符合，所以取该组概率。';der=event(c,'ge',3,'q4-b-event')+note('q4-b-zero','T=0来自AB或BA。','两个0分别属于A、B两枚不同筹码；抽走A后B仍在，抽走B后A仍在。');last='P(T≥3)=2/3；A、B不同身份的两条允许路径给T=0。精确概率、边界筛选与身份解释是原创评价点。'
 s+=qblock(qid,en1,zh1)+mount(choice(qid+'-answer','distribution','Q4('+sid+') · 身份与数值分开',prompt,ch,ans,last,sol),'population-duplicates','在新的重复数值条件下检验身份、事件与分布',c['conditionKey'])+details(sol,duties(qid,dec,met,'回接 population-duplicates、main-nr-diagonal 和 mapping-definition。',form,der,last))
section('practice-q4','做题篇 · Q4：数值相同，身份仍然不同',s)

# Three explicit small-step error branches, with return line and new problem
s=p('如果某个判断卡住，选择对应分支。每条分支先把断开的关系补齐，再回到原行；末尾使用新数值核对迁移。全部分支可直接阅读，无需先答错。')
# Equal means
s+='<section id="branch-equal"><h3>分支一 · 把不同均值直接当作等可能</h3>'+p('误路：主条件有五个不同均值，于是给每个均值五分之一。这里需要补的是“等可能的对象是什么”。')
s+=note('repair1-object','题目等概率抽的是身份，完整两抽基本结果是九条身份路径。','五个均值是这些路径的输出；题面没有另做一次“从五个均值均匀挑选”的试验。')
s+=note('repair1-preimage','T=3的完整原像是AB、BA。','AB给(2+4)/2，BA给(4+2)/2，两条都为3；其余七条的已算均值均不为3。')
s+=line('repair1-sum','P(T=3)','P(AB)+P(BA)','AB与BA是两个互斥的完整样本事件。')+line('repair1-sub','P(T=3)',frac(1,9)+'<mo>+</mo>'+frac(1,9),'每条身份路径经独立均匀两抽得到九分之一。')+line('repair1-one','P(T=3)',frac('1+1',9),'同分母相加，保留分母9。')+line('repair1-count','P(T=3)',frac(2,9),'只计算1加1；这个分数已经最简。')
s+=p('<a href="#main-wr-group-1">回到原证明：T=3 的归组行</a>。下一题更换成 1、5、9 厘米，检查是否能重新找原像。')
# helper new question fully built, no hidden dependent prerequisites

def repair_question(cid,qid,target,word,zhword,choices_,ans,explanation):
 c=C[cid];v=[str(val(u['value'])) for u in c['units']];en=f'Three labelled units A, B and C have measurements {v[0]}, {v[1]} and {v[2]} {word} respectively. Two units are drawn '+('with replacement, with each draw independent and uniform among all three identities' if c['replacement'] else 'without replacement, first uniformly among three identities and then uniformly among the remaining two')+f'. The order is recorded. Let T be their sample mean. Find P(T={target}). Show the allowed paths, path probabilities, mean mapping and the full sampling distribution used. (6)';zh=f'三个有标签的单位 A、B、C 的观测分别为 {v[0]}、{v[1]}、{v[2]} {zhword}。抽取两次，'+mechanism(c)+f'，记录顺序。T 为两次观测的均值。求 P(T={target})，展示所用的允许路径、路径概率、均值映射和完整抽样分布。(6)'
 out=qblock(qid,en,zh);sol=qid+'-solution'
 out+=mount(choice(qid+'-answer','distribution','新题 · 把关系迁移一次',f'按这道新条件，P(T={target}) 是多少？',choices_,ans,explanation,sol),'mapping-definition','错误关系完整补足后，用未作答的新数值重新构造',c['conditionKey'])
 der=note(cid+'-pathset',pathset(c),'按本题抽法逐首抽身份排列所有允许第二抽；先保留身份，再读取数值。')+weight(c)+mapping(c)+grouping(c)+event(c,'eq',target,qid+'-event')+image_frame(cid+'-distribution','本分支新问题的完整抽样分布。精确柱高与同块的归组推导使用同一份有理数数据。')
 out+=details(sol,duties(qid,'题面重新给三项观测及抽法；recorded order 保留有序身份路径；T指定mean。','先在新条件列全路径，再计算每条均值和概率。上一题的数值结果不自动适用。','回接本分支的修复关系以及 main-wr-pathset、conditional-rule、mapping-definition。','均值为两观测和除以2；路径概率按条件乘法；相同均值的互斥路径概率相加。',der,explanation+' 允许路径、权重、完整映射、归组及目标事件是原创评价要点。'))
 return out
s+=repair_question('repair-equal','repair-equal-q',5,'cm','厘米',[('third','三分之一。','AC、BB、CA各贡献九分之一。'),('fifth','五分之一。','五个均值没有相等的原像质量。')],'third','T等于5的概率为三分之一，由AC、BB、CA三条路径各九分之一相加得到。')+'</section>'
s+='<section id="branch-reverse"><h3>分支二 · 平均数相同，就删掉反向路径</h3>'+p('误路：AB与BA平均数相同，于是只保留AB。先看抽样记录，再看统计量输出。')
s+=note('repair2-records','AB记录“先A后B”；BA记录“先B后A”。','记录顺序是题面固定条件，两次完整样本记录不同。')+line('repair2-ab-sub','T(AB)',frac('2+4',2),'代入AB对应的两次天数。')+line('repair2-ab-add','T(AB)',frac(6,2),'只相加分子。')+line('repair2-ab-div','T(AB)','3','再除以2。')+line('repair2-ba-sub','T(BA)',frac('4+2',2),'代入另一条允许路径BA的两次天数。')+line('repair2-ba-add','T(BA)',frac(6,2),'只相加分子；加法交换次序不改变和。')+line('repair2-ba-div','T(BA)','3','再除以2，输出同为3。')+note('repair2-conclusion','两条输入不同，输出相同；归组保留两份路径概率。','多对一映射合并输出标签，并未抹掉其中一个输入事件。')
s+=line('repair2-mass-sub','P(T=3)',frac(1,9)+'<mo>+</mo>'+frac(1,9),'AB与BA互斥，把两条路径的权重相加。')+line('repair2-mass-common','P(T=3)',frac('1+1',9),'同分母相加合并分子。')+line('repair2-mass','P(T=3)',frac(2,9),'计算分子得到2。')
s+=p('<a href="#main-wr-group-1-paths">回到原证明：完整原像集合</a>。下面把观测改为 1、3、7 克。')
s+=repair_question('repair-reverse','repair-reverse-q',4,'grams','克',[('two','九分之二。','AC与CA各给均值4。'),('one','九分之一。','反向路径CA仍然允许，不能删除。')],'two','T等于4的概率为九分之二，由AC、CA两条互斥路径各九分之一相加得到。')+'</section>'
s+='<section id="branch-weight"><h3>分支三 · 删除对角路径，却保留放回权重</h3>'+p('误路：不放回时删除AA、BB、CC，剩六条仍各九分之一。删除路径后，实际第二抽过程也改变了。')
s+=line('repair3-first','P(首抽A)',frac(1,3),'第一抽仍从三个身份均匀选择。')+note('repair3-remaining','首抽A后，剩余身份集合是{B,C}。','A没有放回，因此后续样本空间仅含两个身份。')+line('repair3-second','P(第二抽B | 首抽A)',frac(1,2),'B是剩余两个等可能身份之一。')+line('repair3-rule','P(AB)','P(首抽A)×P(第二抽B | 首抽A)','使用条件概率乘法；不需要假设两个抽次独立。')+line('repair3-sub','P(AB)',frac(1,3)+'<mo>×</mo>'+frac(1,2),'把本次抽法的两层概率代入。')+line('repair3-product','P(AB)',frac('1×1','3×2'),'分数相乘，分子分母分别相乘。')+line('repair3-numerator','P(AB)',frac(1,'3×2'),'先计算分子1乘1。')+line('repair3-answer','P(AB)',frac(1,6),'再计算分母3乘2。')+line('repair3-total-sub','六条总概率',ex('6')+ex('×')+frac(1,6),'六条允许路径各六分之一。')+line('repair3-total-fraction','六条总概率',frac(6,6),'整数6乘分数的分子1，分母保留6。')+line('repair3-total','六条总概率','1','非零数除以自身为1。')
s+=p('<a href="#main-nr-second">回到原证明：第二抽条件概率</a>。下一题继续不放回，改为 2、5、11 分钟。')
s+=repair_question('repair-weight','repair-weight-q',F(13,2),'minutes','分钟',[('third','三分之一。','AC、CA各六分之一。'),('ninth','九分之二。','这是保留旧路径权重的结果，第二抽应使用二分之一。')],'third','T等于十三除以二的概率为三分之一，由AC、CA两条互斥路径各六分之一相加得到。')+'</section>'
section('repair-branches','修复篇 · 三个断点，各自回到一行证明',s)

s=p('现在可以把这章接成一段可复述的过程：确定总体与单位，固定样本量和抽法，列出全部允许样本；对每条样本用同一统计量规则，再把相同输出的路径概率汇总。最后检查每条路径出现恰好一次、各概率非负、总质量为1。')
s+=mount(flash('final-recall','distribution','合上公式，在心里重建',[('给一个有限总体和样本量，构造样本均值的抽样分布要完成哪些步骤？','先固定抽法和身份顺序；列全允许路径；用条件概率求路径权重；每条代入均值；按相同输出收集全部路径并累加概率；列全分布及其余值0，检查无遗漏重计和总概率1。','按“条件→样本→规则→概率”回忆。'),('不放回时，为什么不能只删除对角格却保留旧概率？','第二抽在剩余身份中进行，条件概率分母改变；各条允许路径的概率要随实际过程重算。三身份两抽时，三分之一乘二分之一得到六分之一。','先写出首抽之后剩余哪些身份。'),('读过同题参考后做对，记录能说明什么？','能说明这次借助参考完成核对；不能直接证明已能独立生成完整过程。可以另做新条件构造，并在之后到期时回忆。','把借助参考、客观核对、心答自评分开。')]),'distribution-definition','收束时回忆整套依赖与证据边界')
s+='''<div id="course-report"><p data-report-text class="status" aria-live="polite">启用 JavaScript 后，此处按本页实际记录生成回顾。未运行时不预填成绩。</p><div class="control-row"><button type="button" data-report-refresh>刷新本次记录</button><button type="button" data-report-next>继续未完成或到期项目</button><button type="button" data-report-construction>回到新题完整构造</button><button type="button" data-report-memory>回忆整套程序</button></div></div>'''
s+=p('选择题记录页面客观核对；闪卡记录翻面前的心答自评；图式控件记录探索；Q3记录四组构造选择的组件核对。它们各自提供不同证据，不汇成一个“已掌握全部证明”的百分比。学习面板可导出和导入同课程、同版本记录；本页只在浏览器本地保存。复习间隔使用公开的工程启发式，1、3、7、14、30天；这些固定间隔没有拟合个人遗忘曲线。')
s+=p('建议下一次先不看参考，重新写出一个允许路径集合，在心里完成每条均值的代入、相加和相除，再对照全解。遇到某一步断开，可以直接回到对应行；当前页面不要求通过测验才能继续阅读。')
section('closing','回顾与继续：让下一次也能从条件走到分布',s)

sources=[
 ('spec','Pearson Edexcel International Advanced Level Mathematics specification（S2，sampling and sampling distributions）','https://qualifications.pearson.com/content/dam/pdf/International%20Advanced%20Level/Mathematics/2018/Specification-and-Sample-Assessment/international-a-level-maths-spec.pdf','以批准研究清单核对本章范围：population、sample、census、sampling unit/frame、statistic、sampling distribution。此课不把中心极限定理、置信区间或估计量理论扩写进本章。'),
 ('paper','Pearson WST02公开试卷，第6题，文件WST02_01_que_20201015.pdf','https://qualifications.pearson.com/content/dam/pdf/International%20Advanced%20Level/Mathematics/2018/Exam-materials/WST02_01_que_20201015.pdf','读取该题正文与卷首；用来核对定义问及指定统计量分布构造问的题型。本文题目数据、文字和解答均另行原创；不把文件名日期当作页面内考试日期。'),
 ('sam','Pearson IAL Mathematics sample assessment materials（2013版），统计量定义评分表达','https://qualifications.pearson.com/content/dam/pdf/International%20Advanced%20Level/Mathematics/2013/Specification%20and%20sample%20assessments/IAL%20in%20Mathematics%20SAMS%20WEB%20small%20file.pdf','核对“calculation based only on known data from a sample”之定义重点；正文定义为现代S2表达，强调only与未知总体参数边界。'),
 ('examiner','Pearson S2 examiner report，January 2014，Question 2','https://qualifications.pearson.com/content/dam/pdf/International%20Advanced%20Level/Mathematics/2013/Exam%20materials/WST02_01_pef_20140306.pdf','读取第2题报告：frame与unit需要结合餐厅顾客的具体情境，不能只复述定义。'),
 ('neyman','J. Neyman（1934），On the Two Different Aspects of the Representative Method','https://www.stat.cmu.edu/~brian/905-2008/papers/neyman-1934-jrss.pdf','读取原论文扫描的题名页与开头问题，说明部分调查和整体描述的历史问题；未声称读完69页，也未声称术语最早发明者。'),
 ('fisher','R. A. Fisher（1922），On the mathematical foundations of theoretical statistics','https://digital.library.adelaide.edu.au/items/36b96da4-e256-4e94-9720-eef372935c3a','核对作者文献档案与题名年代；历史段不以未完整读取的正文支持详细主张。'),
 ('deeptutor','HKUDS/DeepTutor，批准版本42fab3cf429a1fbf36b257ab8d116a3814964202','https://github.com/HKUDS/DeepTutor','使用可追溯的选择题与闪卡交互契约；无需输入答案文字或数字。数学内容与自定义构造为本课原创。'),
 ('manim','Manim Community v0.21.0','https://docs.manim.community/en/stable/','图像由实际Manim场景渲染为PNG，具体版本、字体、路径对象、推导行及哈希见复现材料。')]
s=p('以下列出实际采用的范围与用途；正文所有练习均为原创。数学图使用本课 exact-math.json 中的精确有理数。')
for i,title,url,scope in sources:s+=f'<div id="source-{i}"><h3>{H(title)}</h3>{p(scope)}<p><a href="{H(url)}">原始来源</a></p></div>'
section('sources','来源与可复现性',s)

# Synchronized explorer formula data are built from the same exact paths as static proof.
forms={};fmeta={}
for f in CONTRACT['frames']:
 fid=f['frameId'];c=C[f['caseId']];fmeta[fid]=f
 if f['pathId']:
  row=next(p for p in c['paths'] if p['id']==f['pathId']);g=next(g for g in c['distribution'] if f['pathId'] in g['pathIds']);a,bv=row['values'];formula='<div class="proof-line">'+eq('T',frac(rat(a)+'<mo>+</mo>'+rat(bv),2))+p('代入当前路径的两次观测。')+'</div><div class="proof-line">'+eq('T',frac(rat(row['sum']),2))+p('只把分子相加。')+'</div><div class="proof-line">'+eq('T',rat(row['statisticValue']))+p('总和除以样本量2，单位'+c['unit']+'。')+'</div>'
  target=p('当前目标：'+mm(ex('T=')+rat(g['value']))+'；完整原像 '+', '.join(g['pathIds'])+'。')
  if f['stageId']=='grouping':target+=p('此组概率：'+mm(ex('P(T=')+rat(g['value'])+'<mo>)</mo><mo>=</mo>'+rat(g['probability']))+'。对应柱子在图中使用青色突出。')
  forms[fid]={'formula':formula if f['stageId']!='paths' else p('选中的身份路径是 '+f['pathId']+'。第一次身份与第二次身份保留在不同形状中。'),'target':target if f['stageId']=='grouping' else p('下一步把这条允许路径送入同一个统计量规则。'),'lineId':g['lineId'] if f['stageId']=='grouping' else (row['lineIds'][0] if f['stageId']=='mapping' else c['id']+'-pathset'),'caption':f['pathId']+'：'+('身份路径矩阵' if f['stageId']=='paths' else '同一路径的均值代入、相加、相除' if f['stageId']=='mapping' else '所有均值柱子，突出当前原像组')}
 else:forms[fid]={'formula':p('固定条件：'+mechanism(c)+'，样本量2，记录顺序。'),'target':p('从上方选择一条允许路径，逐步检查它进入哪个统计量取值。'),'lineId':c['id']+'-pathset','caption':'完整身份路径与当前抽法；不放回时同一身份对角格不可选。'}
manifest=json.loads((R/'manim-manifest.json').read_text())
assert manifest['dataHash']==hashlib.sha256((R/'exact-math.json').read_bytes()).hexdigest(), 'Manim data hash differs'
assert manifest['frameContractHash']==hashlib.sha256((R/'frame-contract.json').read_bytes()).hexdigest(), 'Manim contract hash differs'
assert manifest['sceneSourceHash']==hashlib.sha256((R/'manim_scene.py').read_bytes()).hexdigest(), 'Manim source changed since rendering'
assert [f['frameId'] for f in manifest['frames']]==[f['frameId'] for f in CONTRACT['frames']], 'Rendered frame collection differs'
for f in manifest['frames']:
 assert hashlib.sha256((R/'media/frames'/(f['frameId']+'.png')).read_bytes()).hexdigest()==f['sha256'], f['frameId']+' PNG hash differs'
frames={f['frameId']:'data:image/png;base64,'+base64.b64encode((R/'media/frames'/ (f['frameId']+'.png')).read_bytes()).decode() for f in CONTRACT['frames']}
data=dict(D);data['dataHash']=hashlib.sha256((R/'exact-math.json').read_bytes()).hexdigest()
script=(R/'course-interactions.js').read_text()
for key,value in [('DATA',data),('FRAMES',frames),('FORMS',forms),('FRAME_META',fmeta)]:script=script.replace('@@'+key+'@@',json.dumps(value,ensure_ascii=False,separators=(',',':')))
for a in activities:
 if a['type']=='interactive':a['prompt']='按当前题面条件选择。完整推导与参考可随时直接阅读。'
 if a['id']=='preimage-four':a['script']=script
 elif a['type']=='interactive':a['script']='/* Shared original components are initialized by the preimage-four module. */'
for sec in sections:
 sec['bodyHtml']=re.sub(r'@@FRAME:([^@]+)@@',lambda m:frames[m[1]],sec['bodyHtml'])
lesson={'schemaVersion':1,'lessonId':'edexcel-ial-s2-sampling-correction-01','revision':'1.0.0','language':'zh-CN','title':'Edexcel IAL S2 Chapter 6 · 从样本走到抽样分布','mode':'bgct','presentation':'document','generationPolicy':'no-typing','theme':'light','objectives':[{'id':'population','title':'按情境区分总体、单位、抽样框与调查方式','kind':'concept'},{'id':'statistic','title':'按已知输入与未知总体参数判断统计量','kind':'concept'},{'id':'distribution','title':'从全部允许样本构造统计量抽样分布','kind':'procedure'},{'id':'construction','title':'在新条件下完整重建路径、映射、权重与分布','kind':'design'}],'sections':sections,'activities':activities}
(R/'lesson.json').write_text(json.dumps(lesson,ensure_ascii=False,indent=2))
(R/'proof-lines.json').write_text(json.dumps(proofs,ensure_ascii=False,indent=2))
(R/'activity-map.json').write_text(json.dumps(blueprint,ensure_ascii=False,indent=2))
(R/'original-questions.json').write_text(json.dumps(questions,ensure_ascii=False,indent=2))
(R/'sources.json').write_text(json.dumps([dict(id=i,title=t,url=u,readScope=s) for i,t,u,s in sources],ensure_ascii=False,indent=2))
(R/'blueprint.md').write_text('# 原创课程蓝图\n\n三个上层对象各七幕：总体与抽样；统计量及参数边界；抽样分布。每组包含问题缺口、来源限制明确的历史视角、全部前提与构造、另一个原创例题、第二种表征、边界、下层题号索引。\n\n下层Q1(a–c)、Q2(a–c)、Q3(a–d)、Q4(a–b)全部有完整英文/中文题面和六项解释。三个修复分支各有原断点、完整小步、精确返回行和新数值完整题。原始活动位置、前提和条件键见activity-map.json；逐行式子与具体理由见proof-lines.json。\n\nQ3先选完整路径、逐条映射、条件概率依据、完整分布；四组统一提交，原始选择和提交前辅助状态冻结。自定义核对仅存exploration.submissions，不写客观attempts。所有局部全解初始关闭但可自由打开。\n\n真实Manim帧与图文共同来源为exact-math.json；通过frame-contract.json映射lineIds/pathIds/barIds/objectRoles。图形、公式与目标组同步提交，回退当前画面不清除revealedThrough或参考覆盖。\n')
print('Authored',len(sections),'sections,',len(activities),'activities,',len(proofs),'proof lines,',len(questions),'question blocks.')
builder=Path(sys.argv[sys.argv.index('--builder')+1]) if '--builder' in sys.argv else R.parents[1]/'repo/plugins/dialogue-tutor/skills/dialogue-tutor/scripts/build_lesson.py'
subprocess.run([sys.executable,str(builder),'--lesson',str(R/'lesson.json'),'--output',str(R/'lesson.html')],check=True)
