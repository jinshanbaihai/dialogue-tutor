# 原创 S2 Chapter 6 复现与控件对照

本目录是 correction-run-01 的原创课程材料。根目录位置可变化；author.py按自己的目录读取exact-math.json、frame-contract.json、course-interactions.js与media/frames/<frameId>.png。manifest保留实际渲染时的原路径作为证据，组装不依赖那些绝对路径。

## 已有 JSON 直接重组单文件

在共享工作区根目录运行：

```bash
python3 repo/plugins/dialogue-tutor/skills/dialogue-tutor/scripts/build_lesson.py --lesson generation/correction-run-01/lesson.json --output generation/correction-run-01/rebuilt.html
```

lesson.json已经包含每个活动的脚本与内嵌PNG；使用批准版本builder即可重建。HTML使用原生MathML和内嵌PNG，无数学CDN、在线字体或运行时数学服务依赖。

## 从原创文本与同源数据重建

```bash
python3 generation/correction-run-01/author.py
python3 generation/correction-run-01/author-audit.py
node generation/correction-run-01/dom-check.cjs
```

若目录布局不同，使用 `python3 author.py --builder /批准skill的路径/scripts/build_lesson.py` 指定同版builder；数据和媒体仍按作者脚本所在目录相对读取。

重新生成共同有理数源：`python3 generation/correction-run-01/exact_data.py`。它同时生成frame-contract.json。数据或合同一旦改变，需要重新渲染相关媒体，不能沿用旧哈希。

实际Manim渲染使用原环境：

```bash
. work/manim-runtime/env.sh
python3 generation/correction-run-01/render_frames.py
```

具体命令与Manim版本、Scene哈希、每帧PNG哈希见render-log.txt与manim-manifest.json。字体与OFL见media/fonts/及visual-read-coverage.md。

## 原生控件 selector

| 学习动作 | selector |
|---|---|
| 主条件选择 | `#sampling-explorer [data-condition="main-wr"]` / `[data-condition="main-nr"]` |
| 身份路径 | `#sampling-explorer [data-path="AC"]`，所有允许路径各一个按钮 |
| 三个表征 | `#sampling-explorer [data-stage="paths"]` / `mapping` / `grouping` |
| 当前真Manim画面 | `[data-explorer-image]` |
| 同步公式、目标组、返回行 | `[data-explorer-formula]` / `[data-explorer-target]` / `[data-explorer-line]` |
| 均值4的原像多选 | `[name="preimage-path"][value="AC"]`，其它路径同样 |
| 原像提交/重试 | `[data-preimage-submit]` / `[data-preimage-retry]` |
| Q3第一组路径 | `[name="construct-path"][value="AB"]` |
| Q3第二组逐条均值 | `[name="construct-map"][data-map-path="AB"]` |
| Q3第三组概率依据 | `[name="construct-reason"][value="remaining"]`，另有old/means |
| Q3第四组分布 | `[name="construct-distribution"][value="thirds"]`，另有ninths/identity |
| Q3统一提交/重试 | `[data-construct-submit]` / `[data-construct-retry]` |
| Q3提示/跳过 | `[data-construct-hint]` / `[data-construct-skip]` |
| Q3各问自由阅读参考 | `#q3-a-solution` 至 `#q3-d-solution` 的原生summary |
| 全文自由展开 | `[data-open-all]` |
| 三个主错误分支入口 | `[data-dt-activity="main-equal"]` / `main-reverse` / `main-weight` |
| 选择题原生radio | `[name="dt-choice-main-equal"][value="five"]`（示例） |
| 选择题提交 | 对应活动内部 `[data-dt-control="submit"]` |
| 三个逐行修复块 | `#branch-equal` / `#branch-reverse` / `#branch-weight` |
| 新数据核对 | `[data-dt-activity="repair-equal-q-answer"]` 等 |
| 最后回忆卡 | `[data-dt-activity="final-recall"]` |
| 真实记录/继续入口 | `[data-report-refresh]` / `[data-report-next]` / `[data-report-construction]` / `[data-report-memory]` |

Q3正确原像为AB、AC、BA、BC、CA、CB；映射依次为2、5、2、7、5、7；概率依据remaining、分布thirds。此表供复核人员驱动实际控件，答案并非秘密。

## 状态与证据

公开runtime导出为`DialogueTutor.instance.exportState()`；完整状态为`getState()`。自定义活动只经`dt:exploration`保存exploration字段，不写objective attempts。可通过`CourseInspect.getState('construction-four')`检查四组原始选择、componentChecks、assistedAtSubmit和assistanceSnapshot；`getState('sampling-explorer')`查看currentFrame及每个conditionKey的revealedThrough/referenceCoverage。

旧记录导入使用现成`DialogueTutor.instance.importState(envelope)`。自定义恢复监听dt:restore，合并本地已接触条件，再通过restoreExploration静默写回；恢复不是学习操作，不生成提交。Q3每次提交前状态冻结，反馈只改变之后的辅助状态。保留最近25次自定义组件核对，正文说明它们不能认证独立完整证明。

## 检验边界

`dom-check.cjs`运行的是实际HTML脚本和原生DOM控件事件，使用jsdom，**不是浏览器**。Image.onload使用测试stub，因此图像加载竞态只证明事件/状态分支；没有把它写成实际解码或浏览器加载证据。实际PNG另外由作者与独立色彩评委目视和像素测量。

手机尺寸由CSS逐层计算：360px视口，body margin0，main左右16px，内容328px；手机activity与参考块左右padding0，activity左右border0，img自身两侧边框1px，保守图像内容326px。未把源font_size或整串文字bbox当成实际分子/分母字形。此计算不替代真正浏览器布局检验。

本课未进行真实浏览器视觉、系统屏幕朗读或键盘导航实测；这些限制保留供根最终审查。
