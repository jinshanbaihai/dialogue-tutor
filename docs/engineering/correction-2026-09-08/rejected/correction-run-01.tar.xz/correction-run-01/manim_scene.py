"""Frozen-JSON-driven, real ManimCE static frames; no external drawing."""
from manim import *
import manim, manimpango, json, os, hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'exact-math.json').read_text())
CONTRACT=json.loads((ROOT/'frame-contract.json').read_text())
P=DATA['palette']; INK=P['ink']; MUTED=P['muted']; TEAL=P['math-stat']; BLUE=P['math-x1']; PURPLE=P['math-x2']
FONT_PATH=ROOT/'media/fonts/NotoSansCJKsc-Regular.otf'
manimpango.register_font(str(FONT_PATH))
FONT='Noto Sans CJK SC'
config.pixel_width=1000; config.pixel_height=1250
config.frame_width=10; config.frame_height=12.5
config.background_color=WHITE
config.media_dir=str(ROOT/'media/manim-cache')
config.write_to_movie=False
config.save_last_frame=False

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def q(v): return Fraction(v['numerator'],v['denominator'])
def f(v):
 v=q(v) if isinstance(v,dict) else Fraction(v)
 return str(v.numerator) if v.denominator==1 else f'frac({v.numerator},{v.denominator})'
def plain(v):
 v=q(v); return str(v.numerator) if v.denominator==1 else str(v)
def at(x,y): return np.array([x,y,0.])

class SamplingFrames(Scene):
 def label(self,s,x,y,h=.55,color=INK):
  m=Text(s,font=FONT,color=color,disable_ligatures=True,font_size=60)
  m.scale_to_fit_height(h)
  # Size mixed-script ASCII glyph bodies independently; CJK/subscripts must not inflate their claimed size.
  for i,(ch,glyph) in enumerate(zip(s,m.chars)):
   if ch.isascii() and ch.isalnum() and glyph.height>0:
    minimum=.55 if ch.isdigit() else .58
    if glyph.height<minimum:
     old_left=glyph.get_left()[0]; old_width=glyph.width
     glyph.scale_to_fit_height(minimum)
     glyph.shift(RIGHT*(old_left-glyph.get_left()[0]))
     delta=glyph.width-old_width
     for later in m.chars[i+1:]: later.shift(RIGHT*delta)
  m.move_to(at(x,y)); self.add(m)
  glyphs=[{'character':ch,'bodyHeightPx':round(g.height*100,3),'bounds':self.bounds(g)} for ch,g in zip(s,m.chars) if ch.isascii() and ch.isalnum()]
  self.text_records.append({'type':'Text','text':s,'glyphBoxHeightPx':round(h*100,2),'asciiGlyphBodies':glyphs,'bounds':self.bounds(m)})
  return m
 def math(self,s,x,y,color=INK,unit=None):
  if 'T' in s: s=s.replace('T','{{ T : stat }}')
  m=MathTypst(s,font_size=72,color=color)
  # Reference cap digit is 60 px; display-style fraction numerals keep >=55 px.
  m.scale(.60/self.ref_digit_height)
  m.set_stroke(color=color,width=.45)
  for piece in m.family_members_with_points():
   if not piece.submobjects and piece.height < .035 and piece.width > .1:
    piece.set_stroke(color=color,width=5)
  for tag,col in [('stat',TEAL),('first',BLUE),('second',PURPLE),('result',TEAL)]:
   if ': '+tag+' }}' in s: m.select(tag).set_color(col)
  if unit:
   u=Text(unit,font=FONT,color=color,font_size=60).scale_to_fit_height(.55)
   m=VGroup(m,u).arrange(RIGHT,buff=.22)
  m.move_to(at(x,y)); self.add(m)
  self.text_records.append({'type':'MathTypst','source':s,'unit':unit,'referenceDigitHeightPx':60,'fractionRuleBounds':[self.bounds(piece) for piece in m.family_members_with_points() if not piece.submobjects and piece.height<.035 and piece.width>.1],'bounds':self.bounds(m)})
  return m
 def bounds(self,m):
  return [round((m.get_left()[0]+5)*100,2),round((6.25-m.get_top()[1])*100,2),round(m.width*100,2),round(m.height*100,2)]
 def badge(self,s,x,y,role,h=.82):
  col={'first-observation':BLUE,'second-observation':PURPLE,'statistic':TEAL}[role]
  sh=Circle(radius=h/2) if role=='first-observation' else Square(side_length=h)
  if role=='statistic': sh.rotate(PI/4)
  sh.set_stroke(col,9).set_fill(WHITE,1).move_to(at(x,y)); self.add(sh)
  self.label(s,x,y,.55,col)
 def title(self,c,kind):
  self.label({'grid':'有序抽样路径','mean':'一条路径 → 一个均值','bars':'统计量的抽样分布'}[kind],0,5.55,.65)
  self.label('有放回 · 独立等概率抽取' if c['replacement'] else '无放回 · 每次等概率抽取',0,4.55,.52,MUTED)
 def grid(self,c,fr):
  xs=[-1.45,.85,3.15]; ys=[1.65,.1,-1.45]
  self.label('第一抽 X₁',-3.45,3.25,.52,BLUE)
  self.label('第二抽 X₂',.85,3.98,.52,PURPLE)
  for i,u in enumerate(c['units']):
   self.badge(u['id'],-3.55,ys[i],'first-observation')
   self.badge(u['id'],xs[i],3.0,'second-observation')
  valid={p['id'] for p in c['paths']}
  for i,a in enumerate(c['units']):
   for j,b in enumerate(c['units']):
    pid=a['id']+b['id']; selected=pid==fr['pathId']; banned=pid not in valid
    box=RoundedRectangle(width=1.94,height=1.35,corner_radius=.15,stroke_color=TEAL if selected else P['line'],stroke_width=11 if selected else 4,fill_color=P['surface2'] if banned else WHITE,fill_opacity=1).move_to(at(xs[j],ys[i]));self.add(box)
    self.label(pid,xs[j],ys[i],.65,MUTED if banned else INK)
    if banned:
     self.add(Line(at(xs[j]-.7,ys[i]+.58),at(xs[j]+.7,ys[i]-.58),color=P['action'],stroke_width=9))
     self.add(Line(at(xs[j]-.7,ys[i]-.58),at(xs[j]+.7,ys[i]+.58),color=P['action'],stroke_width=9))
  self.label('   '.join(u['id']+'='+plain(u['value']) for u in c['units'])+' '+c['unit'],0,-2.8,.54)
  self.label('对角线可重复抽中同一单位' if c['replacement'] else '叉掉对角线：同一单位不能再抽',0,-3.45,.51,MUTED)
  p=next((p for p in c['paths'] if p['id']==fr['pathId']),c['paths'][0])
  factors=p['conditionalFactors']
  self.math(f"{f(factors[0])} times {f(factors[1])} = {f(p['probability'])}",0,-4.85)
 def mean(self,c,fr):
  p=next(p for p in c['paths'] if p['id']==fr['pathId']); a,b=p['values']; n=c['sample_size']
  self.badge(p['unitIds'][0],-3.75,3.25,'first-observation')
  self.badge(p['unitIds'][1],3.75,3.25,'second-observation')
  self.math(f"({f(a)}, {f(b)})",0,3.25,unit=c['unit'])
  self.label('X₁',-3.75,2.5,.51,BLUE)
  self.label('X₂',3.75,2.5,.51,PURPLE)
  self.label('代入',-3.95,1.55,.53,MUTED)
  self.math('T = frac({{ '+f(a)+' : first }} + {{ '+f(b)+' : second }}, '+str(n)+')',.65,1.55,unit=c['unit'])
  self.label('相加',-3.95,-.65,.53,MUTED)
  self.math(f'T = frac({f(p["sum"])}, {n})',.65,-.65,unit=c['unit'])
  self.label('除以'+str(n),-3.75,-2.85,.53,MUTED)
  self.math('T = {{ '+f(p['statisticValue'])+' : result }}',.65,-2.85,unit=c['unit'])
  self.badge('T',-3.0,-4.65,'statistic',.85)
  self.label('该路径映射到这个均值',.75,-4.65,.52,TEAL)
 def bars(self,c,fr):
  dist=c['distribution']; vals=[q(b['value']) for b in dist]
  main=c['id'] in ('main-wr','main-nr')
  xmin,xmax=(Fraction(2),Fraction(6)) if main else (min(vals),max(vals))
  span=xmax-xmin; left=-2.8; right=4.05; baseline=-1.25; top=2.1
  ymax=max(q(b['probability']) for b in DATA['cases']['main-wr']['distribution']) if main else max(q(b['probability']) for b in dist)
  # Axis bounds include padding; bar coordinates use the actual numerical scale.
  pad=span/Fraction(14); amin=xmin-pad; amax=xmax+pad
  ax=Axes(x_range=[float(amin),float(amax),1],y_range=[0,float(ymax),float(ymax)],x_length=right-left,y_length=top-baseline,tips=False,axis_config={'include_ticks':False,'include_numbers':False,'stroke_color':INK,'stroke_width':6})
  ax.shift(at(left,baseline)-ax.c2p(float(amin),0))
  self.add(ax.x_axis,Line(at(left,baseline),at(left,top),color=INK,stroke_width=6))
  self.label('概率',-3.85,3.85,.52)
  self.math(f(ymax),-4.02,top)
  self.label('0',-3.63,baseline,.55)
  self.add(DashedLine(at(left,top),at(right,top),color=P['line'],stroke_width=5))
  self.axis_record={'xMin':str(amin),'xMax':str(amax),'yMin':'0','yMax':str(ymax),'xScale':'linear numeric values','yScale':'linear probability','plotBoundsPx':[220,415,685,335]}
  ticks=[Fraction(i) for i in range(2,7)] if main else vals
  for v in ticks:
   pos=ax.c2p(float(v),0)
   if not (c['id']=='main-nr' and v not in vals):
    self.add(Line(pos+DOWN*.04,pos+DOWN*.16,color=INK,stroke_width=6))
   self.math(f(v),pos[0],-2.4 if v.denominator>1 else -2.0)
  self.badge('T',-3.6,-3.75,'statistic',.85)
  self.label(('最大值' if c['statistic']=='maximum' else '均值')+'（'+c['unit']+'）',.55,-3.75,.55,TEAL)
  minstep=min((b-a for a,b in zip(vals,vals[1:])),default=span)
  width=min(.78,float(minstep/(amax-amin))*(right-left)*.62)
  for b in dist:
   x,y=ax.c2p(float(q(b['value'])),float(q(b['probability'])))[:2]
   selected=fr['pathId'] is not None and b['id'] in fr['barIds']
   bar=Rectangle(width=width,height=y-baseline,fill_color=TEAL,fill_opacity=.72 if not selected else 1,stroke_color=INK if selected else TEAL,stroke_width=11 if selected else 1).move_to(at(x,(y+baseline)/2));self.add(bar)
   self.math(f(b['probability']),x,y+1.02)
  if c['id']=='main-nr':
   for v in (xmin,xmax):
    pos=ax.c2p(float(v),0);self.add(Circle(radius=.11,stroke_color=MUTED,stroke_width=9,fill_opacity=1,fill_color=WHITE).move_to(pos));self.label('0',pos[0],baseline+.5,.51,MUTED)
  if fr['pathId']:
   b=next(b for b in dist if b['id'] in fr['barIds'])
   self.label('该柱汇集：'+'、'.join(b['pathIds']),0,-4.85,.51)
   self.label('当前路径 '+fr['pathId']+' → 描边目标柱',0,-5.55,.51,TEAL)
  else:
   self.label('横轴距离对应真实数值差',0,-4.85,.51,MUTED)
   self.label('所有柱的概率之和为 '+plain(c['totalMass']),0,-5.55,.51)
 def construct(self):
  self.ref_digit_height=MathTypst('2',font_size=72).height
  frames=CONTRACT['frames']; chosen=os.getenv('FRAME_IDS')
  if chosen: frames=[f for f in frames if f['frameId'] in chosen.split(',')]
  output=[]
  for fr in frames:
   self.clear();self.text_records=[];self.axis_record=None
   c=DATA['cases'][fr['caseId']]; assert fr['conditionKey']==c['conditionKey']
   self.title(c,fr['kind']);getattr(self,fr['kind'])(c,fr)
   self.camera.reset();self.camera.capture_mobjects(self.mobjects)
   image=self.camera.get_image().convert('RGB')
   path=ROOT/'media/frames'/f'{fr["frameId"]}.png';path.parent.mkdir(parents=True,exist_ok=True)
   image.save(path,optimize=True,compress_level=9)
   objects=[]
   for obj in DATA['objects']:
    values=[p['values'][0 if obj['role']=='first-observation' else 1] if obj['role']!='statistic' else p['statisticValue'] for p in c['paths'] if p['id'] in fr['pathIds']]
    objects.append({**obj,'exactValues':values,'pathIds':fr['pathIds']})
   output.append({**fr,'file':str(path),'sha256':sha(path),'width':1000,'height':1250,'objects':objects,'objectsMeaning':'semantic mapping; not an inventory of visible glyphs','renderedRoles':(['first-observation','second-observation'] if fr['kind']=='grid' else ['first-observation','second-observation','statistic'] if fr['kind']=='mean' else ['statistic']),'visiblePaths':c['paths'] if fr['kind']=='grid' else [p for p in c['paths'] if p['id'] in fr['pathIds']],'visibleBars':c['distribution'] if fr['kind']=='bars' else [],'axis':self.axis_record,'textObjects':self.text_records})
   print('FRAME_RENDERED '+fr['frameId']+' '+sha(path),flush=True)
  manifest={'renderer':'ManimCE Cairo Scene.render → Camera.capture_mobjects → PNG','manimVersion':manim.__version__,'sceneClass':'SamplingFrames','dataHash':sha(ROOT/'exact-math.json'),'frameContractHash':sha(ROOT/'frame-contract.json'),'sceneSourceHash':sha(__file__),'command':os.getenv('RENDER_COMMAND','manim -s --renderer=cairo generation/correction-run-01/manim_scene.py SamplingFrames'),'font':{'family':FONT,'path':str(FONT_PATH),'sha256':sha(FONT_PATH)},'frameCount':len(output),'frames':output,'limitations':['Static PNG review only; no browser testing.','No video requested or generated.']}
  (ROOT/'manim-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
