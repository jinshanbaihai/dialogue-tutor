from fractions import Fraction as F
from itertools import product,permutations
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).parent

def r(x):
 x=F(x);return {'numerator':x.numerator,'denominator':x.denominator}
def case(cid,values,replacement,statistic='mean',unit='天'):
 units=[{'id':chr(65+i),'value':r(v)} for i,v in enumerate(values)]
 n=len(units); paths=[];groups={}
 for ids in (product(range(n),repeat=2) if replacement else permutations(range(n),2)):
  vals=[F(values[i]) for i in ids];t=sum(vals)/2 if statistic=='mean' else max(vals)
  p=F(1,n)*F(1,n if replacement else n-1);pid=''.join(units[i]['id'] for i in ids)
  row={'id':pid,'unitIds':[units[i]['id'] for i in ids],'values':[r(v) for v in vals],'sum':r(sum(vals)),'statisticValue':r(t),'conditionalFactors':[r(F(1,n)),r(F(1,n if replacement else n-1))],'probability':r(p),'lineIds':[f'{cid}-{pid}-sub',f'{cid}-{pid}-add',f'{cid}-{pid}-div']}
  paths.append(row);groups.setdefault(t,[]).append(row)
 ck=cid+':v1:'+','.join(f'{u["id"]}={F(values[i])}' for i,u in enumerate(units))+f':n=2:{"independent-uniform-with-replacement" if replacement else "uniform-without-replacement"}:{statistic}'
 return {'id':cid,'conditionKey':ck,'units':units,'sample_size':2,'replacement':replacement,'independent':replacement,'statistic':statistic,'unit':unit,'paths':paths,'distribution':[{'id':f'{cid}-bar-{i}','value':r(t),'probability':r(sum((F(p['probability']['numerator'],p['probability']['denominator']) for p in ps),F(0))),'pathIds':[p['id'] for p in ps],'lineId':f'{cid}-group-{i}'} for i,(t,ps) in enumerate(sorted(groups.items()))],'totalMass':r(sum((F(p['probability']['numerator'],p['probability']['denominator']) for p in paths),F(0)))}
D={'schemaVersion':1,'palette':{'canvas':'#F6F5F2','surface':'#FFFFFF','surface2':'#EEEDE8','ink':'#202C39','muted':'#586674','line':'#D4D8DC','control-line':'#7B8792','action':'#8C4A25','math-x1':'#2364AA','math-x2':'#7250A4','math-stat':'#0F7074'},'objects':[{'objectId':'sample-first','role':'first-observation','label':'X₁','token':'math-x1','shape':'circle'},{'objectId':'sample-second','role':'second-observation','label':'X₂','token':'math-x2','shape':'square'},{'objectId':'sample-stat','role':'statistic','label':'T','token':'math-stat','shape':'diamond'}],'cases':{}}
for args in [('main-wr',[2,4,6],True),('main-nr',[2,4,6],False),('example-max',[1,5],True,'maximum','小时'),('construct',[0,4,10],False,'mean','分钟'),('duplicates',[0,0,6],False,'mean','次'),('repair-equal',[1,5,9],True,'mean','厘米'),('repair-reverse',[1,3,7],True,'mean','克'),('repair-weight',[2,5,11],False,'mean','分钟')]:
 c=case(*args);D['cases'][c['id']]=c
raw=json.dumps(D,ensure_ascii=False,indent=2)+'\n';(ROOT/'exact-math.json').write_text(raw)
frames=[]
for cid,c in D['cases'].items():
 if cid.startswith('main-'):
  frames.append({'frameId':cid+'-overview','conditionKey':c['conditionKey'],'caseId':cid,'kind':'grid','stageId':'paths','pathId':None,'pathIds':[p['id'] for p in c['paths']],'barIds':[],'lineIds':[cid+'-weight']})
  for p in c['paths']:
   bar=next(b for b in c['distribution'] if p['id'] in b['pathIds'])
   for stage,kind in [('paths','grid'),('mapping','mean'),('grouping','bars')]:
    frames.append({'frameId':cid+'-'+p['id']+'-'+stage,'conditionKey':c['conditionKey'],'caseId':cid,'kind':kind,'stageId':stage,'pathId':p['id'],'pathIds':[p['id']],'barIds':[bar['id']],'lineIds':p['lineIds'] if kind!='bars' else [bar['lineId']]})
 frames.append({'frameId':cid+'-distribution','conditionKey':c['conditionKey'],'caseId':cid,'kind':'bars','stageId':'distribution','pathId':None,'pathIds':[p['id'] for p in c['paths']],'barIds':[b['id'] for b in c['distribution']],'lineIds':[b['lineId'] for b in c['distribution']]})
contract={'dataHash':hashlib.sha256(raw.encode()).hexdigest(),'frames':frames,'render':{'pixelWidth':1000,'pixelHeight':1250,'background':'#FFFFFF','minimumKeyGlyphHeightPx':55,'minimumOrdinaryGlyphHeightPx':49},'requirements':'Actual ManimCE static frames. Grid 3x3 with row first draw X1 blue circle and column second draw X2 purple square; banned identity diagonals marked. Mean panel 3 separate lines substitution/addition/division; exactly one selected path. Bars separate panel; X axis exact numeric mean spacing, same y axis main-wr/main-nr (0 to 1/3), full probabilities label, target bar outline and contribution path caption. T teal diamond. Match exact-math JSON; do not recompute or handcopy probabilities. Frame IDs exact. No fake buttons in image. Discrete support zero occupancy for main-nr endpoints allowed hollow markers labeled0. Fractions MathTypst. Perframe metadata objects with values/roles and source/hash.'}
(ROOT/'frame-contract.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2)+'\n')
print(len(frames),contract['dataHash'])
