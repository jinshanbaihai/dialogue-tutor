from pathlib import Path
import json,hashlib
R=Path(__file__).parent;BASE=R.parents[1];items=[]
def add(path,ranges=None,note='全文实际读取；非仅搜索命中'):
 p=BASE/path;data=p.read_bytes();n=len(data.decode().splitlines());items.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'lineCount':n,'readRanges':ranges or [[1,n]],'coverage':'full' if not ranges else 'partial','note':note})
sk='repo/plugins/dialogue-tutor/skills/dialogue-tutor/'
add(sk+'SKILL.md',None,'2291行按连续区段1–500、501–900、901–1300、1301–1700、1701–2100、2101–2291读取。较早1–600汇总输出截断后重新读取1–500；结尾2101–2291另行重读。')
for f in ['interactive-html.md','modes-and-explanations.md','teaching-design.md','visual-design.md','engagement-and-narrative.md','deeptutor-provenance.md','learning-evidence.md','expert-review.md','数学的冲突读法.md','统计术语中英对照.md','考纲与考试局.md']:
 add(sk+'references/'+f,None,'全文读取；interactive-html聚合截断处另外读取205–350；learning-evidence/expert-review/数学的冲突读法单独补读全文；未读取所链接旧样章文件。')
for f in ['research/correction-sources/s2-scope.md','reviews/correction-s2-math-acceptance.md','reviews/correction-program-implementation.md','repo/docs/engineering/correction-2026-09-08/validation-plan.md']:add(f)
man='research/dependencies/cowork-bundles/manim/'
for f in ['SKILL.md','repos/manim/docs/tutorials/quickstart.rst','repos/manim/docs/tutorials/building_blocks.rst','repos/manim/example_scenes/basic.py','repos/manim/docs/guides/using_text.rst']:
 if (BASE/(man+f)).exists():add(man+f,None,'完整读取。building_blocks聚合中间截断约127tokens，另补读60–122、210–270、420–480。渲染者另有visual-read-coverage.md。')
add(man+'repos/manim/docs/guides/configuration.rst',[[1,190]],'实际读取CLI与config全局对象相关部分；未声称后半全文。')
add(man+'repos/manim/api/mobject-graphing.md',[[1901,2170]],'Axes构造、配置、_create_axis和坐标转换相关段实际读取。一次cat尝试被截断，不计为全文；helper另记录它的实际范围。')
obra='research/dependencies/cowork-bundles/obra-superpowers/'
for f in ['SKILL.md','skills/obra-requesting-code-review/REFERENCE.md','skills/obra-requesting-code-review/code-reviewer.md','skills/obra-receiving-code-review/REFERENCE.md','skills/obra-verification-before-completion/REFERENCE.md','skills/obra-dispatching-parallel-agents/REFERENCE.md','skills/obra-subagent-driven-development/REFERENCE.md','skills/obra-subagent-driven-development/implementer-prompt.md','skills/obra-subagent-driven-development/task-reviewer-prompt.md','skills/obra-subagent-driven-development/re-review-prompt.md']:add(obra+f,None,'全文读取；实施/评委职责依根任务覆盖：作者仅1个视觉helper，独立批评由根执行，不自派批评者；不提交Git。re-review末22行补读。')
em='research/dependencies/cowork-bundles/emilkowalski-skills/'
for f in ['SKILL.md','skills/emil-design-eng/REFERENCE.md']:add(em+f,None,'实际全文；设计参考分1–350、351–末读取。高频点击采用即时切换，遵守reduced-motion；未调用无关动画路线。')
ws='research/dependencies/plugins/ai-workspace/skills/'
add(ws+'writing-style/SKILL.md',None,'915行全文分1–320、321–650、651–末读取；自检§17与AI套话清单另重读。')
add(ws+'respectful-wording/SKILL.md',None,'305行全文读取；交付检查与例外另重读。')
add(ws+'respectful-wording/scripts/单字检查.py',[[1,70],[151,205]],'原脚本实际运行；读取用途、例外、扫描与输出实现。')
for f in ['QuizBlock.tsx','FlashCardsBlock.tsx']:add('research/DeepTutor/web/app/(workspace)/books/components/blocks/'+f,None,'本轮实际读取原源码；仅把选择/翻卡契约归因DeepTutor，自定义四组构造与state并集为原创适配。')
add(sk+'scripts/build_lesson.py',[[1,160],[457,498],[550,555]],'实际接口读取与定点检索后执行现成builder；未声称全文读取。')
add(sk+'assets/interactive/lesson-runtime.js',[[224,262],[340,364],[600,645],[698,750],[895,925],[1290,1344]],'实际定点读取，并另检索reveal/exposure/restore/attempt/renderRemediation等调用；由实际DOM操作验证整合，未声称读完全部runtime。')
add(sk+'assets/interactive/lesson-runtime.css',[[36,60],[342,365]],'实际读取基础容器和手机padding；并定点检索所有padding/margin/max-width以核嵌套尺寸。')
(R/'generation-read-coverage.json').write_text(json.dumps({'author':'independent original author correction-run-01','date':'2026-09-08','files':items,'notRead':['repo/docs/s2-ch6.html','generation/run*','approved skill examples HTML/JSON course content','prior author course content','independent math oracle implementation'],'hashOnlyProvided':'skill-hashes.json was pre-frozen by root and contains hashes of historical examples; those example files were not opened by this author.','webReadScopes':'See sources.json and source-reading.md; source scope is distinguished from full document reading.','visualHelper':'See visual-read-coverage.md for actual separate render helper reading.','modelSettings':'backend identifier, seed, temperature not exposed; generation-conditions.json retains this uncertainty.'},ensure_ascii=False,indent=2))
print('Recorded',len(items),'actual source read records.')
