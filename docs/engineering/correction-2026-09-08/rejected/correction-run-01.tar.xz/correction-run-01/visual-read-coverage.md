# Visual render read coverage and evidence

## Read coverage

The following files were read in full. Output truncation around the basic.py/building_blocks boundary was repaired with a separate full basic.py read and the building_blocks tail.

- `research/dependencies/cowork-bundles/manim/SKILL.md` — SHA-256 `d86400bf5bda1760430d88b65b7268c52a50bcaf928be21006818b31a096fd7a`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/tutorials/quickstart.rst` — SHA-256 `844baaae5898fc0a6381dd4d8ad9730ee35ffb547fc2f628b60d76579f971931`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/tutorials/building_blocks.rst` — SHA-256 `3615efe105abfdf79e564b94b260f10ebe426e9fa0b421aa46a4bf8b365aac27`
- `research/dependencies/cowork-bundles/manim/repos/manim/example_scenes/basic.py` — SHA-256 `7d249b0e3441f01a4866d1fc3ca56d278f97c92e2e4eaa89ab40591f22f1189f`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/guides/using_text.rst` — SHA-256 `f39f03bc6fc464f8086e313a67c2941c5ebf75cff147037adebc37505460318a`
- `research/dependencies/cowork-bundles/manim/repos/manim/docs/guides/configuration.rst` — SHA-256 `5fa13e90b10075c61e8e9e49498826fac7a8d6b7f091ee2317f2283f8e7d5e9c`

- Required graphing API: `research/dependencies/cowork-bundles/manim/repos/manim/api/mobject-graphing.md`, lines 1901–2185, Axes constructor, styling, axis creation, numerical coordinate conversion.
- Frozen `exact-math.json` and `frame-contract.json` were read completely in compact JSON chunks. No frozen source modification.

## Render provenance

- Real ManimCE 0.21.0 `SamplingFrames(Scene)`, invoked by Manim CLI; construct adds Manim objects and captures each scene state using `Camera.capture_mobjects` and `get_image` during Scene.render.
- Final command: `. work/manim-runtime/env.sh` then `python generation/correction-run-01/render_frames.py`.
- Fractions and all rendered mathematical expressions use MathTypst; shapes, axes, bars and crosses are Manim objects.
- PNG files saved from camera pixels with PIL lossless PNG optimize/compress_level=9 only. No raster redrawing, manual SVG substitution, browser, Playwright or video.
- 55 PNGs; 1000×1250 each; total 6,184,300 bytes (base64 about 8,245,734 bytes).
- Ordinary Chinese labels retain their reference sizing. Mixed Text ASCII digits are independently enlarged to 55 source-pixel geometry and capital bodies to 58; the actual pixel-body results below supersede any inference from the whole-string bbox. MathTypst reference digit remains 60 px. Natural subscripts and punctuation retain their typographic size.
- Every frame retains exact conditionKey, lineIds, pathIds and barIds from contract; objects retain role/token/exact values. Each frame records its PNG hash and text bounds.
- Same main-wr/main-nr y-axis range 0 to 1/3, identical plotting geometry; numerical x spacing preserved. The duplicates y-axis is explicitly drawn at the plot left so x=0 cannot run through its label.

## Visual QA scope

- Final direct view_image inspection: main-wr-AB-mapping, main-wr-CC-mapping, main-wr-AB-grouping, main-nr-overview, duplicates-distribution, repair-weight-distribution.
- Earlier direct inspection of unchanged layouts: main-wr-AB-paths, main-nr-distribution, repair-reverse-distribution, example-max-distribution.
- Fixed overlapping large mean fractions, grid footer clipping, repair-weight fractional x-label overlap, faint fraction rules, missing X₁/X₂ labels, incorrect through-zero visual y-axis placement, and colored T/operand roles.
- Final inspected frames show no clipped content. All 55 recorded text bounding boxes pass programmatic in-frame validation. No claim of browser/mobile viewport execution or of manually inspecting all 55 individually.

## Font provenance

- Official font URL: https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf
- Family: Noto Sans CJK SC; font kept at `media/fonts/NotoSansCJKsc-Regular.otf`.
- Font SHA-256: `2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b`.
- License: SIL Open Font License 1.1; official license URL: https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/LICENSE
- Full license saved at `media/fonts/OFL-LICENSE.txt`; SHA-256 `6a73f9541c2de74158c0e7cf6b0a58ef774f5a780bf191f2d7ec9cc53efe2bf2`.

## Final artifact hashes

- `manim_scene.py` — SHA-256 `d7d3674a98d7b7c6b0b5bf6aa4cffaa27879f3e03f3a92ca50a7ce816ce1a538`
- `render_frames.py` — SHA-256 `81797a95d6957fc9adfdf7dd19e1f3120a3408e1fb87cc73758f28daaee42a79`
- `exact-math.json` — SHA-256 `9ef3d790e4a6c5a4428bc0d00c4916371655be140e8e6d0e34ce798bf76aeccb`
- `frame-contract.json` — SHA-256 `e9ef6f7adffc1c67fb6934545125bd201d4aecfd5fcd6639b5f4cd9a7621e299`
- `manim-manifest.json` — SHA-256 `329a4532bd8e807822327d8ed582ed0a69446853ad277febe4322e0325b7bf6c`
- `render-log.txt` — SHA-256 `74046183b555e2ebe9e204b7651ece84ee10277bbcc7cfd60b700bc1094b3ab1`

## Component revision after independent review I1/I2/M1/M2

- Read the full review `reviews/correction-color-frames-run-01.md`, SHA-256 `6406ccb4df9db5464622528c4193c85f0ac1ddd71938c08a441268a49f813559`. Rejected archived files were not edited.
- Applied all listed line classes together. Parameters are only design inputs; pass evidence comes from actual PNG normal profiles. Necessary axes/ticks use width 6, identity/T/zero outlines and exclusion crosses 9, current frame/bar emphasis 11, auxiliary cells 4, dashed guide 5, fraction rules 5. Unselected bars retain their original fill and 1-width teal perimeter.
- Mixed-script labels are processed per ASCII glyph body with natural spacing restored after each enlargement. This includes every legend digit, division-step digit, X body, path caption and probability-total digit; no CJK character or subscript is used to claim a Latin-body size. `asciiGlyphBodies` stores their geometry and `media/pixel-measurements.json` stores independent pixel crop measurements. The legacy `glyphBoxHeightPx` field is the original reference sizing input, not a per-glyph measurement.
- Compact matrix rows create room for the larger legend; probability formulas moved up without reducing digits. Bottom captions and the fractional-axis legend were reflowed. Both main charts share plotBoundsPx=[220,415,685,335], y range 0 to 1/3, unchanged x spacing and proportional probability heights.
- `objects` is explicitly marked as a semantic mapping rather than a visible inventory. `renderedRoles` records grid first/second roles, mean first/second/statistic roles, and bars statistic role.
- Final actual-Manim CLI process exit 0 is recorded in render-log. Exact frame contract fields, all source/data/PNG hashes, 55 dimensions and all recorded text bounds passed.
- Final direct original-PNG inspection: main-nr-overview, main-wr-AB-mapping, main-wr-AB-grouping, main-nr-distribution, repair-weight-distribution. All showed clear spacing and no clipped content after the revision. This is representative original-PNG review, not 55-frame manual review or browser execution.
- 326px line probes use in-memory Lanczos resampling and normal-axis foreground-coverage integration, with three tangent samples. Curved/diagonal objects are measured in their local normal direction. Current black bar border is measured against white outside and teal inside, so its fill is not counted as black border. No resampled derivative replaces a Manim PNG.

|Line class|Source effective px|326px effective px|Required CSS px|
|---|---:|---:|---:|
|necessary-y-axis|6.0|2.049|1.5|
|necessary-x-axis|6.0|2.032|1.5|
|numeric-tick|6.0|2.117|1.5|
|first-circle-outline|9.125|3.169|2.5|
|second-square-outline|9.108|3.148|2.5|
|statistic-diamond-outline|8.908|3.006|2.5|
|zero-probability-ring|8.998|3.021|2.5|
|current-path-outline|11.0|3.615|3.0|
|current-bar-outline|11.002|3.587|3.0|
|exclusion-cross|9.032|2.927|2.5|
|auxiliary-grid|4.0|1.42|1.0|
|auxiliary-probability-guide|5.0|1.308|1.0|
|fraction-rule|5.0|1.705|1.0|

- All 794 measured ASCII glyph bodies across all 55 Text inventories pass: numeric bodies ≥16 CSS px budget, capital mathematical/path bodies ≥18 CSS px budget at 326px. Representative legend digits are 55 actual source pixels (17.93px budget); X bodies are 58 (18.908px); division-step 2 and total-probability 1 are 56 (18.256px). Natural subscripts are excluded from this body floor.
- All 55 frames have at least 41 source pixels of bottom clearance (13.366px budget at 326). Line-width probes, per-glyph results, source frame hashes and bottom-clearance measurements: `media/pixel-measurements.json`.

- Pixel measurement report SHA-256: `7bab8315ad415790b6a053e2b4e07043bc2874be2faa1ea6309137f880c94bc9`.
