"""Run after `. work/manim-runtime/env.sh`; render and verify frozen 55-frame contract."""
import subprocess, os, json, hashlib, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def measure_pixels():
 import numpy as np
 from PIL import Image
 root=ROOT; manifest=json.loads((root/'manim-manifest.json').read_text())
 palette=json.loads((root/'exact-math.json').read_text())['palette']
 rgb=lambda token:np.array([int(palette.get(token,token).lstrip('#')[i:i+2],16) for i in (0,2,4)],float)
 white=np.array([255.,255.,255.]); ink=rgb('ink'); teal=rgb('math-stat')
 cached={}
 def arr(frame,width):
  key=(frame,width)
  if key not in cached:
   im=Image.open(root/'media/frames'/f'{frame}.png').convert('RGB')
   if width!=1000: im=im.resize((width,round(1250*width/1000)),Image.Resampling.LANCZOS)
   cached[key]=np.asarray(im,dtype=float)
  return cached[key]
 def probe(frame,point,normal,fg,bg0,bg1=None,extent=12,width=1000):
  a=arr(frame,width); scale=width/1000.; n=np.array(normal,float);n/=np.linalg.norm(n); tangent=np.array([-n[1],n[0]])
  t=np.linspace(-extent*scale,extent*scale,961);profiles=[]
  for offset in [-1.5,0,1.5]:
   p=np.array(point)*scale+t[:,None]*n+offset*scale*tangent-.5
   x,y=p[:,0],p[:,1];x0=np.floor(x).astype(int);y0=np.floor(y).astype(int);dx=(x-x0)[:,None];dy=(y-y0)[:,None]
   pix=a[y0,x0]*(1-dx)*(1-dy)+a[y0,x0+1]*dx*(1-dy)+a[y0+1,x0]*(1-dx)*dy+a[y0+1,x0+1]*dx*dy
   bg=np.repeat(np.array(bg0)[None,:],len(t),axis=0)
   if bg1 is not None:bg[t>0]=bg1
   d=bg-fg;alpha=np.clip(np.sum((bg-pix)*d,axis=1)/np.sum(d*d,axis=1),0,1)
   profiles.append(float(np.trapezoid(alpha,t)))
  return round(float(np.median(profiles)),3)
 group='main-wr-AB-grouping'; grid='main-wr-AB-paths'; nr='main-nr-distribution'
 point_x=lambda value:220+(value-12/7)/(32/7)*685
 specs=[
  ('necessary-y-axis',group,[220,450],[1,0],ink,white,None,12,1.5),
  ('necessary-x-axis',group,[330,750],[0,1],ink,white,None,12,1.5),
  ('numeric-tick',group,[point_x(3),760],[1,0],ink,white,None,12,1.5),
  ('first-circle-outline',grid,[145,419],[0,1],rgb('math-x1'),white,None,12,2.5),
  ('second-square-outline',grid,[585,284],[0,1],rgb('math-x2'),white,None,12,2.5),
  ('statistic-diamond-outline',group,[140+.85*100/(2**.5)*.25,1000-.85*100/(2**.5)*.75],[1,-1],teal,white,None,12,2.5),
  ('zero-probability-ring',nr,[point_x(2)-11/(2**.5),750-11/(2**.5)],[-1,-1],rgb('muted'),white,None,9,2.5),
  ('current-path-outline',grid,[585,392.5],[0,1],teal,white,None,12,3.0),
  ('current-bar-outline',group,[point_x(3)-39,630],[1,0],ink,white,teal,12,3.0),
  ('exclusion-cross', 'main-nr-overview',[300,402+15*116/140],[-116,140],rgb('action'),rgb('surface2'),None,12,2.5),
  ('auxiliary-grid',grid,[355,392.5],[0,1],rgb('line'),white,None,12,1.0),
  ('auxiliary-probability-guide',group,[330,415],[0,1],rgb('line'),white,None,12,1.0),
 ]
 for frame in manifest['frames']:
  if frame['frameId']=='main-wr-AB-mapping':
   eq=next(t for t in frame['textObjects'] if t.get('fractionRuleBounds'))
   x,y,w,h=eq['fractionRuleBounds'][0]
   specs.append(('fraction-rule','main-wr-AB-mapping',[x+w/2,y+h/2],[0,1],ink,white,None,10,1.0))
 rows=[]
 for name,frame,point,normal,fg,bg0,bg1,extent,minimum in specs:
  # A dashed guide needs a location on a dash, not in an intentional gap.
  if name=='auxiliary-probability-guide':
   candidates=range(318,347)
   point[0]=max(candidates,key=lambda x:probe(frame,[x,415],normal,fg,bg0,extent=extent,width=1000))
  source=probe(frame,point,normal,fg,bg0,bg1,extent,1000);css=probe(frame,point,normal,fg,bg0,bg1,extent,326)
  rows.append({'lineClass':name,'frameId':frame,'sourcePoint':point,'unitNormal':normal,'sourceEffectiveWidthPx':source,'at326EffectiveWidthPx':css,'minimumCssPx':minimum,'passes':css>=minimum})
 # Every actual ASCII numeric/capital body in every manifest Text object is checked in original camera pixels.
 glyphs=[];bottoms=[]
 for frame in manifest['frames']:
  a=arr(frame['frameId'],1000)
  for text in frame['textObjects']:
   for glyph in text.get('asciiGlyphBodies',[]):
    x,y,w,h=glyph['bounds']; crop=a[max(0,int(np.floor(y))):min(1250,int(np.ceil(y+h))+1),max(0,int(np.floor(x))):min(1000,int(np.ceil(x+w))+1)]
    mask=crop.min(axis=2)<180;present=np.flatnonzero(mask.any(axis=1));height=int(present[-1]-present[0]+1) if len(present) else 0
    minimum=16 if glyph['character'].isdigit() else 18
    glyphs.append({'frameId':frame['frameId'],'text':text['text'],'character':glyph['character'],'sourceBodyHeightPx':height,'at326BudgetPx':round(height*.326,3),'minimumCssPx':minimum,'passes':height*.326>=minimum})
  pixels=(a.min(axis=2)<180).any(axis=1);last=int(np.flatnonzero(pixels)[-1]);bottoms.append({'frameId':frame['frameId'],'sourceBottomClearPx':1249-last,'at326BudgetPx':round((1249-last)*.326,3)})
 report={'method':'Actual camera PNG RGB profiles; sRGB foreground coverage integrated along normal, median of 3 tangent samples. 326px Lanczos resampling is in-memory for pixel budgeting, not browser testing. ASCII body crops use min(R,G,B)<180. Natural subscripts excluded from body floor.','lineWidths':rows,'asciiGlyphBodies':glyphs,'bottomClearance':bottoms,'sourceHashes':{f['frameId']:f['sha256'] for f in manifest['frames']},'sceneSourceHash':manifest['sceneSourceHash']}
 (root/'media/pixel-measurements.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps({'lines':rows,'glyphCount':len(glyphs),'glyphFailures':[g for g in glyphs if not g['passes']],'minimumBottomClearPx':min(b['sourceBottomClearPx'] for b in bottoms)},ensure_ascii=False,indent=2))
 return report

if '--measure-only' in sys.argv:
 measure_pixels();raise SystemExit(0)
cmd=['manim','-s','--renderer=cairo',str(ROOT/'manim_scene.py'),'SamplingFrames']
env=os.environ.copy();env.pop('FRAME_IDS',None);env['RENDER_COMMAND']='. work/manim-runtime/env.sh && '+ ' '.join(cmd)
with (ROOT/'render-log.txt').open('w') as log:
 log.write('COMMAND '+env['RENDER_COMMAND']+'\n');log.flush()
 subprocess.run(['manim','--version'],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
 subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
 log.write('MANIM_PROCESS_EXIT: 0\n');log.flush()
M=json.loads((ROOT/'manim-manifest.json').read_text());C=json.loads((ROOT/'frame-contract.json').read_text())
assert M['frameCount']==55
assert [f['frameId'] for f in M['frames']]==[f['frameId'] for f in C['frames']]
violations=[]
for frame in M['frames']:
 assert hashlib.sha256(Path(frame['file']).read_bytes()).hexdigest()==frame['sha256']
 for obj in frame['textObjects']:
  x,y,w,h=obj['bounds']
  if x<0 or y<0 or x+w>1000 or y+h>1250:violations.append([frame['frameId'],obj])
if violations:
 print(json.dumps(violations,ensure_ascii=False,indent=2));raise SystemExit('Text exceeds frame')
print('Verified 55 exact IDs, all PNG hashes, 1000×1250 text bounds; PNG bytes:',sum(Path(f['file']).stat().st_size for f in M['frames']))

report=measure_pixels()
assert all(r['passes'] for r in report['lineWidths']), 'PNG line floor failed'
assert all(r['passes'] for r in report['asciiGlyphBodies']), 'PNG glyph body floor failed'
assert all(r['sourceBottomClearPx']*.326>=12 for r in report['bottomClearance']), 'Bottom breathing space failed'
with (ROOT/'render-log.txt').open('a') as log: log.write('POST_RENDER_VALIDATION: PASS 55 exact IDs, all frame hashes, all text bounds, actual PNG line and ASCII body floors at 326px.\n')
