# 原创课程蓝图

三个上层对象各七幕：总体与抽样；统计量及参数边界；抽样分布。每组包含问题缺口、来源限制明确的历史视角、全部前提与构造、另一个原创例题、第二种表征、边界、下层题号索引。

下层Q1(a–c)、Q2(a–c)、Q3(a–d)、Q4(a–b)全部有完整英文/中文题面和六项解释。三个修复分支各有原断点、完整小步、精确返回行和新数值完整题。原始活动位置、前提和条件键见activity-map.json；逐行式子与具体理由见proof-lines.json。

Q3先选完整路径、逐条映射、条件概率依据、完整分布；四组统一提交，原始选择和提交前辅助状态冻结。自定义核对仅存exploration.submissions，不写客观attempts。所有局部全解初始关闭但可自由打开。

真实Manim帧与图文共同来源为exact-math.json；通过frame-contract.json映射lineIds/pathIds/barIds/objectRoles。图形、公式与目标组同步提交，回退当前画面不清除revealedThrough或参考覆盖。
