"""Check authored MathML arithmetic against the frozen rational dataset; not the independent oracle."""
from pathlib import Path
from fractions import Fraction
import json,xml.etree.ElementTree as ET,hashlib
R=Path(__file__).parent
D=json.loads((R/'exact-math.json').read_text()); rows={r['lineId']:r for r in json.loads((R/'proof-lines.json').read_text())}
def F(r):return Fraction(r['numerator'],r['denominator'])
def node(s):return ET.fromstring('<mrow>'+ (s if '<' in s else '<mn>'+s+'</mn>') +'</mrow>')
def calc(x):
 if x.tag=='mn':return Fraction(x.text)
 if x.tag=='mfrac':return calc(x[0])/calc(x[1])
 if x.tag=='mrow':
  values=[];op='+'
  for c in x:
   if c.tag=='mo':op=c.text
   else:
    v=calc(c)
    if op=='+':values.append(v)
    elif op=='−':values.append(-v)
    elif op=='×':values[-1]*=v
    else:raise ValueError(op)
  return sum(values,Fraction(0))
 raise ValueError(x.tag)
checked=[]
for c in D['cases'].values():
 for p in c['paths']:
  for lid in p['lineIds']:assert rows[lid]['reason']
  if c['statistic']=='mean':
   sub=node(rows[p['lineIds'][0]]['rhs']);frac=sub[0];assert frac.tag=='mfrac'
   observations=[Fraction(x.text) for x in frac[0] if x.tag=='mn'];assert observations==[F(x) for x in p['values']],p['id']
   assert calc(frac[1])==2
   for lid in p['lineIds']:assert calc(node(rows[lid]['rhs']))==F(p['statisticValue']),lid
  else:
   assert calc(node(rows[p['lineIds'][1]]['rhs']))==max(F(x) for x in p['values'])
  checked.extend(p['lineIds'])
 assert calc(node(rows[c['id']+'-weight']['rhs']))==F(c['paths'][0]['probability'])
 for g in c['distribution']:
  assert calc(node(rows[g['lineId']]['rhs']))==F(g['probability'])
  statement=rows[g['lineId']+'-paths']['statement']
  for pid in g['pathIds']:assert pid in statement
 assert calc(node(rows[c['id']+'-total']['rhs']))==1
report={'scope':'Authored MathML layer compared to frozen common data; no independent oracle implementation read','meanMappingLines':153,'allPathLineIds':len(checked),'cases':len(D['cases']),'checks':'All 51 mean-path substitutions preserve ordered input values and denominator2; addition/division values match exact rational mean; maximum case compares both inputs; all eight path weights and grouped exact probabilities/total rows match frozen data.','dataSha256':hashlib.sha256((R/'exact-math.json').read_bytes()).hexdigest(),'proofRowsSha256':hashlib.sha256((R/'proof-lines.json').read_bytes()).hexdigest(),'passed':True}
(R/'authored-math-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
